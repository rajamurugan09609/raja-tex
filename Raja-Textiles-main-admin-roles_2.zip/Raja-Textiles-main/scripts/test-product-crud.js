const { createClient } = require("@supabase/supabase-js");
const fs = require("fs");
const path = require("path");

function getEnv() {
  const envPath = path.join(__dirname, "..", ".env.local");
  if (!fs.existsSync(envPath)) return {};
  const content = fs.readFileSync(envPath, "utf-8");
  const env = {};
  content.split("\n").forEach((line) => {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith("#")) {
      const idx = trimmed.indexOf("=");
      if (idx !== -1) {
        env[trimmed.substring(0, idx).trim()] = trimmed.substring(idx + 1).trim();
      }
    }
  });
  return env;
}

async function testCrud() {
  const env = getEnv();
  const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL || "https://fbejdxujhxjcmmgsrqeh.supabase.co";
  const supabaseKey =
    env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
    env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
    "sb_publishable_N1aPdp7s3a6KL8Ab3VrraQ_5PJtfElR";

  const client = createClient(supabaseUrl, supabaseKey);

  console.log("Checking current products in Supabase...");
  const { data: initialList, error: listErr } = await client.from("products").select("id, name");
  if (listErr) {
    console.error("Failed to list products:", listErr.message);
    process.exit(1);
  }
  console.log(`Current products in Supabase: ${initialList.length}`);

  // Test inserting a temporary product
  const testId = `test-temp-${Date.now()}`;
  console.log(`Inserting test product ${testId}...`);
  const { error: insErr } = await client.from("products").insert([
    {
      id: testId,
      slug: testId,
      name: "Temporary Verification Product",
      description: "Sample test description for verification",
      category: "Karizma Silk",
      department: "Sarees",
      section: "Women",
      price: 999,
      original_price: 1999,
      discount_percent: 50,
      stock_count: 5,
      in_stock: true,
      fabric: "Soft Silk (80's warp)",
      saree_length: "6.25m with blouse",
      zari_type: "Golden Metallic Zari",
      pallu: "Rich Contrast Graphic Pallu",
      weight: "600 grams",
      unit: "piece",
      images: [
        "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
        "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80"
      ],
      colors: [{ name: "Standard", hex: "#681329", inStock: true }],
      care: ["Dry clean only"]
    }
  ]);

  if (insErr) {
    console.error("Insert error:", insErr.message);
    process.exit(1);
  }
  console.log("Test product successfully inserted with 3 gallery images!");

  // Verify it exists
  const { data: checkData } = await client.from("products").select("id, images").eq("id", testId).single();
  console.log(`Verified existence in DB. Images count: ${checkData.images.length}`);

  // Now test deleting it
  console.log("Deleting test product...");
  const { error: delErr } = await client.from("products").delete().eq("id", testId);
  if (delErr) {
    console.error("Delete error:", delErr.message);
    process.exit(1);
  }
  console.log("Test product deleted from Supabase successfully!");

  // Verify it is gone
  const { data: afterDel } = await client.from("products").select("id").eq("id", testId);
  console.log(`Check after deletion (expected 0): ${afterDel ? afterDel.length : 0}`);

  // Verify all 16 original products still intact
  const { data: finalList } = await client.from("products").select("id, name");
  console.log(`Final count of permanent products: ${finalList.length} (Expected: 16)`);
  console.log("All CRUD and multi-image operations in Supabase verified 100% successfully!");
}

testCrud().catch((e) => {
  console.error(e);
  process.exit(1);
});
