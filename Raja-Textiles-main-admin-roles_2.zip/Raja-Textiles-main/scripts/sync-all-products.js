const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const ts = require('typescript');

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://fbejdxujhxjcmmgsrqeh.supabase.co';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_N1aPdp7s3a6KL8Ab3VrraQ_5PJtfElR';
const client = createClient(supabaseUrl, supabaseKey);

async function main() {
  const tsCode = fs.readFileSync('src/data/products.ts', 'utf8');
  const jsCode = ts.transpileModule(tsCode, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 }
  }).outputText;

  const m = { exports: {} };
  const fn = new Function('module', 'exports', 'require', jsCode);
  fn(m, m.exports, require);

  const initialProducts = m.exports.INITIAL_PRODUCTS;
  console.log(`Found ${initialProducts.length} initial products.`);

  const { data: existing, error: fetchErr } = await client.from('products').select('id');
  if (fetchErr) {
    console.error('Error fetching existing:', fetchErr);
    return;
  }
  const existingIds = new Set((existing || []).map(p => p.id));
  console.log('Existing IDs in Supabase:', Array.from(existingIds));

  let insertedCount = 0;
  for (const p of initialProducts) {
    if (existingIds.has(p.id)) {
      console.log(`Product ${p.id} (${p.name}) already exists. Skipping.`);
      continue;
    }

    const row = {
      id: p.id,
      slug: p.slug,
      name: p.name,
      category: p.category,
      department: p.department || 'Sarees',
      section: p.section || 'Women',
      price: Number(p.price),
      original_price: Number(p.originalPrice || p.price * 2),
      discount_percent: Number(p.discountPercent || 50),
      unit: p.unit || 'piece',
      description: p.description || '',
      fabric: p.fabric || 'Soft Silk',
      saree_length: p.sareeLength || '6.25m with blouse',
      zari_type: p.zariType || 'Golden Zari',
      pallu: p.pallu || 'Rich Contrast Pallu',
      weight: p.weight || '600 grams',
      care: p.care || [],
      images: p.images || [],
      colors: p.colors || [],
      in_stock: p.inStock ?? true,
      stock_count: Number(p.stockCount || 15),
      is_featured: Boolean(p.isFeatured),
      is_best_seller: Boolean(p.isBestSeller),
      rating: Number(p.rating || 5.0),
      review_count: Number(p.reviewCount || 1),
      created_at: p.createdAt || new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const { error: upsertErr } = await client.from('products').upsert(row);
    if (upsertErr) {
      console.error(`Failed to insert ${p.id}:`, upsertErr.message);
    } else {
      console.log(`Inserted: ${p.id} - ${p.name}`);
      insertedCount++;
    }
  }

  const { count } = await client.from('products').select('*', { count: 'exact' });
  console.log(`Sync complete. Inserted: ${insertedCount}. Total in DB now: ${count}`);
}

main().catch(console.error);
