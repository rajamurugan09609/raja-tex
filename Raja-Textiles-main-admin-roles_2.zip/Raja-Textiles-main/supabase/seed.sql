-- =========================================================================
-- RAJA TEXTILE (ELAMPILLAI, SALEM) — INITIAL SEED DATA
-- =========================================================================

-- 1. SEED CATEGORIES
INSERT INTO public.categories (id, slug, name, tamil_name, tagline, description, image, item_count)
VALUES
  ('cat-1', 'karizma-silk', 'Karizma Silk Sarees', 'கரிஷ்மா சில்க்', '3D Embossed & Dual Zari Weaves', 'Engineered with 80s warp weaving, rich copper and silver zari buttas, and smooth lichi-soft drape.', '/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg', 8),
  ('cat-2', 'vintage-kolam', 'Vintage Kolam Sarees', 'கோலம் டிசைன் சில்க்', 'Sacred Geometric Art & Tassels', 'Auspicious Kolam pallus paired with contrast blouses and ultra-lightweight traditional drape.', '/images/products/5a0c39283b9e3a06aaf172239fe371ff.jpg', 6),
  ('cat-3', 'soft-silk', 'Shining Soft Silk', 'சாஃப்ட் சில்க்', 'Golden Zari Buttas & Lichi Finish', 'Lustrous golden zari buttas scattered across royal jewel tones with magnificent contrast borders.', '/images/products/950becc422bfe0054787b3692b27dbd5.jpg', 9),
  ('cat-4', 'bridal-weaves', 'Bridal & Function Edit', 'முகூர்த்த பட்டு', 'Grand Jacquard & Wedding Silks', 'High-density zari borders and festive pallus woven for weddings, housewarmings, and special family rituals.', '/images/products/520c970018c55e4d922933b05cc865c2.jpg', 5),
  ('cat-5', 'temple-border', 'Temple Border Silks', 'கோவில் பார்டர்', 'Traditional Gopuram Spire Borders', 'Timeless South Indian temple border motifs celebrating the rich heritage of Salem handloom mastery.', '/images/products/f565c8cbc1de336ce4b5fb31a34353c1.jpg', 4)
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  image = EXCLUDED.image;

-- 2. SEED INITIAL PRODUCTS
INSERT INTO public.products (
  id, slug, name, category, section, price, original_price, discount_percent,
  description, fabric, saree_length, zari_type, pallu, weight,
  care, images, colors, in_stock, stock_count, is_featured, is_best_seller, rating, review_count
) VALUES
(
  'prod-karizma-3d-01',
  '3d-embossed-karizma-silk-saree',
  '3D Embossed Karizma Silk Saree',
  'Karizma Silk',
  'Women',
  649,
  1999,
  67,
  'Exquisitely hand-finished 3D embossed Karizma silk saree crafted at our Elampillai looms. Features fine 80s warp weaving with lustrous copper and silver zari buttas that elevate any festival, pooja, or celebratory occasion. The soft lichi drape ensures hours of graceful comfort without heaviness.',
  'Karizma Silk (80s warp jacquard woven)',
  '6.25 meters (includes 0.8m running contrast unstitched blouse piece)',
  'Dual-tone Copper & Silver Metallic Zari',
  'Rich Contrast Graphic Pallu with Traditional Zari Jaal',
  '600 grams (Easy drape & crease-resistant)',
  '["Dry clean recommended for first wash", "Gentle cold hand wash with mild shampoo thereafter", "Do not wring or dry directly under harsh noon sunlight", "Low temperature iron on reverse side"]'::jsonb,
  '["/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg", "/images/products/fbabaa2126da87b707a75408119bb842.jpg", "/images/products/affdee654a37eb21f6c1244b0ecf4e4d.jpg", "/images/products/53da7e4e5236b934da8cf6e5eb66b831.jpg", "/images/products/3ea4c01f996c651a1a3ec221e31e4ad2.jpg", "/images/products/0b751002f6f852991f4482c05c81c002.jpg"]'::jsonb,
  '[{"name": "Royal Blue & Gold", "hex": "#193982", "inStock": true, "imageIndex": 0}, {"name": "Ruby Rani Pink", "hex": "#C41E3A", "inStock": true, "imageIndex": 1}, {"name": "Emerald Peacock", "hex": "#097969", "inStock": true, "imageIndex": 2}, {"name": "Wine Violet", "hex": "#4A154B", "inStock": true, "imageIndex": 3}, {"name": "Mustard Gold", "hex": "#D4AF37", "inStock": true, "imageIndex": 4}, {"name": "Teal Cyan", "hex": "#008080", "inStock": true, "imageIndex": 5}]'::jsonb,
  true,
  28,
  true,
  true,
  4.9,
  94
),
(
  'prod-kolam-vintage-02',
  'vintage-kolam-soft-silk-saree',
  'Vintage Kolam Soft Silk Saree',
  'Vintage Kolam',
  'Traditional',
  699,
  1999,
  65,
  'Celebrated across Tamil Nadu for its auspicious Kolam motifs, this Vintage Kolam Soft Silk Saree captures the spirit of traditional celebrations. Features fine gold zari detailing, handcrafted pallu tassels, and vibrant dual-tone shades that catch the evening light beautifully.',
  'Premium Soft Silk with Traditional Kolam Art Motif',
  '6.25 meters (includes 0.8m contrast designer blouse piece)',
  'Antique Golden Zari Woven Borders',
  'Elampillai Special Rich Kolam Art Pallu with Hand-tied Tassels',
  '570 grams (Ultra lightweight & breathable)',
  '["Dry clean preferred for first wash", "Do not bleach or soak for prolonged hours", "Steam iron or warm reverse iron only"]'::jsonb,
  '["/images/products/5a0c39283b9e3a06aaf172239fe371ff.jpg", "/images/products/4d492f437350acc06ccd8d4f7efb6ba5.jpg", "/images/products/7a63501980485d5db51a2e795a8af361.jpg", "/images/products/fc96d886dd86c938b52a1662ceb216e0.jpg", "/images/products/9e53cbe5dd4d48d9aa34bbe2d3da05dd.jpg"]'::jsonb,
  '[{"name": "Deep Rani Pink", "hex": "#B81D5B", "inStock": true, "imageIndex": 0}, {"name": "Royal Violet", "hex": "#5B2C6F", "inStock": true, "imageIndex": 1}, {"name": "Dual-tone Rose Green", "hex": "#A93226", "inStock": true, "imageIndex": 2}, {"name": "Golden Turmeric", "hex": "#D4AC0D", "inStock": true, "imageIndex": 3}, {"name": "Rama Green", "hex": "#117864", "inStock": true, "imageIndex": 4}]'::jsonb,
  true,
  19,
  true,
  true,
  5.0,
  118
),
(
  'prod-shining-fusion-03',
  'shining-fusion-soft-silk-saree',
  'Shining Fusion Soft Silk Saree',
  'Soft Silk',
  'Festive',
  699,
  1999,
  65,
  'The Shining Fusion collection brings together modern lichi-soft textures with timeless South Indian zari craftsmanship. Golden zari floral buttas sparkle across the body, complemented by a grand contrast gold border and magnificent royal pallu.',
  'Shining Lichi-Fusion Soft Silk',
  '6.25 meters (includes 0.8m contrast blouse piece)',
  'Lustrous Golden Zari Buttas & Contrast Border',
  'Regal Contrast Pallu with Floral & Mango Zari Weave',
  '590 grams',
  '["Dry clean recommended", "Store wrapped in muslin cloth for zari preservation", "Avoid spraying perfume directly on zari work"]'::jsonb,
  '["/images/products/950becc422bfe0054787b3692b27dbd5.jpg", "/images/products/93ceaae9391b962ddae5bf7fb34aea97.jpg", "/images/products/e8ade850e5d11e3c11c9f9d09584c959.jpg", "/images/products/026cb5004ffdb6507cbe41d23aada623.jpg", "/images/products/65d05d4e2ece06a2fd00b3329e23ea53.jpg", "/images/products/49acc1ae8eee3a3a320a3298e51a1469.jpg"]'::jsonb,
  '[{"name": "Festive Crimson Red", "hex": "#990000", "inStock": true, "imageIndex": 0}, {"name": "Violet Purple", "hex": "#4A235A", "inStock": true, "imageIndex": 1}, {"name": "Royal Sapphire Blue", "hex": "#1A5276", "inStock": true, "imageIndex": 2}, {"name": "Rani Magenta", "hex": "#C2185B", "inStock": true, "imageIndex": 3}, {"name": "Olive Gold", "hex": "#7D6608", "inStock": true, "imageIndex": 4}, {"name": "Dark Maroon", "hex": "#681329", "inStock": true, "imageIndex": 5}]'::jsonb,
  true,
  32,
  true,
  true,
  4.8,
  95
)
ON CONFLICT (id) DO UPDATE SET
  price = EXCLUDED.price,
  original_price = EXCLUDED.original_price,
  stock_count = EXCLUDED.stock_count;

-- 3. SEED STORE SETTINGS
INSERT INTO public.store_settings (
  id, store_name, tagline, phone, whatsapp, email, address, city, state, pincode, operating_hours, announcement_text, free_shipping_threshold, shipping_fee
) VALUES (
  'default',
  'Raja Textile',
  'Master Weavers of Elampillai, Salem',
  '+91 93600 21627',
  '919360021627',
  'care@rajatextile.in',
  'Main Road, Elampillai, Salem',
  'Salem',
  'Tamil Nadu',
  '637502',
  'Open all days · 9:30 AM – 9:00 PM',
  '✨ Direct from the Master Weavers of Elampillai • Fast Delivery Across India • WhatsApp Order Support: +91 93600 21627',
  999,
  70
)
ON CONFLICT (id) DO UPDATE SET
  store_name = EXCLUDED.store_name,
  phone = EXCLUDED.phone,
  whatsapp = EXCLUDED.whatsapp;
