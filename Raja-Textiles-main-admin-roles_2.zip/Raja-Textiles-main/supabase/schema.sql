-- =========================================================================
-- RAJA TEXTILE (ELAMPILLAI, SALEM) — PRODUCTION DATABASE SCHEMA & MIGRATION
-- Run this script in your Supabase Dashboard SQL Editor.
-- It safely upgrades existing tables and creates missing tables and indexes.
-- =========================================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. BASE TABLES CREATION (If they do not exist)
create table if not exists public.categories (
  id text primary key,
  slug text unique not null,
  name text not null,
  department text not null default 'Sarees',
  tamil_name text,
  tagline text,
  description text,
  image text not null,
  item_count integer default 0,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create table if not exists public.products (
  id text primary key,
  slug text unique not null,
  name text not null,
  category text not null,
  department text not null default 'Sarees',
  section text default 'Women',
  price numeric(10,2) not null,
  original_price numeric(10,2) not null,
  discount_percent integer default 0,
  unit text default 'piece',
  description text not null,
  fabric text not null,
  saree_length text not null,
  zari_type text not null,
  pallu text not null,
  weight text not null,
  care jsonb default '[]'::jsonb,
  images jsonb default '[]'::jsonb,
  colors jsonb default '[]'::jsonb,
  in_stock boolean default true,
  stock_count integer default 10,
  is_featured boolean default false,
  is_best_seller boolean default false,
  rating numeric(3,2) default 5.0,
  review_count integer default 0,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

create table if not exists public.user_profiles (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  full_name text not null default '',
  phone text,
  role text not null default 'customer',
  addresses jsonb default '[]'::jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create table if not exists public.orders (
  id text primary key,
  order_number text unique not null,
  user_id uuid references auth.users on delete set null,
  customer jsonb not null,
  items jsonb not null,
  pricing jsonb not null,
  payment_method text not null,
  payment_status text not null default 'pending',
  order_status text not null default 'placed',
  payment_reference_id text,
  tracking_number text,
  courier_name text,
  notes text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create table if not exists public.store_settings (
  id text primary key default 'default',
  store_name text not null default 'Raja Textile',
  tagline text not null default 'Master Weavers of Elampillai, Salem',
  phone text not null default '+91 93600 21627',
  whatsapp text not null default '919360021627',
  email text not null default 'care@rajatextile.in',
  address text not null default 'Main Road, Elampillai, Salem',
  city text not null default 'Salem',
  state text not null default 'Tamil Nadu',
  pincode text not null default '637502',
  operating_hours text not null default 'Open all days · 9:30 AM – 9:00 PM',
  announcement_text text not null default '✨ Direct from the Master Looms of Elampillai • Free Pan-India Delivery Above ₹999',
  free_shipping_threshold integer not null default 999,
  shipping_fee integer not null default 70,
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

create table if not exists public.coupons (
  id text primary key,
  code text unique not null,
  discount_type text not null, -- 'percentage' or 'flat'
  discount_value numeric(10,2) not null,
  min_order_amount numeric(10,2) default 0,
  is_active boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- =========================================================================
-- 2. SAFE COLUMN UPGRADES FOR EXISTING TABLES
-- This ensures existing tables without new columns are upgraded immediately.
-- =========================================================================
alter table public.products add column if not exists department text not null default 'Sarees';
alter table public.products add column if not exists unit text default 'piece';

alter table public.categories add column if not exists department text not null default 'Sarees';

alter table public.orders add column if not exists user_id uuid references auth.users on delete set null;
alter table public.orders add column if not exists courier_name text;

-- =========================================================================
-- 3. PERFORMANCE INDEXES
-- =========================================================================
create index if not exists idx_products_category on public.products(category);
create index if not exists idx_products_department on public.products(department);
create index if not exists idx_products_slug on public.products(slug);
create index if not exists idx_products_featured on public.products(is_featured);
create index if not exists idx_orders_user_id on public.orders(user_id);
create index if not exists idx_orders_order_number on public.orders(order_number);
create index if not exists idx_orders_created_at on public.orders(created_at desc);

-- =========================================================================
-- 4. ROW LEVEL SECURITY (RLS) POLICIES
-- =========================================================================
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.user_profiles enable row level security;
alter table public.orders enable row level security;
alter table public.store_settings enable row level security;
alter table public.coupons enable row level security;

-- Categories & Products: Public Read Access
drop policy if exists "Public can view categories" on public.categories;
create policy "Public can view categories" on public.categories for select using (true);

drop policy if exists "Public can view products" on public.products;
create policy "Public can view products" on public.products for select using (true);

drop policy if exists "Public can view store settings" on public.store_settings;
create policy "Public can view store settings" on public.store_settings for select using (true);

-- User Profiles: Users can view & update their own profile
drop policy if exists "Users can view own profile" on public.user_profiles;
create policy "Users can view own profile" on public.user_profiles for select using (auth.uid() = id);

drop policy if exists "Users can update own profile" on public.user_profiles;
create policy "Users can update own profile" on public.user_profiles for update using (auth.uid() = id);

-- Orders: Users can view their own orders
drop policy if exists "Users can view own orders" on public.orders;
create policy "Users can view own orders" on public.orders for select using (auth.uid() = user_id or auth.uid() is null);

-- =========================================================================
-- 5. AUTOMATIC USER PROFILE TRIGGER & OWNER ROLE ASSIGNMENT
-- Automatically assigns 'owner' role to sriharibshk@gmail.com upon signup or update
-- =========================================================================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.user_profiles (id, email, full_name, role, created_at, updated_at)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    case when lower(new.email) in ('sriharibshk@gmail.com', 'owner@rajatextile.in') then 'owner' else 'customer' end,
    now(),
    now()
  )
  on conflict (id) do update set
    role = case when lower(excluded.email) in ('sriharibshk@gmail.com', 'owner@rajatextile.in') then 'owner' else public.user_profiles.role end;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Immediately grant owner role to sriharibshk@gmail.com if already exists
update public.user_profiles
set role = 'owner'
where lower(email) in ('sriharibshk@gmail.com', 'owner@rajatextile.in');
