-- =========================================================================
-- ADMIN ROLES (Main Admin / Normal Admin)
-- Run this ONCE in Supabase Dashboard -> SQL Editor.
--
--   main_admin : full access (orders, settings, hero, products, admin team)
--   admin      : Normal Admin -> can ONLY add new products
--
-- Emails listed in OWNER_EMAILS (.env) are always Main Admins.
-- This table is only for the extra admins created from the Owner Portal.
-- =========================================================================

create table if not exists public.admins (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users on delete cascade,
  email text unique not null,
  full_name text not null default '',
  role text not null default 'admin' check (role in ('main_admin', 'admin')),
  created_by text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index if not exists idx_admins_email on public.admins(lower(email));

-- SECURITY: RLS ON and NO policies => the browser (anon/publishable key) can
-- never read or write this table. Only the server (SUPABASE_SECRET_KEY) can.
-- (Do NOT store roles in user_profiles: users can update their own profile row.)
alter table public.admins enable row level security;
