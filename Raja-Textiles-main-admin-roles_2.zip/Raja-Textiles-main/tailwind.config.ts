import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        raja: {
          maroon: {
            DEFAULT: "#681329",
            dark: "#400914",
            light: "#851A36",
            subtle: "#F8EFF1",
          },
          wine: "#400914",
          gold: {
            DEFAULT: "#C49436",
            light: "#DFC077",
            dark: "#9B7120",
            shimmer: "#F5E9CE",
            glow: "rgba(196, 148, 54, 0.25)",
          },
          ivory: {
            DEFAULT: "#FAF5EE",
            warm: "#F3EAE0",
            card: "#FFFFFF",
          },
          ink: {
            DEFAULT: "#291D1A",
            soft: "#5C4A44",
            muted: "#8B7A74",
            border: "#E9DFD3",
          },
        },
      },
      fontFamily: {
        serif: ["var(--font-serif)", "Cormorant Garamond", "Marcellus", "Georgia", "serif"],
        display: ["var(--font-serif)", "Cormorant Garamond", "Marcellus", "Georgia", "serif"],
        sans: ["var(--font-sans)", "Plus Jakarta Sans", "system-ui", "-apple-system", "sans-serif"],
      },
      boxShadow: {
        "gold-sm": "0 2px 8px -1px rgba(196, 148, 54, 0.15)",
        "gold-md": "0 6px 20px -2px rgba(196, 148, 54, 0.25)",
        "gold-lg": "0 12px 32px -4px rgba(196, 148, 54, 0.35)",
        "luxury": "0 20px 40px -15px rgba(64, 9, 20, 0.12)",
        "luxury-hover": "0 25px 50px -12px rgba(104, 19, 41, 0.2)",
      },
      animation: {
        "marquee": "marquee 35s linear infinite",
        "marquee-slow": "marquee 50s linear infinite",
        "shimmer": "shimmer 2.5s infinite",
        "float": "float 4s ease-in-out infinite",
      },
      keyframes: {
        marquee: {
          "0%": { transform: "translateX(0%)" },
          "100%": { transform: "translateX(-50%)" },
        },
        shimmer: {
          "100%": { transform: "translateX(100%)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-6px)" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
