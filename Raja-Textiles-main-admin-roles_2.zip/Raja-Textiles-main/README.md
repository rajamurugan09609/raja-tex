# Raja Textile — Premium Full-Stack E-Commerce Storefront

A high-performance, luxury e-commerce web platform for **Raja Textile**, located in the historic handloom cluster of **Elampillai, Salem, Tamil Nadu, India**.

Designed with an original South Indian luxury editorial aesthetic: traditional weaving heritage meets high-fashion editorial, authentic weaver-direct pricing, robust inventory & cart logic, server-validated checkout with Cashfree payment gateway & WhatsApp ordering, resilient database repository with Supabase PostgreSQL & RLS, and a dedicated staff administration portal.

---

## 1. Verified Brand & Business Information

- **Brand Name**: Raja Textile
- **Tagline**: Master Weavers of Elampillai, Salem
- **Heritage / Specialization**: 3D Embossed Karizma Silks, Vintage Kolam Zari Motifs, Shining Lichi Fusion Soft Silks, and Grand Wedding Brocade Sarees.
- **Store & Workshop Address**: Main Road, Elampillai, Salem — 637502, Tamil Nadu, India
- **Customer Care & Direct WhatsApp**: `+91 93600 21627`
- **Store Hours**: Open all days · 9:30 AM – 9:00 PM IST

---

## 2. Architecture & Tech Stack

- **Framework**: Next.js 14 (App Router) with React 18, TypeScript & Node.js
- **Styling**: Tailwind CSS with custom Raja Textile South Indian Luxury Palette:
  - Deep Maroon: `#681329`
  - Dark Wine: `#400914`
  - Antique Gold: `#C49436`
  - Warm Ivory: `#FAF5EE`
  - Dark Ink: `#291D1A`
- **Typography**: Editorial Serif display paired with readable sans-serif.
- **State & Storage**:
  - `CartContext`: Persistent shopping bag with coupon discounting, free delivery threshold calculation, and quantity validation.
  - `WishlistContext`: Client-side persistent favorite sarees.
  - `ToastContext`: Accessible notifications.
- **Backend & Data Resilience**:
  - Supabase PostgreSQL client & admin wrapper (`@supabase/supabase-js`).
  - Unified repository (`src/lib/db.ts`) with intelligent fail-safe: automatically syncs with Supabase PostgreSQL when provisioned, and seamlessly falls back to high-fidelity local state so the store never goes down or throws 500 errors.
- **Payments**:
  - Official Cashfree Payment Gateway 2023-08-01 API (`/api/checkout/cashfree/create-order`, `/api/checkout/cashfree/verify`, `/api/checkout/cashfree/webhook`).
  - Cashfree Sandbox mode fallback when merchant credentials are unconfigured.
  - Direct Artisan WhatsApp Order fallback with auto-formatted bill breakdown.
  - Cash on Delivery (COD) with PIN code verification.
- **Admin Experience** (`/admin`):
  - Passcode protected (`raja2026` or Elampillai PIN `637502`).
  - Live metric indicators (Active weaves, in-stock count, customer orders, pending dispatches).
  - Product CRUD (Add new saree weave, edit prices, update stock, toggle featured).
  - Customer order management (Status transition: Placed → Confirmed → Shipped → Delivered, add courier tracking AWB).

---

## 3. Important File Locations

```
program/
├── public/
│   ├── images/
│   │   ├── diwali-banner.jpg          # Authentic festival hero visual
│   │   ├── collection-banner.jpg      # Handloom collection banner
│   │   └── products/                  # 23 High-resolution original saree photos
├── src/
│   ├── app/
│   │   ├── page.tsx                   # Luxury homepage (Hero, Marquee, Categories, Grid, Story, Visit)
│   │   ├── layout.tsx                 # Root layout with metadata and providers
│   │   ├── products/page.tsx          # Full catalog with search, filters & sort
│   │   ├── products/[slug]/page.tsx   # Product detail with multi-image gallery, zoom, pincode check
│   │   ├── category/[slug]/page.tsx   # Dedicated weave category pages
│   │   ├── checkout/page.tsx          # 3-step secure checkout form & summary
│   │   ├── checkout/success/page.tsx  # Order confirmation, invoice print, WhatsApp track
│   │   ├── checkout/cashfree-return/  # Cashfree payment gateway return handler
│   │   ├── wishlist/page.tsx          # Saved sarees with move-to-bag
│   │   ├── admin/page.tsx             # Staff portal for catalog & orders
│   │   ├── contact/page.tsx           # Verified Salem store contact & inquiry form
│   │   ├── about/page.tsx             # Heritage of Elampillai weavers
│   │   ├── track-order/page.tsx       # Live courier AWB tracking lookup
│   │   ├── shipping-policy/page.tsx   # Verified dispatch & delivery timelines
│   │   ├── returns-policy/page.tsx    # 7-day exchange terms
│   │   ├── saree-care-guide/page.tsx  # Zari preservation & washing guide
│   │   ├── terms/page.tsx             # Commercial terms & jurisdiction
│   │   ├── privacy/page.tsx           # PCI-DSS & privacy disclosures
│   │   └── api/                       # REST endpoints for orders, products, Cashfree
│   ├── components/                    # AnnouncementBar, Header, Footer, ProductCard, CartDrawer, etc.
│   ├── context/                       # CartContext, WishlistContext, ToastContext
│   ├── data/                          # Authentic initial catalog & store settings
│   ├── lib/                           # Database repository & Supabase client wrapper
│   └── types/                         # TypeScript interfaces
├── supabase/
│   └── schema.sql                     # Complete PostgreSQL DDL with RLS & indexes
├── .env.example                       # Placeholder environment variable template
└── .env.local                         # Active environment configuration
```

---

## 4. How to Run Locally

### Prerequisites
- Node.js 18+ or 20+ (tested and verified on Node v24.19.0)
- npm or pnpm

### Commands

```bash
# 1. Install dependencies
npm install

# 2. Run TypeScript type check
npx tsc --noEmit

# 3. Build for production
npm run build

# 4. Start production server
npm start
# Storefront is live at: http://localhost:3000
```

To run in development mode with hot reload:
```bash
npm run dev
```

---

## 5. Required Environment Variables

Place these in `.env.local` (a `.env.example` file is checked in for reference):

```ini
# APP
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME=Raja Textile

# SUPABASE POSTGRESQL & AUTH
NEXT_PUBLIC_SUPABASE_URL=https://<your-project>.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
SUPABASE_SECRET_KEY=sb_secret_...

# CASHFREE PAYMENT GATEWAY
CASHFREE_APP_ID=
CASHFREE_SECRET_KEY=
CASHFREE_ENV=SANDBOX # Or PRODUCTION

# WHATSAPP STORE CONTACT
WHATSAPP_PHONE_NUMBER=919360021627
```

---

## 6. Supabase Setup & Migration Instructions

1. Log into your Supabase Dashboard at [supabase.com](https://supabase.com).
2. Select your project (or create a new one).
3. Navigate to the **SQL Editor** from the left navigation panel.
4. Copy the entire contents of [`supabase/schema.sql`](./supabase/schema.sql) and paste into the SQL Editor.
5. Click **Run**.
6. Tables `products`, `categories`, `orders`, and `store_settings` with Row Level Security (RLS) policies and performance indexes will be created.

---

## 7. Cashfree Onboarding & Activation Steps

1. Register or log in to [Cashfree Payments](https://www.cashfree.com).
2. Complete Merchant KYC and activate the **Payment Gateway** product.
3. In **Developers > API Keys**, generate your **App ID** and **Secret Key**.
4. Set `CASHFREE_APP_ID` and `CASHFREE_SECRET_KEY` in `.env.local`.
5. For testing, keep `CASHFREE_ENV=SANDBOX`. Once approved for live payments, set `CASHFREE_ENV=PRODUCTION`.
6. In Cashfree Merchant Dashboard under **Webhooks**, set your webhook endpoint:
   `https://<your-domain>/api/checkout/cashfree/webhook`.


---

## Admin roles (Main Admin / Normal Admin)

| Role | Can do |
|------|--------|
| **Main Admin** | Everything: analytics, orders, store settings, hero banners, add / edit / delete / feature products, create & remove admins |
| **Normal Admin** | Add new products only |

**Setup (one time)**
1. Supabase Dashboard -> SQL Editor -> run `supabase/admin_roles.sql`.
2. Set `OWNER_EMAILS` (your Main Admin email) and `SUPABASE_SECRET_KEY` in `.env.local` / hosting env vars.
3. Log in with the Main Admin email -> `/owner` -> **Admin Team** tab -> create admins.

Permissions are enforced on the server (`src/lib/auth-server.ts` -> `ROLE_PERMISSIONS`). To let Normal Admin do more
(e.g. edit products), add the permission there, e.g. `admin: ["product:create", "product:update"]`.
