import React from "react";
import { STORE_SETTINGS } from "@/data/products";

export default function PrivacyPolicyPage() {
  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 bg-white p-8 sm:p-12 rounded-2xl border border-raja-ink-border shadow-sm">
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-raja-gold">
            Privacy & Data Security
          </span>
          <h1 className="font-serif text-3xl font-bold text-raja-maroon mt-1">
            Privacy Policy
          </h1>
          <p className="text-xs text-raja-ink-muted mt-1">
            Effective Date: October 2026 • Raja Textile, Elampillai, Salem
          </p>
        </div>

        <div className="space-y-6 text-xs text-raja-ink-soft leading-relaxed">
          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              1. Information We Collect
            </h2>
            <p>
              When you purchase or inquire on Raja Textile, we collect your name, delivery address, phone number, and email strictly for the purpose of processing your order, arranging courier delivery from Salem, and providing live tracking updates via WhatsApp/SMS.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              2. Payment Data Security
            </h2>
            <p>
              We do not store your credit card numbers, debit card PINs, or netbanking passwords on our servers. All digital transactions are securely processed through RBI-authorized payment aggregators (such as Cashfree Payments) adhering to PCI-DSS Level 1 compliance.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              3. No Sale of Customer Information
            </h2>
            <p>
              We respect your privacy. Raja Textile never sells, trades, or rents your personal contact information to third-party marketing companies.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              4. Contact Grievance Officer
            </h2>
            <p>
              For questions regarding your data, please contact our store care desk:
              <br />
              Email: <strong>{STORE_SETTINGS.email}</strong>
              <br />
              Phone: <strong>{STORE_SETTINGS.phone}</strong>
              <br />
              Address: Raja Textile, Main Road, Elampillai, Salem — 637502, Tamil Nadu, India.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
