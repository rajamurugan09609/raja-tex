"use client";

import React, { useState, useEffect } from "react";
import HeroSection from "@/components/HeroSection";
import TextileMarquee from "@/components/TextileMarquee";
import CollectionsSection from "@/components/CollectionsSection";
import FeaturedSareesSection from "@/components/FeaturedSareesSection";
import CraftsmanshipSection from "@/components/CraftsmanshipSection";
import StoreVisitSection from "@/components/StoreVisitSection";
import { INITIAL_PRODUCTS } from "@/data/products";
import { Product } from "@/types";

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);

  useEffect(() => {
    fetch("/api/products")
      .then((res) => res.json())
      .then((data) => {
        if (data.products && Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      {/* 1. CINEMATIC EDITORIAL HERO */}
      <HeroSection />

      {/* 2. SILKY NON-JUMPING TEXTILE MARQUEE */}
      <TextileMarquee />

      {/* 3. ASYMMETRIC EDITORIAL WEAVE COLLECTIONS */}
      <CollectionsSection />

      {/* 4. FEATURED PRODUCTS & WEAVE CATALOG WITH ANIMATED TABS & QUICK VIEW */}
      <FeaturedSareesSection products={products} />

      {/* 5. INTERACTIVE 4-STAGE ELAMPILLAI CRAFTSMANSHIP DEEP DIVE */}
      <CraftsmanshipSection />

      {/* 6. VERIFIED SALEM SHOWROOM VISIT & WHATSAPP VIDEO CONSULTATION */}
      <StoreVisitSection />
    </div>
  );
}
