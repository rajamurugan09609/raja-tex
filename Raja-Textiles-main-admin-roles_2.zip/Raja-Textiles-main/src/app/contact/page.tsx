"use client";

import React, { useState } from "react";
import {
  MapPin,
  Phone,
  MessageCircle,
  Clock,
  Send,
  CheckCircle2,
} from "lucide-react";
import { STORE_SETTINGS } from "@/data/products";
import { useToast } from "@/context/ToastContext";

export default function ContactPage() {
  const { showToast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    purpose: "Bridal / Function Bulk Order",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    showToast("Nandri! Your message has been sent to Raja Textile weavers.");
  };

  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="text-center space-y-3">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-raja-gold">
            Get in Touch
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-raja-maroon">
            Visit Our Store or Message Us
          </h1>
          <p className="text-xs sm:text-sm text-raja-ink-soft max-w-xl mx-auto">
            Direct weaver customer service based in Elampillai, Salem, Tamil Nadu.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Verified Information */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-8 shadow-sm space-y-6">
            <h2 className="font-serif text-xl font-bold text-raja-ink">
              Store & Workshop Details
            </h2>

            <div className="space-y-4 text-xs text-raja-ink">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-raja-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-sm">Raja Textile</p>
                  <p className="text-raja-ink-soft mt-0.5 leading-relaxed">
                    Main Road, Elampillai,
                    <br />
                    Salem, Tamil Nadu — 637502, India
                  </p>
                  <a
                    href="https://maps.google.com/?q=Elampillai,+Salem,+Tamil+Nadu"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block mt-2 text-raja-maroon font-semibold hover:underline"
                  >
                    Open Google Maps Directions →
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2 border-t border-raja-ink-border/60">
                <Phone className="w-5 h-5 text-raja-gold flex-shrink-0" />
                <div>
                  <p className="font-bold">Phone Support</p>
                  <a
                    href={`tel:${STORE_SETTINGS.phone.replace(/[^0-9+]/g, "")}`}
                    className="text-raja-ink-soft hover:text-raja-maroon font-medium"
                  >
                    {STORE_SETTINGS.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2 border-t border-raja-ink-border/60">
                <MessageCircle className="w-5 h-5 text-[#25D366] flex-shrink-0" />
                <div>
                  <p className="font-bold">Official WhatsApp</p>
                  <a
                    href={`https://wa.me/${STORE_SETTINGS.whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-raja-ink-soft hover:text-raja-maroon font-medium"
                  >
                    +91 93600 21627 (Live Chat & Video Call)
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2 border-t border-raja-ink-border/60">
                <Clock className="w-5 h-5 text-raja-gold flex-shrink-0" />
                <div>
                  <p className="font-bold">Operating Hours</p>
                  <p className="text-raja-ink-soft">{STORE_SETTINGS.operatingHours}</p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-raja-ink-border space-y-2">
              <a
                href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20have%20an%20inquiry.`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-lg bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp Directly</span>
              </a>

              <a
                href={`tel:${STORE_SETTINGS.phone.replace(/[^0-9+]/g, "")}`}
                className="w-full py-3 px-4 rounded-lg bg-raja-maroon hover:bg-raja-maroon-light text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <Phone className="w-4 h-4 text-raja-gold" />
                <span>Call Store: +91 93600 21627</span>
              </a>
            </div>
          </div>

          {/* Right Column: Inquiry Form */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-8 shadow-sm">
            <h2 className="font-serif text-xl font-bold text-raja-ink mb-2">
              Send an Inquiry to Master Weavers
            </h2>
            <p className="text-xs text-raja-ink-soft mb-6">
              Inquiring for family weddings, temple rituals, or wholesale bulk orders? Leave your details below.
            </p>

            {submitted ? (
              <div className="p-8 text-center bg-raja-ivory rounded-xl space-y-3">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h3 className="font-serif text-lg font-bold text-raja-ink">
                  Message Received!
                </h3>
                <p className="text-xs text-raja-ink-soft max-w-sm mx-auto">
                  Our weaving team will contact you shortly on WhatsApp or phone call. Nandri!
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-2 text-xs text-raja-maroon font-semibold underline"
                >
                  Send another inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-raja-ink mb-1">
                    Your Full Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Meenakshi Sundaram"
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-raja-ink mb-1">
                      Phone Number <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="10-digit mobile number"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-raja-ink mb-1">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="email@example.com"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-raja-ink mb-1">
                    Nature of Inquiry
                  </label>
                  <select
                    value={formData.purpose}
                    onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border bg-white"
                  >
                    <option value="Bridal / Function Bulk Order">Bridal / Function Bulk Order</option>
                    <option value="Single Saree Order Assistance">Single Saree Order Assistance</option>
                    <option value="WhatsApp Video Call Saree Inspection">WhatsApp Video Call Saree Inspection</option>
                    <option value="Store Visit Directions">Store Visit Directions</option>
                    <option value="Reseller / Wholesale Partnership">Reseller / Wholesale Partnership</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-raja-ink mb-1">
                    Message / Specifications
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us what color schemes, zari patterns, or quantity you require..."
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-lg bg-raja-maroon hover:bg-raja-maroon-light text-white font-semibold text-xs transition-colors shadow-md flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5 text-raja-gold" />
                  <span>Submit Inquiry to Raja Textile</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
