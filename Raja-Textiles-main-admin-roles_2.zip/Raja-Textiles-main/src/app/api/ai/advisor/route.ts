import { NextRequest, NextResponse } from "next/server";
import { INITIAL_PRODUCTS } from "@/data/products";
import { Product } from "@/types";

const SYSTEM_PROMPT = `You are "Raja AI", the master loom textile & styling advisor for Raja Textile, based in Elampillai, Salem, Tamil Nadu, India.

Your identity and expertise:
- You represent a multi-generational master weaver family from the celebrated textile hub of Elampillai, Salem (PIN 637502).
- You have deep technical and cultural knowledge of South Indian handlooms across ALL textile categories:
  1. Sarees: 80's warp jacquards, 3D embossed Karizma silks, sacred Kolam geometric pallus, pure shining soft silks, and bridal brocade drapes.
  2. Fabrics & Yardage: Running mulberry raw silk and jacquard yardage sold per meter for bespoke designer blouses, lehengas, and kurtas.
  3. Dress Materials: 3-piece unstitched salwar suit sets with grand woven zari dupattas.
  4. Men's Garments: South Indian double dhotis (veshtis) with Mayilkan golden temple borders and matching wedding angavastrams.
  5. Home Textiles: Jacquard woven cushion covers and temple dining runners.
- Tone: Hospitable, warm (greet with "Vanakkam!"), sophisticated, and culturally authentic.
- Store details: Free Pan-India insured delivery on orders above ₹999, WhatsApp video assist (+91 93600 21627), showroom on Main Road, Elampillai, Salem.
- Direct loom prices range between ₹480 and ₹1,600 with zero middlemen markup.
- Format responses cleanly with bold headings, bullet points, and practical drape or styling advice.`;

// Intelligent Domain Knowledge Fallback Engine
function generateKnowledgeReply(query: string): { reply: string; matchedProducts: Product[] } {
  const q = query.toLowerCase();

  // 1. Men's Dhotis & Garments
  if (q.includes("men") || q.includes("dhoti") || q.includes("veshti") || q.includes("angavastram") || q.includes("shirt")) {
    const matched = INITIAL_PRODUCTS.filter((p) => p.department === "Garments");
    return {
      reply: `**Vanakkam!** 🙏 Here is our master weaver guide for **Traditional Men's Silk Wear**:

• **The Heritage Weave**: Our Salem double dhotis (8 Mulam / 4.0 meters) are woven on traditional pit and jacquard looms using premium silk-cotton blend yarns.
• **Zari Temple Borders**: Embellished with classic **Mayilkan (peacock eye)** and **Rudraksha temple motifs** in tested golden zari that stay crisp without creasing.
• **Matching Angavastram**: Each wedding set includes a matching 2.0-meter shoulder drape, perfect for temple darshans, muhurthams, and formal festivals.
• **Comfort & Drape**: Breathable, lightweight, and engineered to hold secure pleats through multi-hour wedding rituals.

Direct loom pricing starts from **₹799** (retail showroom price: ₹1,899). Pan-India delivery is free above ₹999!`,
      matchedProducts: matched.length > 0 ? matched : INITIAL_PRODUCTS.filter((p) => p.category.includes("Men")),
    };
  }

  // 2. Fabrics & Continuous Yardage
  if (q.includes("fabric") || q.includes("meter") || q.includes("yardage") || q.includes("blouse") || q.includes("lehenga") || q.includes("raw silk")) {
    const matched = INITIAL_PRODUCTS.filter((p) => p.department === "Fabrics");
    return {
      reply: `**Vanakkam!** 🙏 Here are our master loom specifications for **Running Silk Fabrics & Yardage**:

• **Weaving Composition**: Continuous mulberry raw silk and electronic jacquard yardage sold directly **per meter** (₹480/meter).
• **Width & Drape**: Full **44-inch standard width**, giving tailors and fashion designers generous cut space with zero fabric wastage.
• **Ideal Applications**:
  - **Bridal Blouses**: Heavy zari motifs that hold detailed aari work and zardosi embroidery without thread slippage.
  - **Designer Lehengas & Kurtas**: Structured body with graceful natural silk fall.
• **Custom Dyeing & Orders**: Available in royal maroon, peacock blue, and emerald green straight from Salem dye-houses.`,
      matchedProducts: matched.length > 0 ? matched : INITIAL_PRODUCTS.filter((p) => p.department === "Fabrics"),
    };
  }

  // 3. Dress Materials & Salwar Suits
  if (q.includes("dress") || q.includes("salwar") || q.includes("suit") || q.includes("unstitched") || q.includes("churidar")) {
    const matched = INITIAL_PRODUCTS.filter((p) => p.department === "Dress Materials");
    return {
      reply: `**Vanakkam!** 🙏 Welcome to our **Artisan Dress Materials Collection**:

• **Complete 3-Piece Ensemble**:
  - **Top**: 2.5 meters of soft silk with delicate buttas and embroidered neckline.
  - **Bottom**: 2.0 meters of smooth santoon/cotton blend for comfortable daily or festive wear.
  - **Dupatta**: Full 2.25-meter woven electronic jacquard dupatta with shimmering golden borders.
• **Direct Weaver Price**: Just **₹999** (retail MRP: ₹2,499).
• **Occasions**: Perfect for family functions, Diwali celebrations, temple poojas, and office ethnic days.`,
      matchedProducts: matched.length > 0 ? matched : INITIAL_PRODUCTS.filter((p) => p.department === "Dress Materials"),
    };
  }

  // 4. Temple Wedding / Bridal Sarees
  if (q.includes("wedding") || q.includes("temple") || q.includes("bridal") || q.includes("muhurtham") || q.includes("grand")) {
    const matched = INITIAL_PRODUCTS.filter((p) => p.department === "Sarees" && (p.isFeatured || p.category.includes("Bridal") || p.category.includes("Soft Silk")));
    return {
      reply: `**Vanakkam!** 🙏 For sacred **Temple Weddings and Muhurthams**, our master weavers recommend:

1. **Grand Brocade Bridal Silk Saree (₹749)**:
   - High-density electronic jacquard golden zari borders engineered for sanctum rituals.
   - Rich contrast graphic pallu with traditional zari jaal.
2. **Shining Soft Silk Saree (₹599)**:
   - Feather-light 580g drape with rich golden buttas that catch warm temple oil lamps.
   - Ultra-comfortable for extended 5-hour marriage ceremonies.
3. **Purity Assurance**:
   - Every weave comes with a matching 0.8m running contrast blouse piece.
   - 100% direct from Salem looms with zero retail intermediary markup.

We also offer live **WhatsApp Video Calls (+91 93600 21627)** so you can inspect the zari shine in natural light before ordering!`,
      matchedProducts: matched.slice(0, 2),
    };
  }

  // 5. 3D Embossed Karizma or Kolam Silk
  if (q.includes("karizma") || q.includes("3d") || q.includes("kolam") || q.includes("emboss")) {
    const matched = INITIAL_PRODUCTS.filter((p) => p.category.includes("Karizma") || p.category.includes("Kolam"));
    return {
      reply: `**Vanakkam!** 🙏 Here is the craft story behind our **3D Embossed Karizma & Kolam Weaves**:

• **The Innovation**: Woven on advanced electronic jacquards using **80's warp combed yarns** interwoven with metallic copper and silver buttas.
• **The 3D Texture**: The relief patterns are embossed during the weaving cycle itself—not printed—so the texture never fades or flattens after washing.
• **Kolam Geometry**: Inspired by auspicious Tamil doorstep kolams, bringing sacred geometry and good fortune to your wardrobe.
• **Weight & Care**: Weighs only **600 grams**. Crease-resistant and easy to pleat within 2 minutes.

Direct loom price: **₹649 – ₹699** (MRP: ₹1,999).`,
      matchedProducts: matched.slice(0, 2),
    };
  }

  // Default General Assistance across all departments
  const matched = INITIAL_PRODUCTS.filter((p) => p.isFeatured || p.isBestSeller).slice(0, 2);
  return {
    reply: `**Vanakkam!** 🙏 I am **Raja AI**, master loom advisor for Raja Textile, Elampillai, Salem.

We are direct loom producers offering complete textile collections:
• **Handloom Sarees**: 3D Embossed Karizma, Vintage Kolam, and Soft Silks (₹599–₹749)
• **Men's Traditional Wear**: Pure Silk Double Dhotis with Mayilkan Zari Borders (₹799)
• **Continuous Fabrics**: Mulberry Raw Silk Running Yardage sold by the meter (₹480/m)
• **Dress Materials**: 3-piece unstitched salwar suits with jacquard dupattas (₹999)
• **Home Furnishings**: Silk jacquard cushion covers and table runners

✨ **Loom Guarantees**:
- Free Insured Delivery across India on orders above ₹999
- Direct weaver pricing with zero retail markup
- WhatsApp live video viewing available at **+91 93600 21627**

How may I assist your wardrobe or occasion today?`,
    matchedProducts: matched,
  };
}

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Messages array is required" }, { status: 400 });
    }

    const lastUserMessage = messages.filter((m: any) => m.role === "user").pop()?.content || "";

    const apiKey = process.env.GROQ_API_KEY;

    // Fast-path: If Groq key exists, attempt calling modern supported Groq models
    if (apiKey && apiKey.startsWith("gsk_")) {
      const groqMessages = [
        { role: "system", content: SYSTEM_PROMPT },
        ...messages.slice(-6).map((m: any) => ({
          role: m.role === "assistant" ? "assistant" : "user",
          content: m.content,
        })),
      ];

      const candidateModels = [
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
        "mixtral-8x7b-32768",
        "gemma2-9b-it",
      ];

      for (const model of candidateModels) {
        try {
          const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              model,
              messages: groqMessages,
              temperature: 0.65,
              max_tokens: 600,
            }),
          });

          if (response.ok) {
            const data = await response.json();
            if (data.choices && data.choices[0]?.message?.content) {
              const reply = data.choices[0].message.content.trim();
              const matchedProducts = INITIAL_PRODUCTS.filter((prod) => {
                const lowerReply = reply.toLowerCase();
                const lowerName = prod.name.toLowerCase();
                const lowerCat = prod.category.toLowerCase();
                return (
                  lowerReply.includes(lowerName.slice(0, 14)) ||
                  lowerReply.includes(lowerCat) ||
                  (lowerReply.includes("karizma") && prod.category === "Karizma Silk") ||
                  (lowerReply.includes("dhoti") && prod.department === "Garments")
                );
              }).slice(0, 2);

              return NextResponse.json({
                success: true,
                reply,
                suggestedProducts: matchedProducts,
              });
            }
          }
        } catch {
          // try next model or fallback
        }
      }
    }

    // High-precision Master Weaver Knowledge Engine Fallback
    const { reply, matchedProducts } = generateKnowledgeReply(lastUserMessage);

    return NextResponse.json({
      success: true,
      reply,
      suggestedProducts: matchedProducts,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to process advisor request" },
      { status: 500 }
    );
  }
}
