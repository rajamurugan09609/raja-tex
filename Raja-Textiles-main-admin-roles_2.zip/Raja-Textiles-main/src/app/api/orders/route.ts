import { NextRequest, NextResponse } from "next/server";
import { getOrders, saveOrder } from "@/lib/db";
import { Order } from "@/types";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const email = searchParams.get("email")?.toLowerCase();
    const userId = searchParams.get("userId");

    const allOrders = await getOrders();

    if (!email && !userId) {
      // For general customer queries, do not dump all customer orders without identifier
      return NextResponse.json({
        success: true,
        orders: [],
      });
    }

    const filtered = allOrders.filter((ord: Order) => {
      const matchEmail = email && ord.customer?.email?.toLowerCase() === email;
      const matchUserId = userId && (ord as any).userId === userId;
      return matchEmail || matchUserId;
    });

    return NextResponse.json({ success: true, count: filtered.length, orders: filtered });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to retrieve orders" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body.items || !body.customer) {
      return NextResponse.json(
        { error: "Invalid order payload. Customer and items are required." },
        { status: 400 }
      );
    }

    const saved = await saveOrder(body);
    return NextResponse.json({ success: true, order: saved });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to place order" },
      { status: 500 }
    );
  }
}
