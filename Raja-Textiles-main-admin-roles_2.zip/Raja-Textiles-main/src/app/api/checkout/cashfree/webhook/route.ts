import { NextRequest, NextResponse } from "next/server";
import { updateOrderStatus, getOrderById } from "@/lib/db";

// Set to keep track of processed event IDs to prevent duplicate webhook replays
const processedEventIds = new Set<string>();

export async function POST(req: NextRequest) {
  try {
    const rawBody = await req.text();
    const _signature = req.headers.get("x-webhook-signature");
    const _timestamp = req.headers.get("x-webhook-timestamp");

    let eventData: any;
    try {
      eventData = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
    }

    const eventId = eventData?.event_time || `${eventData?.type}_${eventData?.data?.order?.order_id}`;
    if (processedEventIds.has(eventId)) {
      return NextResponse.json({ status: "already_processed" });
    }

    const orderId = eventData?.data?.order?.order_id;
    const paymentStatus = eventData?.data?.payment?.payment_status;

    if (orderId && paymentStatus === "SUCCESS") {
      const order = await getOrderById(orderId);
      if (order) {
        await updateOrderStatus(
          order.id,
          "confirmed",
          "verified",
          eventData?.data?.payment?.cf_payment_id
        );
      }
    }

    // Retain up to 1000 events
    if (processedEventIds.size > 1000) {
      processedEventIds.clear();
    }
    processedEventIds.add(eventId);

    return NextResponse.json({ received: true });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Webhook error" },
      { status: 500 }
    );
  }
}
