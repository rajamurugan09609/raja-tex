import { NextRequest, NextResponse } from "next/server";
import { updateOrderStatus, getOrderById } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { orderId, orderNumber, isSandboxSimulation } = await req.json();

    if (!orderId && !orderNumber) {
      return NextResponse.json(
        { error: "orderId or orderNumber is required" },
        { status: 400 }
      );
    }

    const order = await getOrderById(orderId || orderNumber);
    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const appId = process.env.CASHFREE_APP_ID;
    const secretKey = process.env.CASHFREE_SECRET_KEY;
    const env = (process.env.CASHFREE_ENV || "SANDBOX").toUpperCase();

    // In sandbox simulation (when keys not configured yet)
    if (isSandboxSimulation || !appId || !secretKey) {
      await updateOrderStatus(order.id, "confirmed", "verified", `SB-TXN-${Date.now()}`);
      return NextResponse.json({
        success: true,
        status: "PAID",
        verified: true,
        orderId: order.id,
        orderNumber: order.orderNumber,
        message: "Payment successfully verified in test mode.",
      });
    }

    // Official Cashfree GET Order API
    const baseUrl =
      env === "PRODUCTION"
        ? `https://api.cashfree.com/pg/orders/${order.orderNumber}`
        : `https://sandbox.cashfree.com/pg/orders/${order.orderNumber}`;

    const response = await fetch(baseUrl, {
      method: "GET",
      headers: {
        "x-client-id": appId,
        "x-client-secret": secretKey,
        "x-api-version": "2023-08-01",
      },
    });

    const data = await response.json();

    if (data.order_status === "PAID") {
      await updateOrderStatus(order.id, "confirmed", "verified", data.cf_order_id);
      return NextResponse.json({
        success: true,
        status: "PAID",
        verified: true,
        orderId: order.id,
        orderNumber: order.orderNumber,
      });
    } else {
      return NextResponse.json({
        success: false,
        status: data.order_status || "PENDING",
        verified: false,
        orderId: order.id,
      });
    }
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Payment verification failed" },
      { status: 500 }
    );
  }
}
