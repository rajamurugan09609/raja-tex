import { NextRequest, NextResponse } from "next/server";
import { getOrderById } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { orderId } = await req.json();
    if (!orderId) {
      return NextResponse.json({ error: "orderId is required" }, { status: 400 });
    }

    const order = await getOrderById(orderId);
    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const appId = process.env.CASHFREE_APP_ID;
    const secretKey = process.env.CASHFREE_SECRET_KEY;
    const env = (process.env.CASHFREE_ENV || "SANDBOX").toUpperCase();

    // If Cashfree credentials are not yet configured by the store owner
    if (!appId || !secretKey) {
      return NextResponse.json({
        success: true,
        isConfigured: false,
        sandboxSimulation: true,
        orderId: order.id,
        orderNumber: order.orderNumber,
        amount: order.pricing.total,
        message:
          "Cashfree API keys are pending configuration in .env.local. You can test using Sandbox or Direct WhatsApp / COD.",
      });
    }

    const baseUrl =
      env === "PRODUCTION"
        ? "https://api.cashfree.com/pg/orders"
        : "https://sandbox.cashfree.com/pg/orders";

    const cleanPhone = order.customer.phone.replace(/[^0-9]/g, "").slice(-10);
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

    const payload = {
      order_id: order.orderNumber,
      order_amount: order.pricing.total,
      order_currency: "INR",
      customer_details: {
        customer_id: `cust_${cleanPhone}`,
        customer_name: order.customer.fullName,
        customer_phone: cleanPhone,
        customer_email: order.customer.email || "care@rajatextile.in",
      },
      order_meta: {
        return_url: `${siteUrl}/checkout/cashfree-return?order_id=${order.orderNumber}`,
        notify_url: `${siteUrl}/api/checkout/cashfree/webhook`,
      },
      order_note: `Raja Textile Order ${order.orderNumber} (Elampillai, Salem)`,
    };

    const response = await fetch(baseUrl, {
      method: "POST",
      headers: {
        "x-client-id": appId,
        "x-client-secret": secretKey,
        "x-api-version": "2023-08-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      return NextResponse.json(
        { error: data.message || "Failed to create Cashfree order", details: data },
        { status: response.status }
      );
    }

    return NextResponse.json({
      success: true,
      isConfigured: true,
      paymentSessionId: data.payment_session_id,
      orderId: order.id,
      orderNumber: order.orderNumber,
      cfOrderId: data.cf_order_id,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Internal server error" },
      { status: 500 }
    );
  }
}
