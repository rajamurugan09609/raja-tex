import { NextRequest, NextResponse } from "next/server";
import { saveOrder, getProductById } from "@/lib/db";
import { Order, OrderItem, CustomerDetails, OrderPricing } from "@/types";
import { STORE_SETTINGS } from "@/data/products";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { customer, items, paymentMethod, couponCode, notes } = body;

    if (!customer || !customer.fullName || !customer.phone || !customer.address || !customer.pincode) {
      return NextResponse.json(
        { error: "Customer details and shipping address are required" },
        { status: 400 }
      );
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
    }

    // Server-side price and inventory validation to prevent client tampering
    let validatedSubtotal = 0;
    const validatedItems: OrderItem[] = [];

    for (const item of items) {
      const serverProduct = await getProductById(item.productId);
      if (!serverProduct) {
        return NextResponse.json(
          { error: `Product with id ${item.productId} was not found` },
          { status: 400 }
        );
      }

      const validatedPrice = serverProduct.price;
      const quantity = Math.max(1, Math.min(item.quantity || 1, serverProduct.stockCount || 50));
      const itemSubtotal = validatedPrice * quantity;
      validatedSubtotal += itemSubtotal;

      validatedItems.push({
        productId: serverProduct.id,
        name: serverProduct.name,
        image: serverProduct.images[0] || "",
        price: validatedPrice,
        quantity,
        selectedColor: item.selectedColor || "Standard",
        subtotal: itemSubtotal,
      });
    }

    // Calculate server-side discount
    let discount = 0;
    if (couponCode) {
      const upper = couponCode.trim().toUpperCase();
      if (upper === "FESTIVE10") {
        discount = Math.round(validatedSubtotal * 0.1);
      } else if (upper === "WEAVER100" && validatedSubtotal >= 600) {
        discount = 100;
      } else if (upper === "DIWALI50" && validatedSubtotal >= 1000) {
        discount = Math.round(validatedSubtotal * 0.15);
      }
    }

    const shipping =
      validatedSubtotal >= STORE_SETTINGS.freeShippingThreshold ? 0 : STORE_SETTINGS.shippingFee;
    const total = Math.max(0, validatedSubtotal - discount + shipping);

    const pricing: OrderPricing = {
      subtotal: validatedSubtotal,
      discount,
      couponCode: couponCode || undefined,
      shipping,
      tax: 0,
      total,
    };

    // Generate unique order reference number (e.g., RT-2026-XXXXX)
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const orderNumber = `RT-2026-${randomSuffix}`;
    const orderId = `order-${Date.now()}-${randomSuffix}`;

    const newOrder: Order = {
      id: orderId,
      orderNumber,
      userId: body.userId || undefined,
      customer: customer as CustomerDetails,
      items: validatedItems,
      pricing,
      paymentMethod: paymentMethod || "cod",
      paymentStatus: paymentMethod === "cod" ? "pending" : "pending",
      orderStatus: "placed",
      notes: notes || "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = await saveOrder(newOrder);

    return NextResponse.json({
      success: true,
      order: saved,
      orderId: saved.id,
      orderNumber: saved.orderNumber,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to create order" },
      { status: 500 }
    );
  }
}
