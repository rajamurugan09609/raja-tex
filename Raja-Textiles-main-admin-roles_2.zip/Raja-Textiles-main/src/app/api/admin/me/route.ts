import { NextRequest, NextResponse } from "next/server";
import { requirePermission } from "@/lib/auth-server";

export const dynamic = "force-dynamic";
export const revalidate = 0;

/** Tells the logged-in user whether they are an admin, which role, and what they may do. */
export async function GET(req: NextRequest) {
  const guard = await requirePermission(req);
  if (!guard.ok) return guard.response;
  const { auth } = guard;
  return NextResponse.json({
    success: true,
    email: auth.email,
    role: auth.role,
    permissions: auth.permissions,
  });
}
