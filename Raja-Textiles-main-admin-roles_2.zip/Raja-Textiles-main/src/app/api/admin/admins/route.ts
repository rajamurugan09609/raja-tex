import { NextRequest, NextResponse } from "next/server";
import { requirePermission, getOwnerEmails } from "@/lib/auth-server";
import { getAdmins, saveAdmin, deleteAdminByEmail } from "@/lib/db";
import { supabaseAdmin, hasServiceRoleKey } from "@/lib/supabase";
import type { AdminRole, AdminUser } from "@/types";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Only the Main Admin ("admins:manage") may use anything in this file.

export async function GET(req: NextRequest) {
  const guard = await requirePermission(req, "admins:manage");
  if (!guard.ok) return guard.response;

  try {
    const dbAdmins = await getAdmins();
    const envOwners: AdminUser[] = getOwnerEmails().map((email) => ({
      id: `env-${email}`,
      email,
      fullName: "Store Owner",
      role: "main_admin",
      createdAt: "",
      isEnvOwner: true,
    }));
    const dbEmails = new Set(dbAdmins.map((a) => a.email));
    const admins = [...envOwners.filter((o) => !dbEmails.has(o.email)), ...dbAdmins];
    return NextResponse.json({ success: true, admins });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Failed to load admins" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const guard = await requirePermission(req, "admins:manage");
  if (!guard.ok) return guard.response;
  const { auth } = guard;

  if (!supabaseAdmin || !hasServiceRoleKey) {
    return NextResponse.json(
      { error: "SUPABASE_SECRET_KEY is not set on the server, so admin accounts cannot be created." },
      { status: 500 }
    );
  }

  try {
    const body = await req.json();
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    const fullName = String(body.fullName || "").trim();
    const role: AdminRole = body.role === "main_admin" ? "main_admin" : "admin";

    if (!EMAIL_RE.test(email)) {
      return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
    }
    if (getOwnerEmails().includes(email)) {
      return NextResponse.json({ error: "This email is already a Main Admin (owner)." }, { status: 400 });
    }

    // 1) Find or create the login account
    let userId: string | null = null;
    let createdNewAccount = false;

    const { data: existingProfile } = await supabaseAdmin
      .from("user_profiles")
      .select("id")
      .ilike("email", email)
      .maybeSingle();

    if (existingProfile?.id) {
      userId = existingProfile.id;
    } else {
      if (password.length < 8) {
        return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
      }
      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { full_name: fullName },
      });
      if (error || !data?.user) {
        return NextResponse.json(
          { error: error?.message || "Could not create the login account." },
          { status: 400 }
        );
      }
      userId = data.user.id;
      createdNewAccount = true;
    }

    // 2) Give the account its admin role
    const admin = await saveAdmin({
      userId: userId!,
      email,
      fullName: fullName || email.split("@")[0],
      role,
      createdBy: auth.email,
    });

    return NextResponse.json({
      success: true,
      admin,
      createdNewAccount,
      message: createdNewAccount
        ? "New admin account created."
        : "This email already had an account. It has been made an admin (its existing password still works).",
    });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Failed to create admin" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const guard = await requirePermission(req, "admins:manage");
  if (!guard.ok) return guard.response;
  const { auth } = guard;

  try {
    const email = (req.nextUrl.searchParams.get("email") || "").trim().toLowerCase();
    if (!email) {
      return NextResponse.json({ error: "Admin email is required." }, { status: 400 });
    }
    if (getOwnerEmails().includes(email)) {
      return NextResponse.json(
        { error: "Owner accounts set in OWNER_EMAILS cannot be removed here." },
        { status: 400 }
      );
    }
    if (email === auth.email) {
      return NextResponse.json({ error: "You cannot remove your own admin access." }, { status: 400 });
    }

    // Removes admin access only. The person's normal customer login stays.
    await deleteAdminByEmail(email);
    return NextResponse.json({ success: true, email });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Failed to remove admin" }, { status: 500 });
  }
}
