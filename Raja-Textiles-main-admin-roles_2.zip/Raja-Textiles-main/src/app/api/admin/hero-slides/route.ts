import { NextRequest, NextResponse } from "next/server";
import { getHeroSlides, saveHeroSlide, updateHeroSlidesOrder, deleteHeroSlide } from "@/lib/db";
import { requirePermission } from "@/lib/auth-server";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(_req: NextRequest) {
  try {
    const slides = await getHeroSlides();
    return NextResponse.json({ success: true, slides });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to fetch hero slides" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  const guard = await requirePermission(req, "hero:manage");
  if (!guard.ok) return guard.response;

  try {
    const body = await req.json();

    // Check if reordering
    if (body.action === "reorder" && Array.isArray(body.orderedIds)) {
      const slides = await updateHeroSlidesOrder(body.orderedIds);
      return NextResponse.json({ success: true, slides });
    }

    // Otherwise save single slide
    const slide = await saveHeroSlide(body);
    return NextResponse.json({ success: true, slide });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to save hero slide" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  const guard = await requirePermission(req, "hero:manage");
  if (!guard.ok) return guard.response;

  try {
    const id = req.nextUrl.searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "Slide ID required" }, { status: 400 });
    }

    await deleteHeroSlide(id);
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to delete hero slide" },
      { status: 500 }
    );
  }
}
