import { NextRequest, NextResponse } from "next/server";
import { getOrders, updateOrderStatus } from "@/lib/db";
import { requirePermission } from "@/lib/auth-server";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(req: NextRequest) {
  const guard = await requirePermission(req, "orders:read");
  if (!guard.ok) return guard.response;

  try {
    const orders = await getOrders();
    return NextResponse.json({ success: true, orders });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to fetch orders" },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  const guard = await requirePermission(req, "orders:update");
  if (!guard.ok) return guard.response;

  try {
    const { orderId, orderStatus, paymentStatus, trackingNumber } = await req.json();
    if (!orderId || !orderStatus) {
      return NextResponse.json(
        { error: "orderId and orderStatus are required" },
        { status: 400 }
      );
    }

    const updated = await updateOrderStatus(orderId, orderStatus, paymentStatus, trackingNumber);
    if (!updated) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, order: updated });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to update order" },
      { status: 500 }
    );
  }
}
