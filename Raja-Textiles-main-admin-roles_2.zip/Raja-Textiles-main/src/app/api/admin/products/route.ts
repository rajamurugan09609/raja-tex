import { NextRequest, NextResponse } from "next/server";
import { getProducts, saveProduct, getProductById } from "@/lib/db";
import { requirePermission } from "@/lib/auth-server";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET() {
  try {
    const products = await getProducts();
    return NextResponse.json({ success: true, count: products.length, products });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to fetch products" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  // Any admin may reach this route; what they may do is decided below.
  const guard = await requirePermission(req);
  if (!guard.ok) return guard.response;
  const { auth } = guard;

  try {
    const body = await req.json();
    if (!body.name || !body.price) {
      return NextResponse.json(
        { error: "Name and Price are required fields" },
        { status: 400 }
      );
    }

    // This route is used for BOTH "add new" and "update existing" (upsert by id).
    // Work out which one it is on the server, never trust the client.
    const existing = body.id ? await getProductById(String(body.id)) : null;

    if (existing) {
      if (!auth.permissions.includes("product:update")) {
        return NextResponse.json(
          { error: "Normal Admin can only add new products. Only the Main Admin can edit existing products." },
          { status: 403 }
        );
      }
    } else {
      if (!auth.permissions.includes("product:create")) {
        return NextResponse.json(
          { error: "You do not have permission to add products." },
          { status: 403 }
        );
      }
      // A Normal Admin adding a product: server picks the id, and cannot
      // feature it on the home page / hero (that is a Main Admin decision).
      if (!auth.permissions.includes("product:update")) {
        delete body.id;
        body.isFeatured = false;
        body.isBestSeller = false;
      }
    }

    const saved = await saveProduct(body);
    return NextResponse.json({ success: true, product: saved });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to save product" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  const guard = await requirePermission(req, "product:delete");
  if (!guard.ok) return guard.response;

  try {
    const url = new URL(req.url);
    let id = url.searchParams.get("id");
    if (!id) {
      try {
        const body = await req.json();
        id = body?.id;
      } catch {
        // no body
      }
    }

    if (!id) {
      return NextResponse.json(
        { error: "Product ID is required for deletion" },
        { status: 400 }
      );
    }

    const { deleteProduct } = await import("@/lib/db");
    const success = await deleteProduct(id);
    return NextResponse.json({ success: true, id });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to delete product" },
      { status: 500 }
    );
  }
}
