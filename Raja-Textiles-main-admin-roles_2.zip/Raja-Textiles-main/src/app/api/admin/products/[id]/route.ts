import { NextRequest, NextResponse } from "next/server";
import { saveProduct, deleteProduct, getProductById } from "@/lib/db";
import { requirePermission } from "@/lib/auth-server";

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const guard = await requirePermission(req, "product:update");
  if (!guard.ok) return guard.response;

  try {
    const existing = await getProductById(params.id);
    if (!existing) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    const body = await req.json();
    const updated = await saveProduct({ ...existing, ...body, id: params.id });
    return NextResponse.json({ success: true, product: updated });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to update product" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const guard = await requirePermission(req, "product:delete");
  if (!guard.ok) return guard.response;

  try {
    const success = await deleteProduct(params.id);
    return NextResponse.json({ success: true, id: params.id });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to delete product" },
      { status: 500 }
    );
  }
}
