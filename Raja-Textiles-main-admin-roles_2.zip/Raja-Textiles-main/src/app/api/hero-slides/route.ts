import { NextResponse } from "next/server";
import { getHeroSlides } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const allSlides = await getHeroSlides();
    const activeSlides = allSlides.filter((s) => s.isActive);
    return NextResponse.json({ success: true, slides: activeSlides });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || "Failed to fetch hero slides" },
      { status: 500 }
    );
  }
}
