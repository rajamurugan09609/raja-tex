import React from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import ProductCard from "@/components/ProductCard";
import { CATEGORIES } from "@/data/products";
import { getProducts } from "@/lib/db";

export const dynamic = "force-dynamic";
export const revalidate = 0;

interface CategoryPageProps {
  params: { slug: string };
}

export function generateStaticParams() {
  return CATEGORIES.map((cat) => ({
    slug: cat.slug,
  }));
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const category = CATEGORIES.find((c) => c.slug === params.slug);

  if (!category) {
    notFound();
  }

  const allProducts = await getProducts();

  // Filter products by category name or slug
  const products = allProducts.filter(
    (p) =>
      p.category.toLowerCase().includes(category.name.toLowerCase().split(" ")[0]) ||
      category.name.toLowerCase().includes(p.category.toLowerCase())
  );

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="text-xs text-raja-ink-muted mb-4 flex items-center gap-2">
          <Link href="/" className="hover:text-raja-maroon">Home</Link>
          <span>/</span>
          <Link href="/products" className="hover:text-raja-maroon">Sarees</Link>
          <span>/</span>
          <span className="text-raja-maroon font-medium">{category.name}</span>
        </nav>

        {/* Category Hero Banner */}
        <div className="bg-white rounded-2xl border border-raja-ink-border overflow-hidden mb-10 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-12 items-center">
            <div className="md:col-span-8 p-6 sm:p-10 space-y-3">
              <span className="text-xs font-semibold uppercase tracking-[0.25em] text-raja-gold">
                Master Weave Collection
              </span>
              <div className="flex items-baseline gap-3">
                <h1 className="font-serif text-3xl sm:text-4xl font-bold text-raja-maroon">
                  {category.name}
                </h1>
                {category.tamilName && (
                  <span className="font-serif text-lg text-raja-gold-dark font-medium">
                    ({category.tamilName})
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-raja-ink-soft leading-relaxed max-w-xl">
                {category.description}
              </p>
              <p className="text-xs text-raja-ink-muted font-medium pt-2">
                Showing {products.length} verified handloom styles
              </p>
            </div>

            <div className="md:col-span-4 h-48 md:h-full bg-raja-ivory overflow-hidden">
              <img
                src={category.image}
                alt={category.name}
                className="w-full h-full object-cover object-center"
              />
            </div>
          </div>
        </div>

        {/* Product Grid */}
        {products.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center border border-raja-ink-border space-y-4">
            <p className="font-serif text-xl font-bold text-raja-ink">
              New weaves arriving soon for {category.name}
            </p>
            <p className="text-xs text-raja-ink-soft">
              Our weavers are preparing fresh batches on the Elampillai looms.
            </p>
            <Link
              href="/products"
              className="inline-block px-6 py-2.5 rounded bg-raja-maroon text-white text-xs font-semibold"
            >
              View All Available Sarees
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
