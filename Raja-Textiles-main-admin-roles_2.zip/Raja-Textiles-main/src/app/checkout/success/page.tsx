"use client";

import React, { useEffect, useState, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  CheckCircle2,
  Printer,
  MessageCircle,
  ArrowRight,
  Loader2,
} from "lucide-react";
import { Order } from "@/types";
import { STORE_SETTINGS } from "@/data/products";

function CheckoutSuccessContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get("orderId");

  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    async function fetchOrder() {
      if (!orderId) {
        return;
      }
      try {
        const res = await fetch(`/api/orders/${orderId}`);
        const data = await res.json();
        if (data.success && data.order) {
          setOrder(data.order);
        }
      } catch {
        // ignore
      }
    }
    fetchOrder();
  }, [orderId]);

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsAppConfirm = () => {
    if (!order) return;
    const msg = encodeURIComponent(
      `Vanakkam Raja Textile! My order *${order.orderNumber}* has been placed. Please confirm dispatch details from Elampillai.`
    );
    window.open(`https://wa.me/${STORE_SETTINGS.whatsapp}?text=${msg}`, "_blank");
  };

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Success Header Card */}
        <div className="bg-white rounded-2xl border border-raja-ink-border p-8 md:p-10 shadow-sm text-center space-y-4 mb-8">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-raja-gold">
            Order Confirmed & Received
          </span>

          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-raja-maroon">
            Nandri! Your Handloom Weaves are Booked.
          </h1>

          <p className="text-xs sm:text-sm text-raja-ink-soft max-w-lg mx-auto leading-relaxed">
            We have registered your order with our master weavers in Elampillai, Salem.
            Your sarees are being carefully inspected and prepared for safe courier dispatch.
          </p>

          <div className="inline-block bg-raja-maroon-subtle px-4 py-2 rounded-lg border border-raja-maroon/20">
            <span className="text-xs text-raja-ink-soft">Order Reference Number: </span>
            <strong className="text-sm font-bold text-raja-maroon tracking-wider">
              {order?.orderNumber || orderId || "RT-2026-PROCESSING"}
            </strong>
          </div>
        </div>

        {/* Fulfillment Timeline */}
        <div className="bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-8 shadow-sm mb-8 space-y-6">
          <h2 className="font-serif text-base sm:text-lg font-bold text-raja-ink">
            Dispatch & Delivery Roadmap
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 relative">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                ✓
              </div>
              <div>
                <p className="text-xs font-bold text-raja-ink">Order Placed</p>
                <p className="text-[11px] text-raja-ink-muted">Recorded in Salem</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-raja-maroon text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                2
              </div>
              <div>
                <p className="text-xs font-bold text-raja-ink">Artisan Quality Check</p>
                <p className="text-[11px] text-raja-ink-muted">Manual inspection</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-raja-ivory text-raja-ink border border-raja-ink-border flex items-center justify-center text-xs font-bold flex-shrink-0">
                3
              </div>
              <div>
                <p className="text-xs font-bold text-raja-ink">Express Dispatch</p>
                <p className="text-[11px] text-raja-ink-muted">Pan-India Courier</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-raja-ivory text-raja-ink border border-raja-ink-border flex items-center justify-center text-xs font-bold flex-shrink-0">
                4
              </div>
              <div>
                <p className="text-xs font-bold text-raja-ink">Doorstep Delivery</p>
                <p className="text-[11px] text-raja-ink-muted">Safe arrival</p>
              </div>
            </div>
          </div>
        </div>

        {/* Order Details & Summary Card */}
        {order && (
          <div className="bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-8 shadow-sm mb-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-raja-ink-border gap-2">
              <div>
                <h3 className="font-serif text-lg font-bold text-raja-ink">
                  Invoice & Items Breakdown
                </h3>
                <p className="text-xs text-raja-ink-muted">
                  Placed on {new Date(order.createdAt).toLocaleDateString("en-IN", { dateStyle: "long" })}
                </p>
              </div>

              <button
                onClick={handlePrint}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded border border-raja-ink-border hover:bg-raja-ivory text-xs font-semibold text-raja-ink transition-colors self-start sm:self-auto"
              >
                <Printer className="w-4 h-4 text-raja-gold" />
                <span>Print Invoice</span>
              </button>
            </div>

            {/* Items */}
            <div className="space-y-4">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex gap-4 items-center text-xs">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-20 object-cover rounded bg-raja-ivory flex-shrink-0"
                  />
                  <div className="flex-1">
                    <h4 className="font-serif text-sm font-semibold text-raja-ink">
                      {item.name}
                    </h4>
                    <p className="text-raja-ink-muted text-[11px]">
                      Color: {item.selectedColor} • Qty: {item.quantity}
                    </p>
                    <p className="text-raja-ink-soft text-[11px] mt-0.5">
                      Price per unit: ₹{item.price.toLocaleString("en-IN")}
                    </p>
                  </div>
                  <div className="text-right font-bold text-raja-maroon text-sm">
                    ₹{item.subtotal.toLocaleString("en-IN")}
                  </div>
                </div>
              ))}
            </div>

            {/* Price Calculations */}
            <div className="pt-4 border-t border-raja-ink-border space-y-2 text-xs text-raja-ink-soft max-w-sm ml-auto">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-raja-ink">
                  ₹{order.pricing.subtotal.toLocaleString("en-IN")}
                </span>
              </div>
              {order.pricing.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Discount</span>
                  <span className="font-semibold">
                    -₹{order.pricing.discount.toLocaleString("en-IN")}
                  </span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Delivery</span>
                <span className="font-semibold text-raja-ink">
                  {order.pricing.shipping === 0 ? "FREE" : `₹${order.pricing.shipping}`}
                </span>
              </div>
              <div className="pt-2 border-t border-raja-ink-border flex justify-between text-base font-bold text-raja-ink">
                <span>Grand Total</span>
                <span className="text-raja-maroon">
                  ₹{order.pricing.total.toLocaleString("en-IN")}
                </span>
              </div>
            </div>

            {/* Delivery address */}
            <div className="pt-4 border-t border-raja-ink-border grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <p className="font-bold text-raja-ink mb-1">Delivering To:</p>
                <p className="text-raja-ink-soft leading-relaxed">
                  <strong>{order.customer.fullName}</strong>
                  <br />
                  {order.customer.address}
                  {order.customer.landmark ? `, ${order.customer.landmark}` : ""}
                  <br />
                  {order.customer.city}, {order.customer.state} — {order.customer.pincode}
                  <br />
                  Phone: {order.customer.phone}
                </p>
              </div>

              <div>
                <p className="font-bold text-raja-ink mb-1">Payment Method & Status:</p>
                <p className="text-raja-ink-soft leading-relaxed uppercase">
                  <strong>{order.paymentMethod}</strong> •{" "}
                  <span
                    className={`font-semibold ${
                      order.paymentStatus === "verified"
                        ? "text-emerald-700"
                        : "text-amber-700"
                    }`}
                  >
                    {order.paymentStatus}
                  </span>
                </p>
                {order.paymentReferenceId && (
                  <p className="text-[11px] text-raja-ink-muted mt-1">
                    Ref ID: {order.paymentReferenceId}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            type="button"
            onClick={handleWhatsAppConfirm}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded bg-[#25D366] hover:bg-[#20ba59] text-white font-semibold text-xs shadow-md transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Track Order on WhatsApp (+91 93600 21627)</span>
          </button>

          <Link
            href="/products"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded bg-raja-maroon hover:bg-raja-maroon-light text-white font-semibold text-xs shadow-md transition-colors"
          >
            <span>Continue Shopping</span>
            <ArrowRight className="w-4 h-4 text-raja-gold" />
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutSuccessPage() {
  return (
    <Suspense
      fallback={
        <div className="bg-raja-ivory min-h-screen py-20 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-raja-maroon" />
        </div>
      }
    >
      <CheckoutSuccessContent />
    </Suspense>
  );
}
