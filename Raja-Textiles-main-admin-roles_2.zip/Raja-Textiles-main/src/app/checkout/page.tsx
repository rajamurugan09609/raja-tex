"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ShieldCheck,
  CreditCard,
  MessageCircle,
  Truck,
  ArrowRight,
  Lock,
  ChevronLeft,
  AlertCircle,
} from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { CustomerDetails, PaymentMethod } from "@/types";
import { STORE_SETTINGS } from "@/data/products";

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, discount, shipping, total, couponCode, clearCart } = useCart();
  const { user, profile } = useAuth();

  const [customer, setCustomer] = useState<CustomerDetails>({
    fullName: "",
    phone: "",
    email: "",
    address: "",
    landmark: "",
    city: "Salem",
    state: "Tamil Nadu",
    pincode: "",
  });

  // Prefill details from authenticated user session & profile
  useEffect(() => {
    if (user || profile) {
      setCustomer((prev) => ({
        ...prev,
        fullName: prev.fullName || profile?.fullName || (user?.user_metadata as any)?.full_name || "",
        email: prev.email || user?.email || "",
        phone: prev.phone || profile?.phone || "",
        ...(profile?.addresses && profile.addresses.length > 0
          ? {
              address: prev.address || profile.addresses[0].addressLine1,
              city: prev.city || profile.addresses[0].city,
              state: prev.state || profile.addresses[0].state,
              pincode: prev.pincode || profile.addresses[0].pincode,
            }
          : {}),
      }));
    }
  }, [user, profile]);

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cashfree");
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (items.length === 0) {
    return (
      <div className="bg-raja-ivory min-h-screen py-16 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl border border-raja-ink-border p-10 max-w-md text-center space-y-4 shadow-sm">
          <h2 className="font-serif text-2xl font-bold text-raja-ink">
            Your shopping bag is empty
          </h2>
          <p className="text-xs text-raja-ink-soft">
            Please add your favorite sarees to your bag before proceeding to checkout.
          </p>
          <Link
            href="/products"
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded bg-raja-maroon text-white text-xs font-semibold hover:bg-raja-maroon-light transition-colors"
          >
            <span>Explore Sarees</span>
            <ArrowRight className="w-4 h-4 text-raja-gold" />
          </Link>
        </div>
      </div>
    );
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCustomer((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Form validations
    if (!customer.fullName.trim()) {
      setErrorMessage("Please enter your full name.");
      return;
    }
    if (!/^\d{10}$/.test(customer.phone.replace(/[^0-9]/g, "").slice(-10))) {
      setErrorMessage("Please enter a valid 10-digit mobile number.");
      return;
    }
    if (!customer.address.trim()) {
      setErrorMessage("Please provide your complete delivery street address.");
      return;
    }
    if (!/^\d{6}$/.test(customer.pincode.trim())) {
      setErrorMessage("Please provide a valid 6-digit Indian PIN code.");
      return;
    }

    setIsSubmitting(true);

    try {
      // Step 1: Create server-side order
      const orderRes = await fetch("/api/checkout/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user?.id,
          customer,
          items,
          paymentMethod,
          couponCode,
          notes,
        }),
      });

      const orderData = await orderRes.json();
      if (!orderRes.ok || !orderData.success) {
        throw new Error(orderData.error || "Failed to initiate order");
      }

      const { orderId, orderNumber } = orderData;

      // Step 2: Handle chosen payment method
      if (paymentMethod === "cashfree") {
        // Request Cashfree order session
        const cfRes = await fetch("/api/checkout/cashfree/create-order", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ orderId }),
        });

        const cfData = await cfRes.json();

        if (cfData.sandboxSimulation || !cfData.isConfigured) {
          // If keys are not configured yet, seamlessly verify test order
          await fetch("/api/checkout/cashfree/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ orderId, isSandboxSimulation: true }),
          });
          clearCart();
          router.push(`/checkout/success?orderId=${orderId}&mode=sandbox`);
          return;
        }

        // Live Cashfree redirect if session returned
        if (cfData.paymentSessionId) {
          clearCart();
          router.push(`/checkout/success?orderId=${orderId}&cfSession=${cfData.paymentSessionId}`);
          return;
        }
      } else if (paymentMethod === "whatsapp") {
        // Direct WhatsApp order workflow
        clearCart();
        let waText = `*Vanakkam Raja Textile!*\n\nI have placed an order on your website:\n` +
          `*Order No:* ${orderNumber}\n` +
          `*Customer:* ${customer.fullName} (${customer.phone})\n` +
          `*Delivery Address:* ${customer.address}, ${customer.city}, ${customer.state} - ${customer.pincode}\n\n` +
          `*Items:*\n`;

        items.forEach((it, i) => {
          waText += `${i + 1}. ${it.product.name} (${it.selectedColor}) x ${it.quantity} = ₹${it.product.price * it.quantity}\n`;
        });
        waText += `\n*Total Amount:* ₹${total}\n` +
          `Please provide your Google Pay / PhonePe / UPI QR details to confirm my order. Nandri!`;

        window.open(`https://wa.me/${STORE_SETTINGS.whatsapp}?text=${encodeURIComponent(waText)}`, "_blank");
        router.push(`/checkout/success?orderId=${orderId}&mode=whatsapp`);
        return;
      } else if (paymentMethod === "cod") {
        clearCart();
        router.push(`/checkout/success?orderId=${orderId}&mode=cod`);
        return;
      }
    } catch (err: any) {
      setErrorMessage(err?.message || "An unexpected error occurred during checkout.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Link
            href="/products"
            className="inline-flex items-center gap-1.5 text-xs text-raja-ink-muted hover:text-raja-maroon mb-2"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Back to Shopping</span>
          </Link>
          <h1 className="font-serif text-3xl font-bold text-raja-maroon">
            Secure Checkout
          </h1>
          <p className="text-xs sm:text-sm text-raja-ink-soft mt-1">
            Handcrafted sarees dispatched directly from Elampillai looms in Salem.
          </p>
        </div>

        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-3">
            <AlertCircle className="w-5 h-5 flex-shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmitOrder}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
            {/* Left Column: Customer & Delivery Details */}
            <div className="lg:col-span-7 space-y-6">
              {/* Step 1: Customer Details */}
              <div className="bg-white rounded-xl border border-raja-ink-border p-6 shadow-sm space-y-4">
                <div className="flex items-center gap-2 border-b border-raja-ink-border/80 pb-3">
                  <span className="w-6 h-6 rounded-full bg-raja-maroon text-white text-xs font-bold flex items-center justify-center">
                    1
                  </span>
                  <h2 className="font-serif text-lg font-bold text-raja-ink">
                    Customer Information
                  </h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block font-semibold text-raja-ink mb-1">
                      Full Name <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="fullName"
                      required
                      value={customer.fullName}
                      onChange={handleInputChange}
                      placeholder="e.g. Sangeetha Ramanathan"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-raja-ink mb-1">
                      Mobile Number <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      maxLength={10}
                      value={customer.phone}
                      onChange={handleInputChange}
                      placeholder="10-digit mobile number"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-raja-ink mb-1">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={customer.email}
                      onChange={handleInputChange}
                      placeholder="For invoice and tracking notifications"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Step 2: Shipping Address */}
              <div className="bg-white rounded-xl border border-raja-ink-border p-6 shadow-sm space-y-4">
                <div className="flex items-center gap-2 border-b border-raja-ink-border/80 pb-3">
                  <span className="w-6 h-6 rounded-full bg-raja-maroon text-white text-xs font-bold flex items-center justify-center">
                    2
                  </span>
                  <h2 className="font-serif text-lg font-bold text-raja-ink">
                    Pan-India Delivery Address
                  </h2>
                </div>

                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block font-semibold text-raja-ink mb-1">
                      Door No, Building, Street / Area <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="address"
                      required
                      value={customer.address}
                      onChange={handleInputChange}
                      placeholder="e.g. 42, Weavers Colony, Gandhi Road"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-semibold text-raja-ink mb-1">
                        PIN Code <span className="text-red-600">*</span>
                      </label>
                      <input
                        type="text"
                        name="pincode"
                        required
                        maxLength={6}
                        value={customer.pincode}
                        onChange={handleInputChange}
                        placeholder="637502"
                        className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-raja-ink mb-1">
                        City / Town <span className="text-red-600">*</span>
                      </label>
                      <input
                        type="text"
                        name="city"
                        required
                        value={customer.city}
                        onChange={handleInputChange}
                        className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-raja-ink mb-1">
                        State <span className="text-red-600">*</span>
                      </label>
                      <input
                        type="text"
                        name="state"
                        required
                        value={customer.state}
                        onChange={handleInputChange}
                        className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-raja-ink mb-1">
                      Landmark (Optional)
                    </label>
                    <input
                      type="text"
                      name="landmark"
                      value={customer.landmark || ""}
                      onChange={handleInputChange}
                      placeholder="Nearby temple, school, or landmark"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Step 3: Payment Method */}
              <div className="bg-white rounded-xl border border-raja-ink-border p-6 shadow-sm space-y-4">
                <div className="flex items-center gap-2 border-b border-raja-ink-border/80 pb-3">
                  <span className="w-6 h-6 rounded-full bg-raja-maroon text-white text-xs font-bold flex items-center justify-center">
                    3
                  </span>
                  <h2 className="font-serif text-lg font-bold text-raja-ink">
                    Select Payment Method
                  </h2>
                </div>

                <div className="space-y-3">
                  {/* Cashfree Payment Gateway */}
                  <label
                    className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === "cashfree"
                        ? "border-raja-maroon bg-raja-maroon-subtle/50 ring-1 ring-raja-maroon"
                        : "border-raja-ink-border hover:bg-raja-ivory/50"
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cashfree"
                      checked={paymentMethod === "cashfree"}
                      onChange={() => setPaymentMethod("cashfree")}
                      className="mt-1 text-raja-maroon focus:ring-raja-maroon"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs sm:text-sm font-bold text-raja-ink flex items-center gap-2">
                          <CreditCard className="w-4 h-4 text-raja-gold" />
                          Online Payment (Cashfree UPI / Cards / Netbanking)
                        </span>
                        <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          Fast & Secure
                        </span>
                      </div>
                      <p className="text-[11px] text-raja-ink-soft mt-1 leading-relaxed">
                        Pay via Google Pay, PhonePe, Paytm, RuPay, Debit/Credit Card or Netbanking. Encrypted via Cashfree PG.
                      </p>
                    </div>
                  </label>

                  {/* Direct WhatsApp Order */}
                  <label
                    className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === "whatsapp"
                        ? "border-raja-maroon bg-raja-maroon-subtle/50 ring-1 ring-raja-maroon"
                        : "border-raja-ink-border hover:bg-raja-ivory/50"
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="whatsapp"
                      checked={paymentMethod === "whatsapp"}
                      onChange={() => setPaymentMethod("whatsapp")}
                      className="mt-1 text-raja-maroon focus:ring-raja-maroon"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs sm:text-sm font-bold text-raja-ink flex items-center gap-2">
                          <MessageCircle className="w-4 h-4 text-[#25D366]" />
                          Direct WhatsApp Order & UPI QR
                        </span>
                        <span className="text-[10px] font-semibold text-raja-maroon bg-raja-maroon/10 px-2 py-0.5 rounded">
                          Artisan Direct
                        </span>
                      </div>
                      <p className="text-[11px] text-raja-ink-soft mt-1 leading-relaxed">
                        Confirm directly with our Salem weavers on WhatsApp (+91 93600 21627) and pay via direct UPI QR code.
                      </p>
                    </div>
                  </label>

                  {/* Cash on Delivery */}
                  <label
                    className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === "cod"
                        ? "border-raja-maroon bg-raja-maroon-subtle/50 ring-1 ring-raja-maroon"
                        : "border-raja-ink-border hover:bg-raja-ivory/50"
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cod"
                      checked={paymentMethod === "cod"}
                      onChange={() => setPaymentMethod("cod")}
                      className="mt-1 text-raja-maroon focus:ring-raja-maroon"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs sm:text-sm font-bold text-raja-ink flex items-center gap-2">
                          <Truck className="w-4 h-4 text-raja-gold" />
                          Cash on Delivery (COD)
                        </span>
                      </div>
                      <p className="text-[11px] text-raja-ink-soft mt-1 leading-relaxed">
                        Pay with cash upon delivery. Subject to pincode verification at dispatch.
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Special Order Notes */}
              <div className="bg-white rounded-xl border border-raja-ink-border p-4 shadow-sm text-xs">
                <label className="block font-semibold text-raja-ink mb-1">
                  Order Notes / Delivery Instructions (Optional)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Please pack for gifting, call before delivery"
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
                />
              </div>
            </div>

            {/* Right Column: Order Summary & Place Order CTA */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white rounded-xl border border-raja-ink-border p-6 shadow-sm space-y-5 sticky top-28">
                <h3 className="font-serif text-lg font-bold text-raja-ink border-b border-raja-ink-border pb-3">
                  Order Summary ({items.reduce((s, i) => s + i.quantity, 0)} Sarees)
                </h3>

                {/* Items preview list */}
                <div className="max-h-64 overflow-y-auto space-y-3 pr-1">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-3 text-xs">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-14 h-16 object-cover rounded bg-raja-ivory flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h4 className="font-serif font-semibold text-raja-ink line-clamp-1">
                          {item.product.name}
                        </h4>
                        <p className="text-raja-ink-muted text-[11px]">
                          Color: {item.selectedColor}
                        </p>
                        <p className="text-raja-ink-soft text-[11px]">
                          Qty: {item.quantity} × ₹{item.product.price}
                        </p>
                      </div>
                      <div className="text-right font-bold text-raja-maroon">
                        ₹{(item.product.price * item.quantity).toLocaleString("en-IN")}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pricing Summary */}
                <div className="pt-3 border-t border-raja-ink-border space-y-2 text-xs text-raja-ink-soft">
                  <div className="flex justify-between">
                    <span>Items Subtotal</span>
                    <span className="font-semibold text-raja-ink">
                      ₹{subtotal.toLocaleString("en-IN")}
                    </span>
                  </div>

                  {discount > 0 && (
                    <div className="flex justify-between text-emerald-700">
                      <span>Loom Discount ({couponCode})</span>
                      <span className="font-semibold">-₹{discount.toLocaleString("en-IN")}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span>Pan-India Delivery</span>
                    <span className="font-semibold text-raja-ink">
                      {shipping === 0 ? (
                        <span className="text-emerald-700 font-bold uppercase">Free</span>
                      ) : (
                        `₹${shipping}`
                      )}
                    </span>
                  </div>

                  <div className="pt-3 border-t border-raja-ink-border flex justify-between text-base font-bold text-raja-ink">
                    <span>Grand Total</span>
                    <span className="text-xl text-raja-maroon">
                      ₹{total.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>

                {/* Place Order CTA Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-lg bg-raja-maroon hover:bg-raja-maroon-light disabled:opacity-60 text-white font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <span>Securing Your Weaves...</span>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 text-raja-gold" />
                      <span>Place Order • ₹{total.toLocaleString("en-IN")}</span>
                    </>
                  )}
                </button>

                <div className="pt-2 text-center space-y-2 text-[11px] text-raja-ink-muted">
                  <p className="flex items-center justify-center gap-1.5 text-emerald-800 font-medium">
                    <ShieldCheck className="w-4 h-4 text-raja-gold" />
                    Direct Elampillai Loom Dispatch Guaranteed
                  </p>
                  <p>Order support & tracking: +91 93600 21627</p>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
