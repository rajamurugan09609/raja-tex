"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Loader2, AlertCircle } from "lucide-react";

function CashfreeReturnContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const orderId = searchParams.get("order_id");
  const [status, setStatus] = useState<"verifying" | "success" | "failed">("verifying");
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    async function verify() {
      if (!orderId) {
        setStatus("failed");
        setErrorMsg("Missing order_id in return URL.");
        return;
      }

      try {
        const res = await fetch("/api/checkout/cashfree/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ orderNumber: orderId }),
        });

        const data = await res.json();
        if (data.verified || data.status === "PAID") {
          setStatus("success");
          router.replace(`/checkout/success?orderId=${data.orderId || orderId}`);
        } else {
          setStatus("failed");
          setErrorMsg(data.message || "Payment could not be verified.");
        }
      } catch (err: any) {
        setStatus("failed");
        setErrorMsg(err?.message || "Verification request failed.");
      }
    }

    verify();
  }, [orderId, router]);

  return (
    <div className="bg-raja-ivory min-h-screen py-20 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl border border-raja-ink-border p-8 max-w-md w-full text-center space-y-4 shadow-sm">
        {status === "verifying" && (
          <>
            <div className="w-12 h-12 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center mx-auto animate-spin">
              <Loader2 className="w-6 h-6" />
            </div>
            <h2 className="font-serif text-xl font-bold text-raja-ink">
              Verifying Payment with Cashfree
            </h2>
            <p className="text-xs text-raja-ink-soft">
              Please wait while our servers verify your transaction with the payment gateway...
            </p>
          </>
        )}

        {status === "failed" && (
          <>
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-700 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h2 className="font-serif text-xl font-bold text-red-900">
              Payment Verification Pending
            </h2>
            <p className="text-xs text-red-700">{errorMsg}</p>
            <button
              onClick={() => router.push(`/checkout`)}
              className="mt-4 px-6 py-2.5 rounded bg-raja-maroon text-white text-xs font-semibold"
            >
              Return to Checkout
            </button>
          </>
        )}
      </div>
    </div>
  );
}

export default function CashfreeReturnPage() {
  return (
    <Suspense
      fallback={
        <div className="bg-raja-ivory min-h-screen py-20 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-raja-maroon" />
        </div>
      }
    >
      <CashfreeReturnContent />
    </Suspense>
  );
}
