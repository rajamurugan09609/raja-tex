import React from "react";

export default function TermsPage() {
  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 bg-white p-8 sm:p-12 rounded-2xl border border-raja-ink-border shadow-sm">
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-raja-gold">
            Legal & Compliance
          </span>
          <h1 className="font-serif text-3xl font-bold text-raja-maroon mt-1">
            Terms & Conditions
          </h1>
          <p className="text-xs text-raja-ink-muted mt-1">
            Effective Date: October 2026 • Raja Textile, Elampillai, Salem
          </p>
        </div>

        <div className="space-y-6 text-xs text-raja-ink-soft leading-relaxed">
          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              1. Commercial Representation
            </h2>
            <p>
              Raja Textile is an authentic South Indian textile manufacturing and retail brand based in Elampillai, Salem, Tamil Nadu (PIN 637502). All product prices on this website are direct weaver prices quoted in Indian Rupees (INR) and are inclusive of applicable taxes.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              2. Authentic Weaving Disclaimers
            </h2>
            <p>
              Due to the artistic nature of traditional jacquard and handloom weaving, minute color variations may occur between digital camera screens and physical fabric under natural sunlight. Minor variations in zari butta orientation are natural hallmarks of authentic woven textiles.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              3. Payments & Orders
            </h2>
            <p>
              Payments can be completed via Cashfree Payment Gateway, Direct UPI transfer, or Cash on Delivery where service is supported by courier partners. No order is dispatched until verified by our loom dispatch staff.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              4. Governing Law & Jurisdiction
            </h2>
            <p>
              These terms shall be governed by and constructed in accordance with the laws of India. Any disputes arising out of or related to our storefront shall be subject to the exclusive jurisdiction of the courts in Salem, Tamil Nadu.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
