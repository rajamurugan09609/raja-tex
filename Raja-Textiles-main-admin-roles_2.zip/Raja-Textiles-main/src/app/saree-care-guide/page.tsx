import React from "react";
import { Sun, Droplets, Wind, Shield } from "lucide-react";

export default function SareeCareGuidePage() {
  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 bg-white p-8 sm:p-12 rounded-2xl border border-raja-ink-border shadow-sm">
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-raja-gold">
            Preserving Heirloom Weaves
          </span>
          <h1 className="font-serif text-3xl font-bold text-raja-maroon mt-1">
            Saree Care & Metallic Zari Preservation Guide
          </h1>
          <p className="text-xs text-raja-ink-muted mt-1">
            Tips from master weavers of Elampillai to keep your sarees radiant for decades.
          </p>
        </div>

        <div className="space-y-6 text-xs text-raja-ink-soft leading-relaxed">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-raja-ink-border bg-raja-ivory/30 space-y-2">
              <div className="w-8 h-8 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center">
                <Droplets className="w-4 h-4 text-raja-gold" />
              </div>
              <h3 className="font-serif text-sm font-bold text-raja-ink">First Wash Guidelines</h3>
              <p>
                Dry cleaning is recommended for the first wash to set the metallic zari luster. For subsequent washes, hand wash gently in cold water using a mild shampoo or silk detergent. Never use harsh chemical powders.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-raja-ink-border bg-raja-ivory/30 space-y-2">
              <div className="w-8 h-8 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center">
                <Sun className="w-4 h-4 text-raja-gold" />
              </div>
              <h3 className="font-serif text-sm font-bold text-raja-ink">Drying & Airing</h3>
              <p>
                Never wring or twist your saree. Roll gently in a clean dry cotton towel to absorb excess water, then hang in shade. Avoid direct noon sunlight to prevent delicate silk colors from fading.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-raja-ink-border bg-raja-ivory/30 space-y-2">
              <div className="w-8 h-8 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center">
                <Wind className="w-4 h-4 text-raja-gold" />
              </div>
              <h3 className="font-serif text-sm font-bold text-raja-ink">Ironing Instructions</h3>
              <p>
                Always iron on the reverse side of the saree using medium heat or a silk setting. Never run a hot iron directly over metallic gold or silver zari work without a protective cotton pressing cloth.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-raja-ink-border bg-raja-ivory/30 space-y-2">
              <div className="w-8 h-8 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center">
                <Shield className="w-4 h-4 text-raja-gold" />
              </div>
              <h3 className="font-serif text-sm font-bold text-raja-ink">Long-Term Storage</h3>
              <p>
                Wrap sarees in breathable cotton or muslin bags. Change fold lines once every 3 to 4 months to prevent crease tears. Avoid placing mothballs or spraying perfumes directly onto zari.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
