"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  Package,
  ShoppingBag,
  TrendingUp,
  Plus,
  Edit,
  Trash2,
  ExternalLink,
  MessageCircle,
  X,
  Search,
  Lock,
  Image as ImageIcon,
  Save,
  Check,
  Settings,
  RefreshCw,
  Sparkles,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Tag,
  Star,
  Upload,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Users,
  UserPlus,
  ShieldCheck,
} from "lucide-react";
import { Product, Order, TextileDepartment, StoreSettings, HeroSlide, AdminUser } from "@/types";
import { STORE_SETTINGS, INITIAL_HERO_SLIDES } from "@/data/products";
import { useAuth } from "@/context/AuthContext";
import BrandLogo from "@/components/BrandLogo";

// Helper: compress uploaded image via Canvas to sharp, lightweight WebP/JPEG data URL (<100KB)
const compressAndReadImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 1200;
        const MAX_HEIGHT = 1500;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        // Try webp first for maximum compression efficiency
        try {
          const webpUrl = canvas.toDataURL("image/webp", 0.85);
          if (webpUrl.startsWith("data:image/webp")) {
            resolve(webpUrl);
            return;
          }
        } catch {
          // fallback to jpeg
        }
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
};

export default function OwnerPortalPage() {
  // Role comes from the SERVER (Main Admin / Normal Admin). Nothing is hardcoded in the browser.
  const { user, session, isAdmin, isOwner, adminPermissions, adminLoading, isLoading: authLoading } = useAuth();
  const isUnlocked = isAdmin;
  const can = (permission: string) => adminPermissions.includes(permission);

  // Active Tab: 'analytics' | 'products' | 'orders' | 'settings' | 'hero' | 'admins'
  const [activeTab, setActiveTab] = useState<"analytics" | "products" | "orders" | "settings" | "hero" | "admins">("analytics");

  // Admin Team (Main Admin only)
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [adminForm, setAdminForm] = useState({ fullName: "", email: "", password: "", role: "admin" as "admin" | "main_admin" });
  const [adminSaving, setAdminSaving] = useState(false);
  const [adminMessage, setAdminMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  // State
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>(INITIAL_HERO_SLIDES);
  const [loadingData, setLoadingData] = useState(true);

  // Hero Slide Modal State
  const [editingHeroSlide, setEditingHeroSlide] = useState<Partial<HeroSlide> | null>(null);
  const [isEditingHeroSlide, setIsEditingHeroSlide] = useState(false);
  const [heroRawImageUrl, setHeroRawImageUrl] = useState("");
  const [selectedPinProductId, setSelectedPinProductId] = useState("");
  const [heroImageProcessing, setHeroImageProcessing] = useState(false);

  // Store Settings Form State
  const [settingsForm, setSettingsForm] = useState<StoreSettings>(STORE_SETTINGS);
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState(false);

  // Product Editing / Creation Modal & Multi-Image Gallery State
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [productImages, setProductImages] = useState<string[]>([]);
  const [rawImageUrlInput, setRawImageUrlInput] = useState("");
  const [isProcessingImages, setIsProcessingImages] = useState(false);

  // Order Detail / Status Update Modal
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [orderStatusUpdate, setOrderStatusUpdate] = useState<Order["orderStatus"]>("placed");
  const [paymentStatusUpdate, setPaymentStatusUpdate] = useState<Order["paymentStatus"]>("pending");
  const [trackingNumberInput, setTrackingNumberInput] = useState("");
  const [courierNameInput, setCourierNameInput] = useState("Professional Courier");

  // Search & Filter
  const [productSearch, setProductSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");

  // Normal Admin has no analytics/orders: land them on the Product tab
  useEffect(() => {
    if (!isUnlocked) return;
    if (activeTab === "analytics" && !can("orders:read")) setActiveTab("products");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isUnlocked, adminPermissions]);

  const loadDashboardData = useCallback(async () => {
    setLoadingData(true);
    try {
      const headers: Record<string, string> = {};
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }
      const safeJson = async (res: Response) => {
        try {
          return await res.json();
        } catch {
          return {};
        }
      };

      // Only ask for what this admin is allowed to see
      const [prodRes, ordRes, setRes, slideRes, adminRes] = await Promise.all([
        fetch("/api/admin/products", { headers }),
        can("orders:read") ? fetch("/api/admin/orders", { headers }) : Promise.resolve(null),
        fetch("/api/admin/settings", { headers }),
        fetch("/api/admin/hero-slides", { headers }),
        can("admins:manage") ? fetch("/api/admin/admins", { headers }) : Promise.resolve(null),
      ]);

      const prodData = await safeJson(prodRes);
      const ordData = ordRes ? await safeJson(ordRes) : {};
      const setData = await safeJson(setRes);
      const slideData = await safeJson(slideRes);
      const adminData = adminRes ? await safeJson(adminRes) : {};

      if (prodData.products) setProducts(prodData.products);
      if (ordData.orders) setOrders(ordData.orders);
      if (setData.settings) setSettingsForm(setData.settings);
      if (slideData.slides) setHeroSlides(slideData.slides);
      if (adminData.admins) setAdmins(adminData.admins);
    } catch {
      // ignore
    } finally {
      setLoadingData(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.access_token, adminPermissions]);

  // Load products, orders, and store settings
  useEffect(() => {
    if (isUnlocked) {
      loadDashboardData();
    }
  }, [isUnlocked, loadDashboardData]);

  // Open Product Editor with Multi-Image Gallery pre-filled
  const openProductEditor = (prod?: Product) => {
    if (prod) {
      setEditingProduct(prod);
      setProductImages(
        prod.images && prod.images.length > 0
          ? [...prod.images]
          : ["/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"]
      );
    } else {
      setEditingProduct({
        name: "",
        category: "Karizma Silk",
        department: "Sarees",
        section: "Women",
        price: 699,
        originalPrice: 1999,
        stockCount: 15,
        unit: "piece",
        fabric: "Soft Silk (80's warp)",
        sareeLength: "6.25m with blouse",
        zariType: "Golden Metallic Zari",
        pallu: "Rich Contrast Graphic Pallu",
        description: "",
        inStock: true,
        isFeatured: false,
        isBestSeller: false,
      });
      setProductImages(["/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"]);
    }
    setRawImageUrlInput("");
    setIsEditing(true);
  };

  // Upload multi-files from device & auto-compress
  const handleUploadFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsProcessingImages(true);
    try {
      const newUrls: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.type.startsWith("image/")) continue;
        const compressed = await compressAndReadImage(file);
        newUrls.push(compressed);
      }
      if (newUrls.length > 0) {
        setProductImages((prev) => {
          if (
            prev.length === 1 &&
            prev[0] === "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"
          ) {
            return newUrls;
          }
          return [...prev, ...newUrls];
        });
      }
    } catch (err: any) {
      alert("Failed to process one or more images: " + (err?.message || "Unknown error"));
    } finally {
      setIsProcessingImages(false);
    }
  };

  // Add raw URL to gallery
  const handleAddRawImageUrl = () => {
    const url = rawImageUrlInput.trim();
    if (!url) return;
    setProductImages((prev) => {
      if (
        prev.length === 1 &&
        prev[0] === "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"
      ) {
        return [url];
      }
      return [...prev, url];
    });
    setRawImageUrlInput("");
  };

  // Set selected image as Primary Cover (index 0)
  const handleSetPrimaryImage = (index: number) => {
    if (index === 0) return;
    setProductImages((prev) => {
      const copy = [...prev];
      const [item] = copy.splice(index, 1);
      copy.unshift(item);
      return copy;
    });
  };

  // Move image earlier or later in display order
  const handleMoveImage = (index: number, direction: "left" | "right") => {
    setProductImages((prev) => {
      const targetIdx = direction === "left" ? index - 1 : index + 1;
      if (targetIdx < 0 || targetIdx >= prev.length) return prev;
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIdx];
      copy[targetIdx] = temp;
      return copy;
    });
  };

  // Delete image from gallery
  const handleRemoveImage = (index: number) => {
    setProductImages((prev) => {
      const copy = prev.filter((_, idx) => idx !== index);
      return copy.length > 0
        ? copy
        : ["/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"];
    });
  };

  // Upload hero banner image from device & auto-compress
  const handleUploadHeroImage = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    if (!file.type.startsWith("image/")) return;
    setHeroImageProcessing(true);
    try {
      const compressed = await compressAndReadImage(file);
      setHeroRawImageUrl(compressed);
    } catch (err: any) {
      alert("Failed to process banner image: " + (err?.message || "Unknown error"));
    } finally {
      setHeroImageProcessing(false);
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.name || !editingProduct?.price) return;

    // Assemble images array from multi-image gallery
    const assembledImages = productImages.filter((img) => img && img.trim().length > 0);
    if (assembledImages.length === 0) {
      assembledImages.push("/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg");
    }

    const payload = {
      ...editingProduct,
      images: assembledImages,
      discountPercent: editingProduct.originalPrice && editingProduct.originalPrice > editingProduct.price
        ? Math.round(((editingProduct.originalPrice - editingProduct.price) / editingProduct.originalPrice) * 100)
        : 0,
    };

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        if (payload.isFeatured && data.product?.id) {
          const slideExists = heroSlides.some((s) => s.productId === data.product.id);
          if (!slideExists) {
            const autoSlide: Partial<HeroSlide> = {
              type: "product",
              title: data.product.name,
              subtitle: data.product.description ? data.product.description.substring(0, 95) + "..." : "Master weave crafted in Elampillai.",
              badge: "Featured Masterpiece",
              tamilTitle: data.product.category,
              imageUrl: data.product.images[0] || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
              linkUrl: `/products/${data.product.slug || data.product.id}`,
              price: data.product.price,
              originalPrice: data.product.originalPrice,
              discountBadge: data.product.discountPercent ? `${data.product.discountPercent}% OFF` : undefined,
              buttonText: "View Saree",
              order: heroSlides.length + 1,
              isActive: true,
              productId: data.product.id,
            };
            await fetch("/api/admin/hero-slides", {
              method: "POST",
              headers,
              body: JSON.stringify(autoSlide),
            });
          }
        }
        setIsEditing(false);
        setEditingProduct(null);
        await loadDashboardData();
        alert(`Product "${payload.name}" saved successfully with ${assembledImages.length} photo(s).`);
      } else {
        alert(data.error || "Failed to save product.");
      }
    } catch {
      alert("Failed to save product.");
    }
  };

  const handleDeleteProduct = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to permanently delete "${name}"?\nThis will remove it from the store catalog, database, and hero banners.`)) return;

    // Optimistic UI update for immediate instant feedback
    const previousProducts = [...products];
    const previousSlides = [...heroSlides];
    setProducts((prev) => prev.filter((p) => p.id !== id));
    setHeroSlides((prev) => prev.filter((s) => s.productId !== id));

    try {
      const headers: Record<string, string> = {
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch(`/api/admin/products/${encodeURIComponent(id)}`, {
        method: "DELETE",
        headers,
      });
      const data = await res.json();
      if (data.success) {
        await loadDashboardData();
        alert(`Product "${name}" deleted permanently.`);
      } else {
        // Revert on failure
        setProducts(previousProducts);
        setHeroSlides(previousSlides);
        alert(data.error || "Failed to delete product from database.");
      }
    } catch (err: any) {
      setProducts(previousProducts);
      setHeroSlides(previousSlides);
      alert("Failed to delete product: " + (err?.message || "Network error"));
    }
  };

  const handleToggleFeatured = async (product: Product) => {
    if (!can("product:update")) return;
    const nextFeatured = !product.isFeatured;

    // Optimistic UI update
    setProducts((prev) =>
      prev.map((p) => (p.id === product.id ? { ...p, isFeatured: nextFeatured } : p))
    );

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers,
        body: JSON.stringify({
          ...product,
          isFeatured: nextFeatured,
        }),
      });
      const data = await res.json();
      if (!data.success) {
        alert(data.error || "Failed to toggle featured status.");
      } else {
        // Automatically sync hero carousel slide for featured product
        if (nextFeatured) {
          const slideExists = heroSlides.some((s) => s.productId === product.id);
          if (!slideExists) {
            const autoSlide: Partial<HeroSlide> = {
              type: "product",
              title: product.name,
              subtitle: product.description ? product.description.substring(0, 95) + "..." : "Master weave crafted in Elampillai.",
              badge: "Featured Masterpiece",
              tamilTitle: product.category,
              imageUrl: product.images[0] || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
              linkUrl: `/products/${product.slug || product.id}`,
              price: product.price,
              originalPrice: product.originalPrice,
              discountBadge: product.discountPercent ? `${product.discountPercent}% OFF` : undefined,
              buttonText: "View Saree",
              order: heroSlides.length + 1,
              isActive: true,
              productId: product.id,
            };
            await fetch("/api/admin/hero-slides", {
              method: "POST",
              headers,
              body: JSON.stringify(autoSlide),
            });
          }
        }
      }
      await loadDashboardData();
    } catch {
      alert("Failed to toggle featured status.");
      await loadDashboardData();
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    setSettingsSuccess(false);

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers,
        body: JSON.stringify(settingsForm),
      });
      const data = await res.json();
      if (data.success) {
        setSettingsSuccess(true);
        setTimeout(() => setSettingsSuccess(false), 3000);
      }
    } catch {
      alert("Failed to update store settings.");
    } finally {
      setSavingSettings(false);
    }
  };

  const handleUpdateOrderStatus = async () => {
    if (!selectedOrder) return;
    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch("/api/admin/orders", {
        method: "PUT",
        headers,
        body: JSON.stringify({
          orderId: selectedOrder.id,
          orderStatus: orderStatusUpdate,
          paymentStatus: paymentStatusUpdate,
          trackingNumber: trackingNumberInput,
          courierName: courierNameInput,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSelectedOrder(null);
        await loadDashboardData();
      }
    } catch {
      alert("Failed to update order status.");
    }
  };

  // --- HERO SLIDES & ADVERTISEMENT BANNER HANDLERS ---
  const openHeroSlideEditor = (slide?: HeroSlide) => {
    if (slide) {
      setEditingHeroSlide(slide);
      setHeroRawImageUrl(slide.imageUrl || "");
    } else {
      setEditingHeroSlide({
        type: "advertisement",
        title: "",
        subtitle: "",
        badge: "Special Offer",
        tamilTitle: "",
        linkUrl: "/collection",
        discountBadge: "Special Offer",
        buttonText: "Shop Offer",
        order: heroSlides.length + 1,
        isActive: true,
      });
      setHeroRawImageUrl("");
    }
    setIsEditingHeroSlide(true);
  };

  const handleSaveHeroSlide = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingHeroSlide?.title) return;

    const payload = {
      ...editingHeroSlide,
      imageUrl: heroRawImageUrl.trim() || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
      order: Number(editingHeroSlide.order || heroSlides.length + 1),
    };

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch("/api/admin/hero-slides", {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        setIsEditingHeroSlide(false);
        setEditingHeroSlide(null);
        await loadDashboardData();
      }
    } catch {
      alert("Failed to save hero slide");
    }
  };

  const handleDeleteHeroSlide = async (id: string, title: string) => {
    if (!confirm(`Delete slide "${title}" from Hero Carousel?`)) return;

    try {
      const headers: Record<string, string> = {
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch(`/api/admin/hero-slides?id=${id}`, {
        method: "DELETE",
        headers,
      });
      const data = await res.json();
      if (data.success) {
        await loadDashboardData();
      }
    } catch {
      alert("Failed to delete hero slide");
    }
  };

  const handleMoveHeroSlide = async (index: number, direction: "up" | "down") => {
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= heroSlides.length) return;

    const newSlides = [...heroSlides];
    const [moved] = newSlides.splice(index, 1);
    newSlides.splice(targetIndex, 0, moved);

    const orderedIds = newSlides.map((s) => s.id);
    setHeroSlides(newSlides);

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      await fetch("/api/admin/hero-slides", {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "reorder", orderedIds }),
      });
    } catch {
      await loadDashboardData();
    }
  };

  const handleToggleHeroSlideActive = async (slide: HeroSlide) => {
    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      await fetch("/api/admin/hero-slides", {
        method: "POST",
        headers,
        body: JSON.stringify({ ...slide, isActive: !slide.isActive }),
      });
      await loadDashboardData();
    } catch {
      alert("Failed to toggle slide");
    }
  };

  const handlePinSelectedProduct = async () => {
    if (!selectedPinProductId) return;
    const prod = products.find((p) => p.id === selectedPinProductId);
    if (!prod) return;

    const newSlide: Partial<HeroSlide> = {
      type: "product",
      title: prod.name,
      subtitle: prod.description ? prod.description.substring(0, 95) + "..." : "Authentic Salem weave.",
      badge: "Direct Loom " + (prod.discountPercent ? `${prod.discountPercent}% OFF` : "Special"),
      tamilTitle: prod.category,
      imageUrl: prod.images[0] || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
      linkUrl: `/products/${prod.slug}`,
      price: prod.price,
      originalPrice: prod.originalPrice,
      discountBadge: prod.discountPercent ? `${prod.discountPercent}% OFF` : undefined,
      buttonText: "View Saree",
      order: heroSlides.length + 1,
      isActive: true,
      productId: prod.id,
    };

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (session?.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
      }

      const res = await fetch("/api/admin/hero-slides", {
        method: "POST",
        headers,
        body: JSON.stringify(newSlide),
      });
      const data = await res.json();
      if (data.success) {
        setSelectedPinProductId("");
        await loadDashboardData();
      }
    } catch {
      alert("Failed to pin product to hero");
    }
  };

  // ---- Admin Team handlers (Main Admin only) ----
  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminMessage(null);
    setAdminSaving(true);
    try {
      const res = await fetch("/api/admin/admins", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {}),
        },
        body: JSON.stringify(adminForm),
      });
      const data = await res.json();
      if (data.success) {
        setAdminMessage({ type: "ok", text: data.message || "Admin created." });
        setAdminForm({ fullName: "", email: "", password: "", role: "admin" });
        await loadDashboardData();
      } else {
        setAdminMessage({ type: "error", text: data.error || "Failed to create admin." });
      }
    } catch {
      setAdminMessage({ type: "error", text: "Network error. Please try again." });
    } finally {
      setAdminSaving(false);
    }
  };

  const handleRemoveAdmin = async (email: string) => {
    if (!confirm(`Remove admin access for ${email}?\nTheir normal customer login will stay, but they can no longer open the admin portal.`)) return;
    setAdminMessage(null);
    try {
      const res = await fetch(`/api/admin/admins?email=${encodeURIComponent(email)}`, {
        method: "DELETE",
        headers: session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {},
      });
      const data = await res.json();
      if (data.success) {
        setAdminMessage({ type: "ok", text: `${email} is no longer an admin.` });
        await loadDashboardData();
      } else {
        setAdminMessage({ type: "error", text: data.error || "Failed to remove admin." });
      }
    } catch {
      setAdminMessage({ type: "error", text: "Network error. Please try again." });
    }
  };

  // Analytics Computations
  const totalRevenue = orders
    .filter((o) => o.paymentStatus === "verified")
    .reduce((sum, o) => sum + (o.pricing?.total || 0), 0);

  const pendingOrdersCount = orders.filter((o) => o.orderStatus === "placed" || o.orderStatus === "confirmed").length;
  const lowStockProducts = products.filter((p) => p.stockCount <= 5);

  const filteredProducts = products.filter((p) => {
    if (departmentFilter !== "all" && p.department !== departmentFilter) return false;
    if (productSearch) {
      const q = productSearch.toLowerCase();
      return p.name.toLowerCase().includes(q) || p.fabric.toLowerCase().includes(q) || p.category.toLowerCase().includes(q);
    }
    return true;
  });

  // 1. AUTHENTICATION / PERMISSION BARRIER (server decides who is an admin)
  if (authLoading || (session && adminLoading)) {
    return (
      <div className="min-h-[85vh] flex items-center justify-center bg-raja-ivory">
        <Loader2 className="w-6 h-6 animate-spin text-raja-maroon" />
      </div>
    );
  }

  if (!isUnlocked) {
    return (
      <div className="min-h-[85vh] flex items-center justify-center p-4 bg-raja-ivory">
        <div className="max-w-md w-full bg-white rounded-2xl border border-raja-ink-border p-8 shadow-luxury text-center space-y-6">
          <BrandLogo variant="auth" withLink={false} />

          <div className="space-y-1">
            <h1 className="font-serif text-2xl font-bold text-raja-maroon">Admin Portal</h1>
            <p className="text-xs text-raja-ink-soft">
              This section is only for the Main Admin and authorized store admins.
            </p>
          </div>

          {user ? (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-left text-xs space-y-2">
              <p className="font-bold text-red-900">Signed in as: {user.email}</p>
              <p className="text-red-800">
                This account does not have admin access. Please sign in with an admin account, or ask the Main Admin to create one for you.
              </p>
            </div>
          ) : (
            <div className="pt-2">
              <Link
                href="/auth/login"
                className="inline-block w-full py-3 px-4 rounded-xl bg-raja-maroon text-white font-bold text-xs uppercase tracking-wider shadow-sm hover:bg-raja-maroon-light transition-colors"
              >
                Sign In with Admin Account
              </Link>
            </div>
          )}
        </div>
      </div>
    );
  }

  // 2. MAIN OWNER PORTAL
  return (
    <div className="bg-raja-ivory min-h-screen py-8 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Top Control Bar */}
        <div className="bg-white rounded-2xl border border-raja-ink-border p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BrandLogo variant="header" withLink={false} />
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                {isOwner ? "Main Admin Portal" : "Admin Portal · Add Products"}
              </span>
              <p className="text-xs text-raja-ink-muted mt-0.5">
                Logged in: {user?.email}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={loadDashboardData}
              className="p-2 text-raja-ink-muted hover:text-raja-maroon rounded-lg hover:bg-raja-ivory transition-colors"
              title="Refresh live data"
            >
              <RefreshCw className={`w-4 h-4 ${loadingData ? "animate-spin text-raja-maroon" : ""}`} />
            </button>
            <Link
              href="/"
              target="_blank"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-raja-ink-border text-xs font-semibold hover:border-raja-maroon hover:text-raja-maroon transition-all"
            >
              <span>View Live Storefront</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-raja-ink-border/80 overflow-x-auto pb-2 scrollbar-none">
          {can("orders:read") && (
            <button
              onClick={() => setActiveTab("analytics")}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === "analytics"
                  ? "bg-raja-maroon text-white shadow-sm"
                  : "text-raja-ink hover:bg-white"
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Store Analytics</span>
            </button>
          )}

          <button
            onClick={() => setActiveTab("products")}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === "products"
                ? "bg-raja-maroon text-white shadow-sm"
                : "text-raja-ink hover:bg-white"
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Product Catalog ({products.length})</span>
          </button>

          {can("orders:read") && (
            <button
              onClick={() => setActiveTab("orders")}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === "orders"
                  ? "bg-raja-maroon text-white shadow-sm"
                  : "text-raja-ink hover:bg-white"
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Orders &amp; Fulfilment ({orders.length})</span>
            </button>
          )}

          {can("settings:update") && (
            <button
              onClick={() => setActiveTab("settings")}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === "settings"
                  ? "bg-raja-maroon text-white shadow-sm"
                  : "text-raja-ink hover:bg-white"
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Store Settings &amp; Info</span>
            </button>
          )}

          {can("hero:manage") && (
            <button
              onClick={() => setActiveTab("hero")}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === "hero"
                  ? "bg-raja-maroon text-white shadow-sm"
                  : "text-raja-ink hover:bg-white"
              }`}
            >
              <Sparkles className="w-4 h-4 text-raja-gold" />
              <span>Hero Carousel &amp; Ads ({heroSlides.length})</span>
            </button>
          )}

          {can("admins:manage") && (
            <button
              onClick={() => setActiveTab("admins")}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === "admins"
                  ? "bg-raja-maroon text-white shadow-sm"
                  : "text-raja-ink hover:bg-white"
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Admin Team ({admins.length})</span>
            </button>
          )}
        </div>

        {/* TAB 1: ANALYTICS */}
        {activeTab === "analytics" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-raja-ink-border shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">
                  Total Verified Revenue
                </span>
                <p className="font-serif text-2xl font-bold text-raja-maroon mt-1">
                  ₹{totalRevenue.toLocaleString("en-IN")}
                </p>
                <p className="text-[11px] text-raja-ink-soft mt-1">From completed orders</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-raja-ink-border shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">
                  Total Orders Placed
                </span>
                <p className="font-serif text-2xl font-bold text-raja-ink mt-1">
                  {orders.length} Orders
                </p>
                <p className="text-[11px] text-raja-gold-dark font-medium mt-1">
                  {pendingOrdersCount} pending dispatch
                </p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-raja-ink-border shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">
                  Active Weave Items
                </span>
                <p className="font-serif text-2xl font-bold text-raja-ink mt-1">
                  {products.length} Products
                </p>
                <p className="text-[11px] text-raja-ink-soft mt-1">Across 5 departments</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-raja-ink-border shadow-sm">
                <span className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">
                  Low Stock Inventory
                </span>
                <p className="font-serif text-2xl font-bold text-amber-700 mt-1">
                  {lowStockProducts.length} Items
                </p>
                <p className="text-[11px] text-amber-800 mt-1">&le; 5 units remaining</p>
              </div>
            </div>

            {/* Recent Orders List */}
            {orders.length > 0 && (
              <div className="bg-white rounded-2xl border border-raja-ink-border p-6 shadow-sm">
                <h3 className="font-serif text-base font-bold text-raja-ink mb-4">
                  Recent Customer Orders
                </h3>
                <div className="space-y-3">
                  {orders.slice(0, 5).map((ord) => (
                    <div
                      key={ord.id}
                      className="flex items-center justify-between p-3 rounded-xl bg-raja-ivory/50 border border-raja-ink-border/60 text-xs"
                    >
                      <div>
                        <span className="font-bold text-raja-ink">#{ord.orderNumber}</span> · {ord.customer.fullName} ({ord.customer.city})
                        <p className="text-raja-ink-muted text-[11px]">{ord.items.length} item(s) · {ord.paymentMethod.toUpperCase()}</p>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-raja-maroon">₹{ord.pricing?.total?.toLocaleString("en-IN")}</span>
                        <p className="text-[10px] font-semibold uppercase text-emerald-800">{ord.orderStatus}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: PRODUCTS CATALOG MANAGEMENT */}
        {activeTab === "products" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3 flex-1 max-w-md">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-raja-gold absolute left-3 top-3" />
                  <input
                    type="text"
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    placeholder="Search products by title, fabric, category..."
                    className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-raja-ink-border bg-white"
                  />
                </div>
                <select
                  value={departmentFilter}
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                  className="text-xs p-2 rounded-xl border border-raja-ink-border bg-white"
                >
                  <option value="all">All Departments</option>
                  <option value="Sarees">Sarees</option>
                  <option value="Fabrics">Fabrics</option>
                  <option value="Dress Materials">Dress Materials</option>
                  <option value="Garments">Men&apos;s Garments</option>
                  <option value="Home Textiles">Home Textiles</option>
                </select>
              </div>

              <button
                onClick={() => openProductEditor()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-raja-maroon text-white font-bold text-xs uppercase tracking-wider shadow-sm hover:bg-raja-maroon-light transition-colors self-start sm:self-auto"
              >
                <Plus className="w-4 h-4 text-raja-gold" />
                <span>Add Product (with Raw Image Link)</span>
              </button>
            </div>

            {/* Products Table */}
            <div className="bg-white rounded-2xl border border-raja-ink-border overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-raja-ivory border-b border-raja-ink-border text-raja-ink uppercase font-bold text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3.5">Weave &amp; Image</th>
                      <th className="p-3.5">Department</th>
                      <th className="p-3.5">Price</th>
                      <th className="p-3.5">Inventory</th>
                      <th className="p-3.5">Availability</th>
                      <th className="p-3.5 text-center">Featured (Home &amp; Hero)</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-raja-ink-border/60">
                    {filteredProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-raja-ivory/40 transition-colors">
                        <td className="p-3.5 flex items-center gap-3">
                          <img
                            src={p.images[0] || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"}
                            alt={p.name}
                            className="w-10 h-12 object-cover rounded-md bg-raja-ivory flex-shrink-0 border border-raja-ink-border"
                          />
                          <div>
                            <span className="font-bold text-raja-ink line-clamp-1">{p.name}</span>
                            <span className="text-[10px] text-raja-ink-muted">{p.fabric}</span>
                          </div>
                        </td>
                        <td className="p-3.5">
                          <span className="px-2 py-0.5 rounded bg-raja-ivory text-raja-maroon font-semibold border border-raja-ink-border">
                            {p.department || "Sarees"}
                          </span>
                        </td>
                        <td className="p-3.5 font-bold text-raja-maroon">
                          ₹{p.price.toLocaleString("en-IN")}
                          {p.unit === "meter" && <span className="text-[10px] text-raja-ink-muted font-normal"> /m</span>}
                        </td>
                        <td className="p-3.5">
                          <span className={`font-semibold ${p.stockCount <= 5 ? "text-red-700 font-bold" : "text-raja-ink"}`}>
                            {p.stockCount} {p.unit === "meter" ? "meters" : "units"}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              p.inStock ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"
                            }`}
                          >
                            {p.inStock ? "In Stock" : "Sold Out"}
                          </span>
                        </td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            disabled={!can("product:update")}
                            onClick={() => handleToggleFeatured(p)}
                            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold transition-all shadow-xs cursor-pointer disabled:cursor-not-allowed disabled:opacity-70 ${
                              p.isFeatured
                                ? "bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200"
                                : "bg-gray-50 text-gray-500 border border-gray-200 hover:border-amber-400 hover:text-amber-800"
                            }`}
                            title={p.isFeatured ? "Featured on Home & Hero — Click to un-feature" : "Click to feature on Home & Hero"}
                          >
                            <Star className={`w-3.5 h-3.5 ${p.isFeatured ? "fill-amber-500 text-amber-500" : "text-gray-400"}`} />
                            <span>{p.isFeatured ? "Featured" : "Standard"}</span>
                          </button>
                        </td>
                        <td className="p-3.5 text-right space-x-1">
                          {!can("product:update") && !can("product:delete") && (
                            <span className="text-[10px] text-raja-ink-muted">View only</span>
                          )}
                          {can("product:update") && (
                          <button
                            onClick={() => openProductEditor(p)}
                            className="p-1.5 text-raja-ink-soft hover:text-raja-maroon rounded hover:bg-raja-ivory transition-colors"
                            title="Edit product"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          )}
                          {can("product:delete") && (
                          <button
                            onClick={() => handleDeleteProduct(p.id, p.name)}
                            className="p-1.5 text-red-600 hover:text-red-800 rounded hover:bg-red-50 transition-colors"
                            title="Delete product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CUSTOMER ORDERS & FULFILMENT */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            <h2 className="font-serif text-xl font-bold text-raja-ink">Customer Orders &amp; Fulfilment</h2>

            {orders.length === 0 ? (
              <div className="bg-white rounded-2xl p-16 text-center border border-raja-ink-border space-y-3">
                <ShoppingBag className="w-12 h-12 text-raja-gold mx-auto" />
                <h3 className="font-serif text-xl font-bold text-raja-ink">No Orders Placed Yet</h3>
                <p className="text-xs text-raja-ink-soft max-w-sm mx-auto">
                  When customers purchase weaves, fabrics, or dhotis on the website, their orders will appear here for courier dispatch.
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-raja-ink-border overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-raja-ivory border-b border-raja-ink-border text-raja-ink uppercase font-bold text-[10px] tracking-wider">
                      <tr>
                        <th className="p-3.5">Order #</th>
                        <th className="p-3.5">Customer &amp; City</th>
                        <th className="p-3.5">Items</th>
                        <th className="p-3.5">Total &amp; Payment</th>
                        <th className="p-3.5">Fulfilment Status</th>
                        <th className="p-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-raja-ink-border/60">
                      {orders.map((ord) => (
                        <tr key={ord.id} className="hover:bg-raja-ivory/40 transition-colors">
                          <td className="p-3.5 font-bold text-raja-maroon">#{ord.orderNumber}</td>
                          <td className="p-3.5">
                            <span className="font-bold text-raja-ink">{ord.customer.fullName}</span>
                            <br />
                            <span className="text-[11px] text-raja-ink-muted">
                              {ord.customer.city}, {ord.customer.state} ({ord.customer.phone})
                            </span>
                          </td>
                          <td className="p-3.5">{ord.items.length} item(s)</td>
                          <td className="p-3.5">
                            <span className="font-bold text-raja-maroon">
                              ₹{ord.pricing?.total?.toLocaleString("en-IN")}
                            </span>
                            <br />
                            <span className="text-[10px] font-semibold text-emerald-800 uppercase">
                              {ord.paymentStatus} ({ord.paymentMethod})
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span className="font-semibold text-raja-ink uppercase text-[10px] px-2 py-0.5 rounded bg-raja-maroon-subtle">
                              {ord.orderStatus}
                            </span>
                            {ord.trackingNumber && (
                              <p className="text-[10px] text-raja-ink-muted mt-0.5">
                                {ord.courierName || "Courier"}: {ord.trackingNumber}
                              </p>
                            )}
                          </td>
                          <td className="p-3.5 text-right space-x-2">
                            <a
                              href={`https://wa.me/${ord.customer.phone.replace(/\D/g, "")}?text=Vanakkam%20${encodeURIComponent(ord.customer.fullName)},%20this%20is%20Raja%20Textile%20Elampillai%20regarding%20your%20Order%20%23${ord.orderNumber}.${ord.trackingNumber ? `%20Your%20tracking%20number%20is%20${ord.trackingNumber}.` : ""}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 text-emerald-700 hover:text-emerald-900 inline-block"
                              title="Chat with customer on WhatsApp"
                            >
                              <MessageCircle className="w-4 h-4" />
                            </a>
                            <button
                              onClick={() => {
                                setSelectedOrder(ord);
                                setOrderStatusUpdate(ord.orderStatus);
                                setPaymentStatusUpdate(ord.paymentStatus);
                                setTrackingNumberInput(ord.trackingNumber || "");
                                setCourierNameInput(ord.courierName || "Professional Courier");
                              }}
                              className="px-2.5 py-1 rounded bg-raja-maroon text-white font-bold text-[10px] hover:bg-raja-maroon-light shadow-sm"
                            >
                              Update Status
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: STORE SETTINGS & BANNERS */}
        {activeTab === "settings" && (
          <div className="bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-raja-ink-border pb-4">
              <div>
                <h2 className="font-serif text-xl font-bold text-raja-maroon">
                  Storefront Settings &amp; Announcements
                </h2>
                <p className="text-xs text-raja-ink-soft mt-0.5">
                  Update your contact phone, WhatsApp consultation number, announcement bar, and shipping rates live.
                </p>
              </div>

              {settingsSuccess && (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold animate-fade-in">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Settings Saved Live!</span>
                </div>
              )}
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-5 text-xs">
              {/* Announcement Bar Text */}
              <div>
                <label className="font-bold text-raja-ink block mb-1">
                  Top Announcement Bar Message (Displayed on all pages)
                </label>
                <input
                  type="text"
                  required
                  value={settingsForm.announcementText}
                  onChange={(e) => setSettingsForm({ ...settingsForm, announcementText: e.target.value })}
                  className="w-full p-3 rounded-xl border border-raja-ink-border bg-raja-ivory/20 focus:outline-none focus:border-raja-maroon"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-raja-ink block mb-1">Store Name</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.storeName}
                    onChange={(e) => setSettingsForm({ ...settingsForm, storeName: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Tagline</label>
                  <input
                    type="text"
                    value={settingsForm.tagline}
                    onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="font-bold text-raja-ink block mb-1">Phone Number (Calling)</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.phone}
                    onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">WhatsApp Number (Orders &amp; Video Calls)</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.whatsapp}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsapp: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Support Email</label>
                  <input
                    type="email"
                    required
                    value={settingsForm.email}
                    onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-raja-ink block mb-1">Free Shipping Order Threshold (₹)</label>
                  <input
                    type="number"
                    required
                    value={settingsForm.freeShippingThreshold}
                    onChange={(e) => setSettingsForm({ ...settingsForm, freeShippingThreshold: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Standard Courier Shipping Fee (₹)</label>
                  <input
                    type="number"
                    required
                    value={settingsForm.shippingFee}
                    onChange={(e) => setSettingsForm({ ...settingsForm, shippingFee: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="font-bold text-raja-ink block mb-1">Showroom Street Address</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.address}
                    onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Pincode</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.pincode}
                    onChange={(e) => setSettingsForm({ ...settingsForm, pincode: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-raja-ink block mb-1">Operating Hours</label>
                <input
                  type="text"
                  required
                  value={settingsForm.operatingHours}
                  onChange={(e) => setSettingsForm({ ...settingsForm, operatingHours: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-raja-ink-border"
                />
              </div>

              <div className="pt-4 border-t border-raja-ink-border flex justify-end">
                <button
                  type="submit"
                  disabled={savingSettings}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-raja-maroon text-white font-bold hover:bg-raja-maroon-light transition-all shadow-md disabled:opacity-50"
                >
                  <Save className="w-4 h-4 text-raja-gold" />
                  <span>{savingSettings ? "Saving Settings..." : "Save Store Settings"}</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 6: ADMIN TEAM (Main Admin only) */}
        {activeTab === "admins" && can("admins:manage") && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Create admin */}
            <form
              onSubmit={handleCreateAdmin}
              className="lg:col-span-2 bg-white rounded-2xl border border-raja-ink-border p-6 shadow-sm space-y-4 self-start"
            >
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-raja-maroon" />
                <h3 className="font-serif text-base font-bold text-raja-ink">Create New Admin</h3>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">Name</label>
                <input
                  type="text"
                  value={adminForm.fullName}
                  onChange={(e) => setAdminForm({ ...adminForm, fullName: e.target.value })}
                  placeholder="Staff name"
                  className="w-full text-xs p-2.5 rounded-lg border border-raja-ink-border"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">Email (login ID)</label>
                <input
                  type="email"
                  required
                  value={adminForm.email}
                  onChange={(e) => setAdminForm({ ...adminForm, email: e.target.value })}
                  placeholder="staff@example.com"
                  className="w-full text-xs p-2.5 rounded-lg border border-raja-ink-border"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">Password</label>
                <div className="relative">
                  <input
                    type={showAdminPassword ? "text" : "password"}
                    value={adminForm.password}
                    onChange={(e) => setAdminForm({ ...adminForm, password: e.target.value })}
                    placeholder="Minimum 8 characters"
                    autoComplete="new-password"
                    className="w-full text-xs p-2.5 pr-10 rounded-lg border border-raja-ink-border"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminPassword((v) => !v)}
                    className="absolute right-2.5 top-2.5 text-raja-ink-muted hover:text-raja-maroon"
                    title={showAdminPassword ? "Hide password" : "Show password"}
                  >
                    {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[10px] text-raja-ink-muted">
                  If this email already has a customer account, leave the password empty. It will be upgraded to admin.
                </p>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-raja-ink-muted">Role</label>
                <select
                  value={adminForm.role}
                  onChange={(e) => setAdminForm({ ...adminForm, role: e.target.value as "admin" | "main_admin" })}
                  className="w-full text-xs p-2.5 rounded-lg border border-raja-ink-border bg-white"
                >
                  <option value="admin">Normal Admin — can only add products</option>
                  <option value="main_admin">Main Admin — full access</option>
                </select>
              </div>

              {adminMessage && (
                <p
                  className={`text-xs p-2.5 rounded-lg border ${
                    adminMessage.type === "ok"
                      ? "bg-emerald-50 border-emerald-200 text-emerald-800"
                      : "bg-red-50 border-red-200 text-red-800"
                  }`}
                >
                  {adminMessage.text}
                </p>
              )}

              <button
                type="submit"
                disabled={adminSaving}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-raja-maroon text-white font-bold text-xs uppercase tracking-wider shadow-sm hover:bg-raja-maroon-light transition-colors disabled:opacity-60"
              >
                {adminSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4 text-raja-gold" />}
                <span>{adminSaving ? "Creating..." : "Create Admin"}</span>
              </button>
            </form>

            {/* Admin list */}
            <div className="lg:col-span-3 bg-white rounded-2xl border border-raja-ink-border overflow-hidden shadow-sm self-start">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-raja-ivory border-b border-raja-ink-border text-raja-ink uppercase font-bold text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3.5">Admin</th>
                      <th className="p-3.5">Role</th>
                      <th className="p-3.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-raja-ink-border/60">
                    {admins.map((a) => (
                      <tr key={a.id} className="hover:bg-raja-ivory/40 transition-colors">
                        <td className="p-3.5">
                          <span className="font-bold text-raja-ink block">{a.fullName || a.email.split("@")[0]}</span>
                          <span className="text-[11px] text-raja-ink-muted">{a.email}</span>
                        </td>
                        <td className="p-3.5">
                          {a.role === "main_admin" ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 font-bold text-[10px]">
                              <ShieldCheck className="w-3 h-3" /> Main Admin
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-raja-ivory text-raja-ink border border-raja-ink-border font-bold text-[10px]">
                              Normal Admin
                            </span>
                          )}
                        </td>
                        <td className="p-3.5 text-right">
                          {a.isEnvOwner || a.email === user?.email?.toLowerCase() ? (
                            <span className="text-[10px] text-raja-ink-muted">{a.isEnvOwner ? "Owner (fixed)" : "You"}</span>
                          ) : (
                            <button
                              onClick={() => handleRemoveAdmin(a.email)}
                              className="p-1.5 text-red-600 hover:text-red-800 rounded hover:bg-red-50 transition-colors"
                              title="Remove admin access"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {admins.length === 0 && (
                      <tr>
                        <td colSpan={3} className="p-6 text-center text-raja-ink-muted">No admins yet.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: HERO CAROUSEL & ADVERTISEMENT BANNERS */}
        {activeTab === "hero" && (
          <div className="space-y-6">
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-raja-ink-border shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-raja-ink-border">
                <div>
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-raja-gold" />
                    <h3 className="font-serif text-xl font-bold text-raja-maroon">
                      Hero Carousel &amp; Advertisement Banners
                    </h3>
                  </div>
                  <p className="text-xs text-raja-ink-soft mt-1">
                    Control which products and promotional banners appear in the top hero showcase.
                    Move up or down to set order sequence, or toggle visibility.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => openHeroSlideEditor()}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-raja-maroon text-white font-bold text-xs hover:bg-raja-maroon-light transition-all shadow-md"
                  >
                    <Plus className="w-4 h-4 text-raja-gold" />
                    <span>Add Promo / Ad Banner</span>
                  </button>
                </div>
              </div>

              {/* Quick Pin Product Bar */}
              <div className="mt-5 p-4 rounded-xl bg-raja-ivory/60 border border-raja-gold/30 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Tag className="w-4 h-4 text-raja-gold flex-shrink-0" />
                  <div>
                    <span className="font-bold text-raja-ink">Pin Catalog Product to Hero:</span>
                    <p className="text-[11px] text-raja-ink-muted">
                      Select any product to showcase it in the top hero slider.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedPinProductId}
                    onChange={(e) => setSelectedPinProductId(e.target.value)}
                    className="p-2 rounded-lg border border-raja-ink-border bg-white text-xs max-w-xs truncate"
                  >
                    <option value="">-- Choose a Product --</option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} (₹{p.price})
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={handlePinSelectedProduct}
                    disabled={!selectedPinProductId}
                    className="px-3.5 py-2 rounded-lg bg-raja-gold text-raja-wine font-bold text-xs hover:bg-raja-gold-light transition-all disabled:opacity-40"
                  >
                    Pin to Hero
                  </button>
                </div>
              </div>

              {/* Current Slides List */}
              <div className="mt-6 space-y-3">
                {heroSlides.length === 0 ? (
                  <p className="text-xs text-raja-ink-muted py-8 text-center">
                    No slides configured. Add an advertisement banner or pin a product above.
                  </p>
                ) : (
                  heroSlides.map((slide, idx) => (
                    <div
                      key={slide.id}
                      className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                        slide.isActive
                          ? "bg-white border-raja-ink-border hover:border-raja-gold/60"
                          : "bg-gray-50/80 border-dashed border-gray-300 opacity-60"
                      }`}
                    >
                      {/* Left: Reorder Controls & Thumbnail */}
                      <div className="flex items-center gap-3">
                        {/* Up / Down Controls */}
                        <div className="flex flex-col items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleMoveHeroSlide(idx, "up")}
                            disabled={idx === 0}
                            className="p-1 rounded text-raja-ink-muted hover:text-raja-maroon disabled:opacity-20 hover:bg-raja-ivory"
                            title="Move Up in sequence"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <span className="text-[10px] font-bold text-raja-ink bg-raja-ivory px-1.5 py-0.5 rounded border border-raja-ink-border">
                            #{idx + 1}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleMoveHeroSlide(idx, "down")}
                            disabled={idx === heroSlides.length - 1}
                            className="p-1 rounded text-raja-ink-muted hover:text-raja-maroon disabled:opacity-20 hover:bg-raja-ivory"
                            title="Move Down in sequence"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Thumbnail */}
                        <div className="w-16 h-20 rounded-lg overflow-hidden border border-raja-ink-border bg-raja-ivory flex-shrink-0">
                          <img
                            src={slide.imageUrl}
                            alt={slide.title}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg";
                            }}
                          />
                        </div>

                        {/* Title & Info */}
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                slide.type === "advertisement"
                                  ? "bg-amber-100 text-amber-900 border border-amber-300"
                                  : "bg-raja-maroon/10 text-raja-maroon border border-raja-maroon/20"
                              }`}
                            >
                              {slide.type === "advertisement" ? "Promo / Ad Banner" : "Featured Product"}
                            </span>
                            {slide.badge && (
                              <span className="text-[10px] text-raja-gold-dark font-medium">
                                • {slide.badge}
                              </span>
                            )}
                          </div>

                          <h4 className="font-serif font-bold text-sm text-raja-ink">
                            {slide.title}
                          </h4>

                          <p className="text-[11px] text-raja-ink-soft line-clamp-1 max-w-md">
                            {slide.subtitle || slide.linkUrl}
                          </p>

                          <div className="flex items-center gap-3 text-[10px] text-raja-ink-muted">
                            {slide.price && (
                              <span className="font-bold text-raja-maroon">
                                ₹{slide.price} {slide.originalPrice && <span className="line-through text-gray-400">₹{slide.originalPrice}</span>}
                              </span>
                            )}
                            {slide.discountBadge && (
                              <span className="font-semibold text-emerald-700">
                                {slide.discountBadge}
                              </span>
                            )}
                            <span className="text-raja-ink-muted">
                              Target: <code className="bg-raja-ivory px-1 rounded">{slide.linkUrl}</code>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Right Actions */}
                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <button
                          type="button"
                          onClick={() => handleToggleHeroSlideActive(slide)}
                          className={`p-2 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                            slide.isActive
                              ? "bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100"
                              : "bg-gray-100 text-gray-600 border-gray-300 hover:bg-gray-200"
                          }`}
                          title={slide.isActive ? "Hide from Hero" : "Show in Hero"}
                        >
                          {slide.isActive ? (
                            <>
                              <Eye className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Active</span>
                            </>
                          ) : (
                            <>
                              <EyeOff className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Hidden</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => openHeroSlideEditor(slide)}
                          className="p-2 text-raja-ink-soft hover:text-raja-maroon rounded-lg hover:bg-raja-ivory border border-raja-ink-border transition-colors"
                          title="Edit slide"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteHeroSlide(slide.id, slide.title)}
                          className="p-2 text-red-600 hover:text-red-700 rounded-lg hover:bg-red-50 border border-red-200 transition-colors"
                          title="Delete slide"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Edit / Add Product Modal with Raw Image Link Input & Live Preview */}
      {isEditing && editingProduct && (
        <div className="fixed inset-0 z-[100] bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-hidden">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-raja-gold/40 flex flex-col max-h-[92vh] overflow-hidden">
            {/* Modal Sticky Header */}
            <div className="p-4 sm:p-5 border-b border-raja-ink-border flex items-center justify-between flex-shrink-0 bg-white">
              <div>
                <h3 className="font-serif text-lg font-bold text-raja-maroon">
                  {editingProduct.id ? "Edit Textile Product" : "Add New Textile Product"}
                </h3>
                <p className="text-[11px] text-raja-ink-soft">
                  Provide product specifications and raw image links.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="p-1.5 rounded-full text-raja-ink-muted hover:text-raja-ink hover:bg-raja-ivory transition-colors"
                title="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="flex flex-col flex-1 overflow-hidden">
              {/* Modal Scrollable Body */}
              <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs overscroll-contain">
                {/* Product Title */}
                <div>
                  <label className="font-bold text-raja-ink block mb-1">Product Title *</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.name || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                    placeholder="e.g. 3D Embossed Karizma Silk Saree"
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:outline-none focus:border-raja-maroon"
                  />
                </div>

              {/* MULTI-IMAGE GALLERY MANAGER */}
              <div className="p-3.5 sm:p-4 rounded-xl bg-raja-ivory/60 border border-raja-gold/40 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-raja-maroon flex items-center gap-1.5 text-xs sm:text-sm">
                    <ImageIcon className="w-4 h-4 text-raja-gold" />
                    <span>Product Gallery &amp; Photos ({productImages.length}) *</span>
                  </label>
                  <span className="text-[10px] bg-raja-gold/20 text-raja-wine px-2 py-0.5 rounded-full font-semibold">
                    Cover + Multi-Angle Views
                  </span>
                </div>
                <p className="text-[11px] text-raja-ink-muted leading-relaxed">
                  Upload multiple photos from your phone/camera (Pallu, Zari border, Draped view, Model) or paste raw image URLs. First photo is always the <strong>Primary Store Cover</strong>.
                </p>

                {/* Upload Button & Direct URL Area */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <label className="cursor-pointer border-2 border-dashed border-raja-gold/60 hover:border-raja-maroon bg-white/90 hover:bg-raja-gold/10 rounded-xl p-3 flex items-center justify-center gap-2.5 transition-all text-center group">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleUploadFiles(e.target.files)}
                      disabled={isProcessingImages}
                    />
                    {isProcessingImages ? (
                      <Loader2 className="w-4 h-4 text-raja-maroon animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4 text-raja-maroon group-hover:scale-110 transition-transform" />
                    )}
                    <div className="text-left">
                      <span className="font-bold text-raja-ink block text-[11px]">
                        {isProcessingImages ? "Optimizing Photos..." : "Upload Photos from Device"}
                      </span>
                      <span className="text-[9px] text-raja-ink-muted">JPG, PNG, WebP (auto web-compressed)</span>
                    </div>
                  </label>

                  {/* Add Image by Direct URL */}
                  <div className="flex gap-1.5 items-center bg-white p-1.5 rounded-xl border border-raja-ink-border">
                    <input
                      type="text"
                      value={rawImageUrlInput}
                      onChange={(e) => setRawImageUrlInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleAddRawImageUrl();
                        }
                      }}
                      placeholder="Paste raw image URL (https://...)"
                      className="flex-1 px-2.5 py-1.5 text-[11px] font-mono bg-transparent border-none focus:outline-none text-raja-ink"
                    />
                    <button
                      type="button"
                      onClick={handleAddRawImageUrl}
                      disabled={!rawImageUrlInput.trim()}
                      className="px-3 py-1.5 rounded-lg bg-raja-wine hover:bg-raja-maroon text-white font-semibold text-[11px] disabled:opacity-40 transition-colors flex-shrink-0"
                    >
                      + Add URL
                    </button>
                  </div>
                </div>

                {/* Image Thumbnails Grid */}
                {productImages.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5 pt-1">
                    {productImages.map((imgUrl, index) => {
                      const isCover = index === 0;
                      return (
                        <div
                          key={index}
                          className={`relative aspect-[3/4] rounded-lg overflow-hidden border-2 transition-all bg-raja-ivory group ${
                            isCover
                              ? "border-raja-gold ring-2 ring-raja-gold/30 shadow-md"
                              : "border-raja-ink-border hover:border-raja-gold"
                          }`}
                        >
                          <img
                            src={imgUrl}
                            alt={`Product Photo ${index + 1}`}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src =
                                "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg";
                            }}
                          />

                          {/* Cover / Position Badge */}
                          <div className="absolute top-1 left-1">
                            {isCover ? (
                              <span className="bg-raja-maroon text-raja-gold font-bold text-[9px] px-1.5 py-0.5 rounded shadow flex items-center gap-0.5">
                                <Star className="w-2.5 h-2.5 fill-current" /> Cover
                              </span>
                            ) : (
                              <span className="bg-black/60 backdrop-blur-sm text-white text-[9px] px-1.5 py-0.5 rounded font-medium">
                                #{index + 1}
                              </span>
                            )}
                          </div>

                          {/* Quick Actions Overlay */}
                          <div className="absolute inset-0 bg-black/65 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-1.5 text-white">
                            <div className="flex justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => handleRemoveImage(index)}
                                className="p-1 rounded bg-red-600 hover:bg-red-700 text-white transition-colors"
                                title="Remove photo"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>

                            <div className="space-y-1">
                              {!isCover && (
                                <button
                                  type="button"
                                  onClick={() => handleSetPrimaryImage(index)}
                                  className="w-full py-0.5 px-1 rounded bg-raja-gold text-raja-wine font-bold text-[9px] hover:bg-raja-gold-light transition-colors text-center block"
                                >
                                  Make Cover
                                </button>
                              )}
                              <div className="flex justify-between gap-1">
                                <button
                                  type="button"
                                  disabled={index === 0}
                                  onClick={() => handleMoveImage(index, "left")}
                                  className="flex-1 py-0.5 rounded bg-white/20 hover:bg-white/40 disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center"
                                  title="Move earlier"
                                >
                                  <ChevronLeft className="w-3 h-3" />
                                </button>
                                <button
                                  type="button"
                                  disabled={index === productImages.length - 1}
                                  onClick={() => handleMoveImage(index, "right")}
                                  className="flex-1 py-0.5 rounded bg-white/20 hover:bg-white/40 disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center"
                                  title="Move later"
                                >
                                  <ChevronRight className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Department & Category */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-raja-ink block mb-1">Department *</label>
                  <select
                    value={editingProduct.department || "Sarees"}
                    onChange={(e) => setEditingProduct({ ...editingProduct, department: e.target.value as TextileDepartment })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border bg-white"
                  >
                    <option value="Sarees">Sarees</option>
                    <option value="Fabrics">Fabrics &amp; Yardage</option>
                    <option value="Dress Materials">Dress Materials</option>
                    <option value="Garments">Men&apos;s Garments</option>
                    <option value="Home Textiles">Home Textiles</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Category Name *</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.category || "Karizma Silk"}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                  />
                </div>
              </div>

              {/* Price, MRP, Stock, Unit */}
              <div className="grid grid-cols-4 gap-2.5">
                <div>
                  <label className="font-bold text-raja-ink block mb-1">Loom Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full p-2 rounded-lg border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">MRP Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.originalPrice || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: Number(e.target.value) })}
                    className="w-full p-2 rounded-lg border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Stock *</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.stockCount || 10}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stockCount: Number(e.target.value) })}
                    className="w-full p-2 rounded-lg border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Selling Unit</label>
                  <select
                    value={editingProduct.unit || "piece"}
                    onChange={(e) => setEditingProduct({ ...editingProduct, unit: e.target.value })}
                    className="w-full p-2 rounded-lg border border-raja-ink-border bg-white"
                  >
                    <option value="piece">per Piece</option>
                    <option value="meter">per Meter</option>
                    <option value="set">per Set</option>
                  </select>
                </div>
              </div>

              {/* Fabric, Length, Zari */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-raja-ink block mb-1">Fabric &amp; Texture *</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.fabric || "Soft Silk (80's warp)"}
                    onChange={(e) => setEditingProduct({ ...editingProduct, fabric: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Dimensions / Length</label>
                  <input
                    type="text"
                    value={editingProduct.sareeLength || "6.25m with blouse"}
                    onChange={(e) => setEditingProduct({ ...editingProduct, sareeLength: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                  />
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Zari Type</label>
                  <input
                    type="text"
                    value={editingProduct.zariType || "Golden Metallic Zari"}
                    onChange={(e) => setEditingProduct({ ...editingProduct, zariType: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="font-bold text-raja-ink block mb-1">Weave Story / Description</label>
                <textarea
                  rows={3}
                  value={editingProduct.description || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  placeholder="Handcrafted at our Elampillai looms..."
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                />
              </div>

              {/* Feature & Badge Controls (Main Admin only) */}
              {can("product:update") && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="flex items-center gap-2 p-2.5 rounded-lg border border-amber-200 bg-amber-50/50">
                  <input
                    type="checkbox"
                    id="isFeaturedCheck"
                    checked={editingProduct.isFeatured ?? false}
                    onChange={(e) => setEditingProduct({ ...editingProduct, isFeatured: e.target.checked })}
                    className="w-4 h-4 text-amber-600 rounded"
                  />
                  <label htmlFor="isFeaturedCheck" className="text-xs font-bold text-amber-950 cursor-pointer flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                    <span>Featured (Home &amp; Hero)</span>
                  </label>
                </div>

                <div className="flex items-center gap-2 p-2.5 rounded-lg border border-raja-ink-border/60 bg-raja-ivory/50">
                  <input
                    type="checkbox"
                    id="isBestSellerCheck"
                    checked={editingProduct.isBestSeller ?? false}
                    onChange={(e) => setEditingProduct({ ...editingProduct, isBestSeller: e.target.checked })}
                    className="w-4 h-4 text-raja-maroon rounded"
                  />
                  <label htmlFor="isBestSellerCheck" className="text-xs font-bold text-raja-ink cursor-pointer">
                    🔥 Best Seller Badge
                  </label>
                </div>
              </div>
              )}

              {/* Availability Switch */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="inStockCheck"
                  checked={editingProduct.inStock ?? true}
                  onChange={(e) => setEditingProduct({ ...editingProduct, inStock: e.target.checked })}
                  className="w-4 h-4 text-raja-maroon rounded"
                />
                <label htmlFor="inStockCheck" className="text-xs font-semibold text-raja-ink cursor-pointer">
                  Product is In-Stock and available for immediate dispatch
                </label>
              </div>
            </div>

            {/* Modal Sticky Footer */}
            <div className="p-3.5 sm:p-4 border-t border-raja-ink-border flex items-center justify-end gap-3 flex-shrink-0 bg-raja-ivory/60">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-5 py-2.5 rounded-xl border border-raja-ink-border font-bold text-xs hover:bg-white transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-raja-maroon text-white font-bold text-xs hover:bg-raja-maroon-light shadow-md transition-all"
              >
                Save Product
              </button>
            </div>
          </form>
        </div>
      </div>
    )}

      {/* Order Status Update Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-[100] bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-hidden">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-raja-gold/40 flex flex-col max-h-[92vh] overflow-hidden text-xs">
            <div className="p-4 sm:p-5 border-b border-raja-ink-border flex items-center justify-between flex-shrink-0 bg-white">
              <div>
                <h3 className="font-serif text-base font-bold text-raja-maroon">
                  Fulfil Order #{selectedOrder.orderNumber}
                </h3>
                <p className="text-[11px] text-raja-ink-muted">
                  Customer: {selectedOrder.customer.fullName} ({selectedOrder.customer.phone})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="p-1.5 rounded-full text-raja-ink-muted hover:text-raja-ink hover:bg-raja-ivory transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
              <div>
                <label className="font-bold text-raja-ink block mb-1">Fulfilment Status</label>
                <select
                  value={orderStatusUpdate}
                  onChange={(e) => setOrderStatusUpdate(e.target.value as Order["orderStatus"])}
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border bg-white"
                >
                  <option value="placed">Placed (New Order)</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="processing">Processing &amp; Weave Inspection</option>
                  <option value="shipped">Shipped (Dispatched with Courier)</option>
                  <option value="delivered">Delivered to Customer</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-raja-ink block mb-1">Payment Status</label>
                <select
                  value={paymentStatusUpdate}
                  onChange={(e) => setPaymentStatusUpdate(e.target.value as Order["paymentStatus"])}
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border bg-white"
                >
                  <option value="pending">Pending</option>
                  <option value="verified">Verified &amp; Paid</option>
                  <option value="failed">Failed</option>
                  <option value="refunded">Refunded</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-raja-ink block mb-1">Courier Partner</label>
                <select
                  value={courierNameInput}
                  onChange={(e) => setCourierNameInput(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border bg-white"
                >
                  <option value="Professional Courier">Professional Courier</option>
                  <option value="ST Courier">ST Courier (South India Express)</option>
                  <option value="India Post Speed Post">India Post Speed Post</option>
                  <option value="DTDC">DTDC Courier</option>
                  <option value="Delhivery">Delhivery</option>
                  <option value="Blue Dart">Blue Dart</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-raja-ink block mb-1">Courier AWB / Tracking Number</label>
                <input
                  type="text"
                  value={trackingNumberInput}
                  onChange={(e) => setTrackingNumberInput(e.target.value)}
                  placeholder="e.g. SLM98231456"
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                />
              </div>
            </div>

            <div className="p-3.5 sm:p-4 border-t border-raja-ink-border flex items-center justify-end gap-3 flex-shrink-0 bg-raja-ivory/60">
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="px-5 py-2.5 rounded-xl border border-raja-ink-border font-bold text-xs hover:bg-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUpdateOrderStatus}
                className="px-6 py-2.5 rounded-xl bg-raja-maroon text-white font-bold text-xs hover:bg-raja-maroon-light shadow-sm"
              >
                Save Order Status
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit / Add Hero Slide Modal */}
      {isEditingHeroSlide && editingHeroSlide && (
        <div className="fixed inset-0 z-[100] bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-hidden">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-raja-gold/40 flex flex-col max-h-[92vh] overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-raja-ink-border flex items-center justify-between flex-shrink-0 bg-white">
              <div>
                <h3 className="font-serif text-lg font-bold text-raja-maroon">
                  {editingHeroSlide.id ? "Edit Hero Slide / Banner" : "Add Advertisement / Hero Banner"}
                </h3>
                <p className="text-[11px] text-raja-ink-soft">
                  Configure headline, campaign badge, link destination, and raw image URL.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsEditingHeroSlide(false)}
                className="p-1.5 rounded-full text-raja-ink-muted hover:text-raja-ink hover:bg-raja-ivory transition-colors"
                title="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveHeroSlide} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs overscroll-contain">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-raja-ink block mb-1">Slide Type *</label>
                    <select
                      value={editingHeroSlide.type || "advertisement"}
                      onChange={(e) =>
                        setEditingHeroSlide({
                          ...editingHeroSlide,
                          type: e.target.value as HeroSlide["type"],
                        })
                      }
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border bg-white"
                    >
                      <option value="advertisement">Promo / Advertisement Banner</option>
                      <option value="product">Featured Product</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-raja-ink block mb-1">Top Badge / Tagline *</label>
                    <input
                      type="text"
                      required
                      value={editingHeroSlide.badge || ""}
                      onChange={(e) =>
                        setEditingHeroSlide({ ...editingHeroSlide, badge: e.target.value })
                      }
                      placeholder="e.g. Festival Special 60% OFF"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Slide Headline Title *</label>
                  <input
                    type="text"
                    required
                    value={editingHeroSlide.title || ""}
                    onChange={(e) =>
                      setEditingHeroSlide({ ...editingHeroSlide, title: e.target.value })
                    }
                    placeholder="e.g. Salem Wedding Grandeur Mela"
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-raja-ink block mb-1">Tamil Title / Sub-badge</label>
                    <input
                      type="text"
                      value={editingHeroSlide.tamilTitle || ""}
                      onChange={(e) =>
                        setEditingHeroSlide({ ...editingHeroSlide, tamilTitle: e.target.value })
                      }
                      placeholder="e.g. சிறப்பு தள்ளுபடி"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-raja-ink block mb-1">Offer Badge Text</label>
                    <input
                      type="text"
                      value={editingHeroSlide.discountBadge || ""}
                      onChange={(e) =>
                        setEditingHeroSlide({ ...editingHeroSlide, discountBadge: e.target.value })
                      }
                      placeholder="e.g. Up to 70% OFF or From ₹499"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-raja-ink block mb-1">Subtitle / Campaign Description *</label>
                  <textarea
                    rows={2}
                    required
                    value={editingHeroSlide.subtitle || ""}
                    onChange={(e) =>
                      setEditingHeroSlide({ ...editingHeroSlide, subtitle: e.target.value })
                    }
                    placeholder="e.g. Authentic handlooms crafted in Elampillai with pure gold zari borders."
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                  />
                </div>

                {/* HERO SLIDE BANNER IMAGE WITH FILE UPLOAD AND URL */}
                <div className="p-3.5 rounded-xl bg-raja-ivory/60 border border-raja-gold/40 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-raja-maroon flex items-center gap-1.5 text-xs">
                      <ImageIcon className="w-4 h-4 text-raja-gold" />
                      <span>Banner Image *</span>
                    </label>
                    <span className="text-[10px] text-raja-ink-muted">Device Upload or Direct URL</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label className="cursor-pointer border-2 border-dashed border-raja-gold/60 hover:border-raja-maroon bg-white/90 hover:bg-raja-gold/10 rounded-xl p-2.5 flex items-center justify-center gap-2 transition-all group">
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleUploadHeroImage(e.target.files)}
                        disabled={heroImageProcessing}
                      />
                      {heroImageProcessing ? (
                        <Loader2 className="w-4 h-4 text-raja-maroon animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4 text-raja-maroon group-hover:scale-110 transition-transform" />
                      )}
                      <span className="text-[11px] font-bold text-raja-ink">
                        {heroImageProcessing ? "Processing..." : "Upload Banner File"}
                      </span>
                    </label>

                    <input
                      type="text"
                      required
                      value={heroRawImageUrl}
                      onChange={(e) => setHeroRawImageUrl(e.target.value)}
                      placeholder="Or paste URL (https://...)"
                      className="p-2.5 rounded-xl border border-raja-ink-border bg-white font-mono text-[11px]"
                    />
                  </div>

                  {/* Live Banner Preview */}
                  {heroRawImageUrl && (
                    <div className="relative aspect-[21/9] rounded-xl border border-raja-ink-border bg-raja-ivory overflow-hidden">
                      <img
                        src={heroRawImageUrl}
                        alt="Hero Banner Preview"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg";
                        }}
                      />
                      <span className="absolute bottom-2 left-2 text-[10px] bg-black/60 text-white px-2 py-0.5 rounded backdrop-blur-sm">
                        Live Preview
                      </span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-raja-ink block mb-1">Target Link Destination *</label>
                    <input
                      type="text"
                      required
                      value={editingHeroSlide.linkUrl || "/collection"}
                      onChange={(e) =>
                        setEditingHeroSlide({ ...editingHeroSlide, linkUrl: e.target.value })
                      }
                      placeholder="e.g. /collection or /category/mens-garments"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-raja-ink block mb-1">Button Action Text</label>
                    <input
                      type="text"
                      value={editingHeroSlide.buttonText || "Shop Offer"}
                      onChange={(e) =>
                        setEditingHeroSlide({ ...editingHeroSlide, buttonText: e.target.value })
                      }
                      placeholder="e.g. Shop Festive Sale"
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-raja-ink block mb-1">Display Order Position</label>
                    <input
                      type="number"
                      value={editingHeroSlide.order || 1}
                      onChange={(e) =>
                        setEditingHeroSlide({ ...editingHeroSlide, order: Number(e.target.value) })
                      }
                      className="w-full p-2.5 rounded-lg border border-raja-ink-border"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-6">
                    <input
                      type="checkbox"
                      id="heroSlideActive"
                      checked={editingHeroSlide.isActive !== false}
                      onChange={(e) =>
                        setEditingHeroSlide({ ...editingHeroSlide, isActive: e.target.checked })
                      }
                      className="w-4 h-4 text-raja-maroon rounded"
                    />
                    <label htmlFor="heroSlideActive" className="font-bold text-raja-ink cursor-pointer">
                      Active (Show in Hero Slider)
                    </label>
                  </div>
                </div>
              </div>

              <div className="p-3.5 sm:p-4 border-t border-raja-ink-border flex items-center justify-end gap-3 flex-shrink-0 bg-raja-ivory/60">
                <button
                  type="button"
                  onClick={() => setIsEditingHeroSlide(false)}
                  className="px-5 py-2.5 rounded-xl border border-raja-ink-border font-bold text-xs hover:bg-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-raja-maroon text-white font-bold text-xs hover:bg-raja-maroon-light shadow-sm"
                >
                  Save Hero Slide
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
