"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { Sparkles, AlertCircle } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";

function AuthCallbackContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function handleAuth() {
      // 1. Check for OAuth error in URL query
      const errorDesc = searchParams.get("error_description") || searchParams.get("error");
      if (errorDesc) {
        if (isMounted) setError(errorDesc);
        setTimeout(() => router.replace(`/auth/login?error=${encodeURIComponent(errorDesc)}`), 2500);
        return;
      }

      if (!isSupabaseConfigured || !supabase) {
        if (isMounted) setError("Supabase is not configured.");
        setTimeout(() => router.replace("/auth/login"), 2000);
        return;
      }

      const next = searchParams.get("next") || "/account";
      const code = searchParams.get("code");

      try {
        // 2. If code exists in query params (PKCE flow), exchange it in the browser
        if (code) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
          if (exchangeError) {
            console.error("Code exchange error:", exchangeError);
          }
        }

        // 3. Verify session in client browser (works for both PKCE and hash fragments)
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession();

        if (sessionError) {
          throw sessionError;
        }

        if (session) {
          // Sync profile if user metadata has full_name
          const user = session.user;
          if (user) {
            try {
              const fullName =
                user.user_metadata?.full_name ||
                user.user_metadata?.name ||
                user.email?.split("@")[0] ||
                "Customer";

              await supabase.from("profiles").upsert(
                {
                  id: user.id,
                  email: user.email,
                  full_name: fullName,
                  updated_at: new Date().toISOString(),
                },
                { onConflict: "id" }
              );
            } catch {
              // Non-blocking
            }
          }

          router.replace(next);
          return;
        }

        // 4. Fallback listener for hash fragments if getSession wasn't ready yet
        const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
          if (session && (event === "SIGNED_IN" || event === "TOKEN_REFRESHED")) {
            authListener.subscription.unsubscribe();
            router.replace(next);
          }
        });

        // 5. Safety timeout: if after 3.5 seconds still no session, redirect to account
        setTimeout(() => {
          if (isMounted) {
            router.replace(next);
          }
        }, 3500);
      } catch (err: any) {
        if (isMounted) setError(err.message || "Failed to complete authentication.");
        setTimeout(
          () => router.replace(`/auth/login?error=${encodeURIComponent(err.message || "Auth failed")}`),
          2500
        );
      }
    }

    handleAuth();

    return () => {
      isMounted = false;
    };
  }, [searchParams, router]);

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-12 px-4 bg-raja-ivory">
      <div className="max-w-md w-full bg-white p-8 sm:p-10 rounded-2xl border border-raja-ink-border shadow-luxury text-center space-y-6">
        <BrandLogo variant="auth" withLink={false} />

        {error ? (
          <div className="space-y-3">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-700 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h2 className="font-serif text-xl font-bold text-red-800">
              Authentication Notice
            </h2>
            <p className="text-xs text-raja-ink-soft leading-relaxed">{error}</p>
            <p className="text-[11px] text-raja-ink-muted">Redirecting you to login...</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-2 border-raja-gold/20 border-t-raja-maroon animate-spin" />
              <Sparkles className="w-6 h-6 text-raja-gold animate-pulse" />
            </div>
            <div className="space-y-1">
              <h2 className="font-serif text-2xl font-bold text-raja-maroon">
                Signing you in...
              </h2>
              <p className="text-xs text-raja-ink-soft">
                Verifying your Google credentials with Raja Textile master looms.
              </p>
            </div>
            <div className="pt-2">
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Direct Handloom Heritage • Salem, Tamil Nadu
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AuthCallbackPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[85vh] flex items-center justify-center bg-raja-ivory">
          <div className="w-10 h-10 border-2 border-raja-gold border-t-raja-maroon rounded-full animate-spin" />
        </div>
      }
    >
      <AuthCallbackContent />
    </Suspense>
  );
}
