import React from "react";
import Link from "next/link";
import { STORE_SETTINGS } from "@/data/products";

export default function ShippingPolicyPage() {
  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 bg-white p-8 sm:p-12 rounded-2xl border border-raja-ink-border shadow-sm">
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-raja-gold">
            Delivery Information
          </span>
          <h1 className="font-serif text-3xl font-bold text-raja-maroon mt-1">
            Shipping & Pan-India Delivery Policy
          </h1>
          <p className="text-xs text-raja-ink-muted mt-1">
            Last updated: October 2026 • Dispatched from Elampillai, Salem
          </p>
        </div>

        <div className="space-y-6 text-xs text-raja-ink-soft leading-relaxed">
          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              1. Direct Loom Dispatch Timeline
            </h2>
            <p>
              All sarees ordered from Raja Textile are packed directly at our loom facilities in
              Elampillai, Salem, Tamil Nadu. Orders placed before 3:00 PM IST on working days are
              dispatched within <strong>24 to 48 hours</strong> after undergoing a strict multi-point
              artisan quality check.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              2. Delivery Timelines by Region
            </h2>
            <ul className="list-disc list-inside space-y-1.5 pl-2">
              <li>
                <strong>Tamil Nadu & Pondicherry:</strong> 2 to 3 business days (Speed Post / ST Courier / Professional Courier).
              </li>
              <li>
                <strong>Karnataka, Kerala, Andhra Pradesh & Telangana:</strong> 3 to 4 business days.
              </li>
              <li>
                <strong>Rest of India (North, West & East):</strong> 4 to 6 business days.
              </li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              3. Delivery Charges
            </h2>
            <p>
              • <strong>Free Pan-India Delivery</strong> on all orders of <strong>₹{STORE_SETTINGS.freeShippingThreshold}</strong> or more.
              <br />
              • For orders below ₹{STORE_SETTINGS.freeShippingThreshold}, a nominal delivery fee of <strong>₹{STORE_SETTINGS.shippingFee}</strong> is applied at checkout.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              4. Tracking Your Parcel
            </h2>
            <p>
              As soon as your saree is handed over to our logistics partner in Salem, you will receive an SMS and WhatsApp message with your courier tracking link and AWB number. You can also track your order anytime via our{" "}
              <Link href="/track-order" className="text-raja-maroon underline font-medium">
                Track Order portal
              </Link>
              .
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              5. Queries & Assistance
            </h2>
            <p>
              For any urgent delivery assistance, please message our support desk on WhatsApp at{" "}
              <strong>+91 93600 21627</strong> or call between 9:30 AM and 9:00 PM IST.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
