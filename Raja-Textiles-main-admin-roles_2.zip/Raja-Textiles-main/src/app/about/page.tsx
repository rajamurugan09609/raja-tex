import React from "react";
import { MessageCircle } from "lucide-react";
import { STORE_SETTINGS } from "@/data/products";

export default function AboutPage() {
  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="text-center space-y-4">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-raja-gold">
            Elampillai Handloom Tradition
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-raja-maroon">
            The Living Heritage of Salem Weavers
          </h1>
          <p className="text-sm text-raja-ink-soft max-w-2xl mx-auto leading-relaxed">
            For generations, the rhythmic clatter of jacquard looms has defined daily life in Elampillai.
            At Raja Textile, we bring that legacy of intricate zari craftsmanship directly to families worldwide.
          </p>
        </div>

        {/* Feature Image & Mission */}
        <div className="bg-white rounded-2xl border border-raja-ink-border overflow-hidden shadow-sm">
          <img
            src="/images/products/fbabaa2126da87b707a75408119bb842.jpg"
            alt="Handcrafted sarees of Raja Textile Elampillai"
            className="w-full h-72 md:h-96 object-cover"
          />
          <div className="p-8 sm:p-10 space-y-4">
            <h2 className="font-serif text-2xl font-bold text-raja-ink">
              Direct from the Loom to Your Celebrations
            </h2>
            <p className="text-sm text-raja-ink-soft leading-relaxed">
              Traditional retail showrooms add layers of distribution costs, wholesaler margins, and showroom overheads.
              By establishing our direct online portal from Elampillai, Raja Textile bridges the gap between master artisans
              and saree lovers. Every saree you purchase directly sustains the weaving families of Salem.
            </p>
          </div>
        </div>

        {/* Core Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl border border-raja-ink-border shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center font-bold">
              1
            </div>
            <h3 className="font-serif text-base font-bold text-raja-ink">
              Authentic Jacquard Precision
            </h3>
            <p className="text-xs text-raja-ink-soft leading-relaxed">
              Every Kolam motif and 3D floral butta is woven into the warp and weft—never stamped or printed.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-raja-ink-border shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center font-bold">
              2
            </div>
            <h3 className="font-serif text-base font-bold text-raja-ink">
              Lightweight Comfortable Drape
            </h3>
            <p className="text-xs text-raja-ink-soft leading-relaxed">
              Engineered with 80&apos;s warp Karizma and soft silk blends that stay crease-resistant throughout day-long rituals.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-raja-ink-border shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center font-bold">
              3
            </div>
            <h3 className="font-serif text-base font-bold text-raja-ink">
              WhatsApp Video Consultation
            </h3>
            <p className="text-xs text-raja-ink-soft leading-relaxed">
              Experience the sarees on live video before buying. See true drape, fall, and metallic zari shine.
            </p>
          </div>
        </div>

        {/* Direct Contact Banner */}
        <div className="bg-raja-wine text-white rounded-2xl p-8 sm:p-10 text-center space-y-4">
          <h2 className="font-serif text-2xl font-bold">
            Visit Our Flagship Store in Elampillai, Salem
          </h2>
          <p className="text-xs sm:text-sm text-raja-ivory/80 max-w-md mx-auto">
            {STORE_SETTINGS.address}, {STORE_SETTINGS.city} — {STORE_SETTINGS.pincode}.
            <br />
            {STORE_SETTINGS.operatingHours}
          </p>
          <div className="pt-2">
            <a
              href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20would%20like%20to%20plan%20a%20visit%20to%20your%20Elampillai%20store.`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded bg-raja-gold text-raja-wine font-semibold text-xs hover:bg-raja-gold-light transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Connect with Master Weavers on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
