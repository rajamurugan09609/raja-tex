"use client";

import React from "react";
import Link from "next/link";
import { Heart, ShoppingBag, Trash2, ArrowRight } from "lucide-react";
import { useWishlist } from "@/context/WishlistContext";
import { useCart } from "@/context/CartContext";
import { Product } from "@/types";

export default function WishlistPage() {
  const { wishlist, toggleWishlist, wishlistCount } = useWishlist();
  const { addToCart } = useCart();

  const handleMoveToBag = (product: Product) => {
    addToCart(product, product.colors?.[0]?.name || "Standard", 1);
    toggleWishlist(product);
  };

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <nav className="text-xs text-raja-ink-muted mb-2 flex items-center gap-2">
            <Link href="/" className="hover:text-raja-maroon">Home</Link>
            <span>/</span>
            <span className="text-raja-maroon font-medium">My Wishlist</span>
          </nav>

          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-raja-maroon">
            Saved Weaves ({wishlistCount})
          </h1>
          <p className="text-xs sm:text-sm text-raja-ink-soft mt-1">
            Keep track of your favorite Elampillai weaves and order whenever you are ready.
          </p>
        </div>

        {wishlist.length === 0 ? (
          <div className="bg-white rounded-2xl border border-raja-ink-border p-12 text-center max-w-lg mx-auto space-y-4">
            <div className="w-16 h-16 rounded-full bg-raja-maroon/10 text-raja-maroon flex items-center justify-center mx-auto">
              <Heart className="w-8 h-8" />
            </div>
            <h2 className="font-serif text-xl font-bold text-raja-ink">
              Your wishlist is empty
            </h2>
            <p className="text-xs text-raja-ink-soft">
              Explore our textile collections and click the heart icon on any weave to save it here.
            </p>
            <Link
              href="/collection"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded bg-raja-maroon text-white text-xs font-semibold hover:bg-raja-maroon-light transition-colors"
            >
              <span>Explore Collections</span>
              <ArrowRight className="w-3.5 h-3.5 text-raja-gold" />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {wishlist.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-xl border border-raja-ink-border overflow-hidden shadow-sm flex flex-col justify-between"
              >
                <div className="relative aspect-[4/5] bg-raja-ivory overflow-hidden">
                  <Link href={`/products/${product.slug}`}>
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </Link>

                  <button
                    onClick={() => toggleWishlist(product)}
                    className="absolute top-3 right-3 p-2 rounded-full bg-white/90 text-red-700 hover:bg-white shadow-sm"
                    aria-label="Remove from wishlist"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-raja-gold font-bold uppercase tracking-wider">
                      {product.category}
                    </span>
                    <h3 className="font-serif text-base font-semibold text-raja-ink hover:text-raja-maroon transition-colors line-clamp-1 mt-0.5">
                      <Link href={`/products/${product.slug}`}>{product.name}</Link>
                    </h3>
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className="text-base font-bold text-raja-maroon">
                        ₹{product.price.toLocaleString("en-IN")}
                        {product.unit === "meter" && <span className="font-normal text-xs text-raja-ink-muted ml-0.5">/m</span>}
                      </span>
                      <span className="text-xs text-raja-ink-muted line-through">
                        ₹{product.originalPrice.toLocaleString("en-IN")}
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 mt-3 border-t border-raja-ink-border">
                    <button
                      onClick={() => handleMoveToBag(product)}
                      className="w-full py-2.5 px-3 rounded bg-raja-maroon hover:bg-raja-maroon-light text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <ShoppingBag className="w-3.5 h-3.5 text-raja-gold" />
                      <span>Move to Bag</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
