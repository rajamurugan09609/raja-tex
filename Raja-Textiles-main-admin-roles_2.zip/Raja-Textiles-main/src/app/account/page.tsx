"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  User,
  Package,
  MapPin,
  LogOut,
  Plus,
  Trash2,
  ExternalLink,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { Order, Address } from "@/types";

export default function AccountPage() {
  const router = useRouter();
  const { user, profile, signOut, saveAddress, deleteAddress, isLoading, isOwner, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<"orders" | "addresses" | "profile">("orders");
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);

  // New Address Form State
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [addressForm, setAddressForm] = useState<Omit<Address, "id">>({
    label: "Home",
    fullName: "",
    phone: "",
    addressLine1: "",
    city: "Salem",
    state: "Tamil Nadu",
    pincode: "",
  });

  // Redirect if not signed in after loading
  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/auth/login");
    }
  }, [user, isLoading, router]);

  // Fetch orders for this customer
  useEffect(() => {
    if (user?.email) {
      fetch(`/api/orders?email=${encodeURIComponent(user.email)}&userId=${user.id}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.orders) {
            setOrders(data.orders);
          }
        })
        .catch(() => {})
        .finally(() => setLoadingOrders(false));
    }
  }, [user]);

  if (isLoading || !user) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center bg-raja-ivory">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-2 border-raja-gold border-t-raja-maroon rounded-full animate-spin mx-auto" />
          <p className="text-xs text-raja-ink-soft">Loading your account details...</p>
        </div>
      </div>
    );
  }

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addressForm.fullName || !addressForm.addressLine1 || !addressForm.pincode) return;
    await saveAddress(addressForm);
    setShowAddressModal(false);
    setAddressForm({
      label: "Home",
      fullName: "",
      phone: "",
      addressLine1: "",
      city: "Salem",
      state: "Tamil Nadu",
      pincode: "",
    });
  };

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Profile Banner */}
        <div className="bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-8 shadow-sm mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-raja-wine text-white flex items-center justify-center font-serif text-2xl font-bold shadow-gold-sm border border-raja-gold/40">
              {(profile?.fullName || user.email || "R").charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif text-2xl font-bold text-raja-maroon">
                  {profile?.fullName || "Valued Customer"}
                </h1>
                {isAdmin && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300">
                    {isOwner ? "Main Admin" : "Admin"}
                  </span>
                )}
              </div>
              <p className="text-xs text-raja-ink-soft mt-0.5">{user.email}</p>
              <p className="text-[11px] text-raja-gold-dark font-medium mt-1">
                Direct Weaving Patron • Salem, Tamil Nadu
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-stretch sm:self-auto">
            {isAdmin && (
              <Link
                href="/owner"
                className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-raja-wine text-white text-xs font-bold hover:bg-raja-maroon transition-colors shadow-sm"
              >
                <span>{isOwner ? "Owner Portal" : "Admin Portal"}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            )}

            <button
              onClick={() => signOut()}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-raja-ink-border bg-raja-ivory text-xs font-semibold text-raja-ink hover:text-red-700 hover:border-red-300 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* Dashboard Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-raja-ink-border mb-8 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab("orders")}
            className={`pb-3 px-4 text-xs uppercase tracking-wider font-bold transition-all relative flex items-center gap-2 ${
              activeTab === "orders"
                ? "text-raja-maroon border-b-2 border-raja-maroon"
                : "text-raja-ink-muted hover:text-raja-ink"
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Order History ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("addresses")}
            className={`pb-3 px-4 text-xs uppercase tracking-wider font-bold transition-all relative flex items-center gap-2 ${
              activeTab === "addresses"
                ? "text-raja-maroon border-b-2 border-raja-maroon"
                : "text-raja-ink-muted hover:text-raja-ink"
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Saved Addresses ({profile?.addresses?.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab("profile")}
            className={`pb-3 px-4 text-xs uppercase tracking-wider font-bold transition-all relative flex items-center gap-2 ${
              activeTab === "profile"
                ? "text-raja-maroon border-b-2 border-raja-maroon"
                : "text-raja-ink-muted hover:text-raja-ink"
            }`}
          >
            <User className="w-4 h-4" />
            <span>Profile & Security</span>
          </button>
        </div>

        {/* TAB 1: ORDER HISTORY */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            {loadingOrders ? (
              <div className="bg-white p-12 text-center rounded-2xl border border-raja-ink-border">
                <div className="w-8 h-8 border-2 border-raja-gold border-t-raja-maroon rounded-full animate-spin mx-auto mb-2" />
                <p className="text-xs text-raja-ink-soft">Loading your order history...</p>
              </div>
            ) : orders.length === 0 ? (
              <div className="bg-white p-12 sm:p-16 text-center rounded-2xl border border-raja-ink-border space-y-4">
                <div className="w-16 h-16 rounded-full bg-raja-ivory flex items-center justify-center mx-auto text-raja-gold">
                  <Package className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-raja-ink">
                  No orders placed yet
                </h3>
                <p className="text-xs sm:text-sm text-raja-ink-soft max-w-sm mx-auto">
                  Discover authentic 3D embossed silks, running fabrics, and traditional bridal drapes direct from Elampillai looms.
                </p>
                <Link
                  href="/products"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-raja-maroon text-white font-bold text-xs uppercase tracking-wider hover:bg-raja-maroon-light shadow-md transition-all"
                >
                  <span>Explore Textile Collection</span>
                  <ArrowRight className="w-3.5 h-3.5 text-raja-gold" />
                </Link>
              </div>
            ) : (
              orders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white rounded-2xl border border-raja-ink-border shadow-sm p-6 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-raja-ink-border">
                    <div>
                      <div className="flex items-center gap-2.5">
                        <span className="font-serif text-lg font-bold text-raja-maroon">
                          Order #{order.orderNumber}
                        </span>
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                            order.paymentStatus === "verified"
                              ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
                              : "bg-amber-50 text-amber-800 border border-amber-200"
                          }`}
                        >
                          Payment: {order.paymentStatus}
                        </span>
                      </div>
                      <p className="text-[11px] text-raja-ink-muted mt-0.5">
                        Placed on {new Date(order.createdAt).toLocaleDateString("en-IN", { dateStyle: "long" })}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-raja-ink">
                        ₹{order.pricing?.total?.toLocaleString("en-IN")}
                      </span>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-raja-maroon-subtle text-raja-maroon">
                        Status: {order.orderStatus.toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {/* Order Items List */}
                  <div className="space-y-3">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 text-xs">
                        <img
                          src={item.image || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"}
                          alt={item.name}
                          className="w-14 h-16 object-cover rounded-lg bg-raja-ivory flex-shrink-0"
                        />
                        <div className="flex-1">
                          <h4 className="font-serif font-bold text-raja-ink">{item.name}</h4>
                          <p className="text-raja-ink-muted text-[11px]">
                            Color: {item.selectedColor} · Qty: {item.quantity}
                          </p>
                        </div>
                        <span className="font-semibold text-raja-maroon">
                          ₹{item.subtotal?.toLocaleString("en-IN")}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Tracking info if dispatched */}
                  {order.trackingNumber && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-emerald-700" />
                        <span>
                          Shipped via <strong>{order.courierName || "Express Courier"}</strong> · AWB:{" "}
                          <strong>{order.trackingNumber}</strong>
                        </span>
                      </div>
                      <Link
                        href={`/track-order?awb=${order.trackingNumber}`}
                        className="text-xs font-bold text-emerald-800 hover:underline flex items-center gap-1"
                      >
                        <span>Track</span>
                        <ExternalLink className="w-3 h-3" />
                      </Link>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 2: SAVED ADDRESSES */}
        {activeTab === "addresses" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-serif text-xl font-bold text-raja-ink">Delivery Addresses</h2>
              <button
                onClick={() => setShowAddressModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-raja-maroon text-white text-xs font-bold hover:bg-raja-maroon-light transition-colors shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Address</span>
              </button>
            </div>

            {(!profile?.addresses || profile.addresses.length === 0) ? (
              <div className="bg-white p-12 text-center rounded-2xl border border-raja-ink-border space-y-3">
                <MapPin className="w-8 h-8 text-raja-gold mx-auto" />
                <p className="text-sm font-bold text-raja-ink">No saved addresses</p>
                <p className="text-xs text-raja-ink-soft">
                  Add your primary delivery address for one-click checkout.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {profile.addresses.map((addr) => (
                  <div
                    key={addr.id}
                    className="bg-white p-5 rounded-2xl border border-raja-ink-border relative space-y-2 shadow-sm"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded bg-raja-ivory text-raja-maroon border border-raja-ink-border">
                        {addr.label}
                      </span>
                      <button
                        onClick={() => deleteAddress(addr.id)}
                        className="text-raja-ink-muted hover:text-red-700 p-1"
                        title="Delete address"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <h3 className="font-bold text-sm text-raja-ink">{addr.fullName}</h3>
                    <p className="text-xs text-raja-ink-soft leading-relaxed">
                      {addr.addressLine1}
                      {addr.addressLine2 && `, ${addr.addressLine2}`}
                      {addr.landmark && ` (Near ${addr.landmark})`}
                      <br />
                      {addr.city}, {addr.state} — {addr.pincode}
                    </p>
                    <p className="text-xs text-raja-ink font-medium">Phone: {addr.phone}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: PROFILE & SECURITY */}
        {activeTab === "profile" && (
          <div className="max-w-xl bg-white p-8 rounded-2xl border border-raja-ink-border shadow-sm space-y-6">
            <h2 className="font-serif text-xl font-bold text-raja-ink">Profile Details</h2>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-raja-ink-muted block text-[11px] uppercase font-bold mb-1">
                  Full Name
                </label>
                <p className="font-semibold text-sm text-raja-ink">{profile?.fullName || "Not provided"}</p>
              </div>

              <div>
                <label className="text-raja-ink-muted block text-[11px] uppercase font-bold mb-1">
                  Registered Email Address
                </label>
                <p className="font-semibold text-sm text-raja-ink">{user.email}</p>
              </div>

              <div>
                <label className="text-raja-ink-muted block text-[11px] uppercase font-bold mb-1">
                  Registered Phone
                </label>
                <p className="font-semibold text-sm text-raja-ink">{profile?.phone || "Not linked yet"}</p>
              </div>

              <div className="pt-4 border-t border-raja-ink-border">
                <Link
                  href="/auth/forgot-password"
                  className="text-xs font-bold text-raja-maroon hover:underline"
                >
                  Change Password / Security Reset →
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Address Modal */}
      {showAddressModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-raja-gold/30">
            <h3 className="font-serif text-lg font-bold text-raja-maroon mb-4">
              Add Delivery Address
            </h3>
            <form onSubmit={handleSaveAddress} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-raja-ink block mb-1">Contact Name *</label>
                <input
                  type="text"
                  required
                  value={addressForm.fullName}
                  onChange={(e) => setAddressForm({ ...addressForm, fullName: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:outline-none focus:border-raja-maroon"
                />
              </div>

              <div>
                <label className="font-bold text-raja-ink block mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={addressForm.phone}
                  onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:outline-none focus:border-raja-maroon"
                />
              </div>

              <div>
                <label className="font-bold text-raja-ink block mb-1">Street / House Address *</label>
                <textarea
                  required
                  rows={2}
                  value={addressForm.addressLine1}
                  onChange={(e) => setAddressForm({ ...addressForm, addressLine1: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:outline-none focus:border-raja-maroon"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-raja-ink block mb-1">City *</label>
                  <input
                    type="text"
                    required
                    value={addressForm.city}
                    onChange={(e) => setAddressForm({ ...addressForm, city: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:outline-none focus:border-raja-maroon"
                  />
                </div>
                <div>
                  <label className="font-bold text-raja-ink block mb-1">6-Digit PIN Code *</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={addressForm.pincode}
                    onChange={(e) => setAddressForm({ ...addressForm, pincode: e.target.value.replace(/\D/g, "") })}
                    className="w-full p-2.5 rounded-lg border border-raja-ink-border focus:outline-none focus:border-raja-maroon"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddressModal(false)}
                  className="flex-1 py-2.5 rounded-lg border border-raja-ink-border font-bold text-raja-ink-soft hover:bg-raja-ivory"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-lg bg-raja-maroon text-white font-bold hover:bg-raja-maroon-light shadow-sm"
                >
                  Save Address
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
