import React from "react";
import Link from "next/link";
import { Metadata } from "next";
import { Sparkles, ArrowRight, ShieldCheck, Truck, RefreshCw, Scissors } from "lucide-react";
import { CATEGORIES } from "@/data/products";
import { getProducts } from "@/lib/db";
import { TextileDepartment } from "@/types";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export const metadata: Metadata = {
  title: "Textile Collections | Raja Textile Elampillai",
  description:
    "Explore our complete textile archive: Authentic Elampillai Silk Sarees, Pure Mulberry Raw Silk Fabrics, Unstitched Salwar Suits, Men's Silk Dhotis, and Handcrafted Home Furnishings.",
};

const DEPARTMENTS: {
  id: TextileDepartment;
  title: string;
  tamilTitle: string;
  tagline: string;
  description: string;
  image: string;
  badge: string;
}[] = [
  {
    id: "Sarees",
    title: "Elampillai Silk Sarees",
    tamilTitle: "இளம்பிள்ளை பட்டு சேலைகள்",
    tagline: "Karizma 3D, Vintage Kolam & Wedding Silks",
    description:
      "Renowned worldwide for featherlight drapes, 80's combed yarn, intricate golden zari buttas, and contrast jacquard pallus woven directly on the master looms of Elampillai.",
    image: "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
    badge: "Master Loom Specialty",
  },
  {
    id: "Fabrics",
    title: "Silk Fabrics & Running Yardage",
    tamilTitle: "பட்டு துணி ரகங்கள் (மீட்டர்)",
    tagline: "Mulberry Raw Silk, Brocade & Blouse Material",
    description:
      "Premium running yardage sold per meter for bespoke bridal blouses, couture lehengas, kurtas, and custom tailoring. Woven with authentic gold and antique zari threads.",
    image: "/images/products/93ceaae9391b962ddae5bf7fb34aea97.jpg",
    badge: "Sold by the Meter",
  },
  {
    id: "Dress Materials",
    title: "Unstitched Suit Sets & Dress Materials",
    tamilTitle: "சுடிதார் துணிகள்",
    tagline: "3-Piece Soft Silk Sets with Jacquard Dupattas",
    description:
      "Handcrafted three-piece salwar suit materials featuring soft silk tops with intricate zari neck work, premium bottom fabrics, and grand woven full-length jacquard dupattas.",
    image: "/images/products/affdee654a37eb21f6c1244b0ecf4e4d.jpg",
    badge: "3-Piece Festive Sets",
  },
  {
    id: "Garments",
    title: "Men's Traditional Silk Dhotis & Veshtis",
    tamilTitle: "வேஷ்டி & அங்களவஸ்திரம்",
    tagline: "Pure Silk Double Dhotis with Temple Borders",
    description:
      "Traditional South Indian wedding dhotis paired with matching angavastrams. Woven with rich golden Mayil and Mayilkan borders for auspicious weddings and festive pujas.",
    image: "/images/products/d3491e83863f4c3f7686c9daedcf312a.jpg",
    badge: "Auspicious Occasions",
  },
  {
    id: "Home Textiles",
    title: "Home Textiles & Living Furnishings",
    tamilTitle: "வீட்டு அலங்கார துணிகள்",
    tagline: "Jacquard Cushion Covers & Temple Drapes",
    description:
      "Elevate your home sanctuary with handcrafted jacquard silk cushion covers, festival temple hangings, and dining table runners woven with traditional South Indian motifs.",
    image: "/images/products/94e8ae5a574f711faa8642c263beae7b.jpg",
    badge: "Loom Home Living",
  },
];

export default async function CollectionPage() {
  const products = await getProducts();

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav className="text-xs text-raja-ink-muted mb-4 flex items-center gap-2">
          <Link href="/" className="hover:text-raja-maroon font-medium transition-colors">
            Home
          </Link>
          <span>/</span>
          <span className="text-raja-maroon font-bold">Textile Collections</span>
        </nav>

        {/* Editorial Header */}
        <div className="border-b border-raja-ink-border pb-10 mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs uppercase font-bold tracking-[0.25em] text-raja-gold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Salem Master Weaves · Elampillai</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-raja-maroon leading-tight max-w-4xl">
            Curated Textile Archives &amp; Departments
          </h1>
          <p className="text-sm sm:text-base text-raja-ink-soft mt-3 max-w-2xl leading-relaxed">
            Beyond our celebrated sarees, Raja Textile crafts high-density running yardage, festive unstitched salwar suits, auspicious wedding dhotis, and jacquard living furnishings direct from our family looms in Elampillai, Salem.
          </p>

          {/* Department Quick Filter Bar */}
          <div className="flex flex-wrap items-center gap-2.5 mt-8">
            <Link
              href="/products"
              className="px-4 py-2 rounded-full text-xs font-bold bg-raja-maroon text-white hover:bg-raja-maroon-light transition-all shadow-sm"
            >
              Browse All ({products.length})
            </Link>
            {DEPARTMENTS.map((dept) => {
              const count = products.filter((p) => p.department === dept.id).length;
              return (
                <Link
                  key={dept.id}
                  href={`/products?department=${encodeURIComponent(dept.id)}`}
                  className="px-4 py-2 rounded-full text-xs font-semibold bg-white text-raja-ink hover:text-raja-maroon border border-raja-ink-border hover:border-raja-gold transition-all shadow-sm flex items-center gap-1.5"
                >
                  <span>{dept.title.split(" ")[0]}</span>
                  <span className="text-[10px] text-raja-gold-dark font-bold bg-raja-gold/10 px-1.5 py-0.2 rounded-full">
                    {count}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Department Showcase Grid */}
        <div className="space-y-16">
          {DEPARTMENTS.map((dept, index) => {
            const deptProducts = products.filter((p) => p.department === dept.id);
            const deptCategories = CATEGORIES.filter((c) => c.department === dept.id);
            const isReversed = index % 2 === 1;

            return (
              <section
                key={dept.id}
                id={dept.id.toLowerCase().replace(/\s+/g, "-")}
                className="bg-white rounded-2xl border border-raja-ink-border overflow-hidden shadow-sm hover:shadow-luxury transition-all duration-300"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
                  {/* Department Visual Banner */}
                  <div
                    className={`lg:col-span-5 relative min-h-[300px] sm:min-h-[380px] bg-raja-ivory overflow-hidden ${
                      isReversed ? "lg:order-2" : "lg:order-1"
                    }`}
                  >
                    <img
                      src={dept.image}
                      alt={dept.title}
                      loading="lazy"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-raja-wine/80 via-raja-wine/20 to-transparent" />
                    
                    {/* Badge */}
                    <div className="absolute top-4 left-4 z-10">
                      <span className="bg-raja-maroon text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                        {dept.badge}
                      </span>
                    </div>

                    {/* Department Title Overlay */}
                    <div className="absolute bottom-6 left-6 right-6 text-white z-10">
                      <span className="text-raja-gold text-xs font-semibold tracking-widest block mb-1">
                        {dept.tamilTitle}
                      </span>
                      <h2 className="font-serif text-2xl sm:text-3xl font-bold leading-tight">
                        {dept.title}
                      </h2>
                      <p className="text-xs text-raja-ivory/80 mt-1">
                        {dept.tagline}
                      </p>
                    </div>
                  </div>

                  {/* Department Details & Actions */}
                  <div
                    className={`lg:col-span-7 p-6 sm:p-8 lg:p-10 flex flex-col justify-between ${
                      isReversed ? "lg:order-1" : "lg:order-2"
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between border-b border-raja-ink-border/60 pb-3 mb-4">
                        <span className="text-xs font-bold tracking-widest uppercase text-raja-gold-dark">
                          Department Archive · {dept.id}
                        </span>
                        <span className="text-xs font-semibold text-raja-ink-muted">
                          {deptProducts.length} Woven Designs
                        </span>
                      </div>

                      <p className="text-sm sm:text-base text-raja-ink-soft leading-relaxed mb-6">
                        {dept.description}
                      </p>

                      {/* Sub-categories */}
                      {deptCategories.length > 0 && (
                        <div className="mb-6">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-raja-ink mb-2">
                            Signature Weaves &amp; Styles:
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {deptCategories.map((c) => (
                              <Link
                                key={c.id}
                                href={`/products?category=${encodeURIComponent(c.name)}`}
                                className="text-xs px-3 py-1.5 rounded-lg bg-raja-ivory border border-raja-ink-border hover:border-raja-maroon hover:text-raja-maroon transition-colors"
                              >
                                {c.name}
                              </Link>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Sample Products Preview */}
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-raja-ink mb-3">
                          Loom Highlights:
                        </h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          {deptProducts.slice(0, 3).map((prod) => (
                            <Link
                              key={prod.id}
                              href={`/products/${prod.slug}`}
                              className="group block p-2 rounded-xl border border-raja-ink-border hover:border-raja-gold bg-raja-ivory/30 transition-all"
                            >
                              <div className="aspect-[4/3] rounded-lg overflow-hidden mb-2 bg-raja-ivory">
                                <img
                                  src={prod.images[0]}
                                  alt={prod.name}
                                  loading="lazy"
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                />
                              </div>
                              <p className="text-xs font-serif font-bold text-raja-ink line-clamp-1 group-hover:text-raja-maroon">
                                {prod.name}
                              </p>
                              <p className="text-[11px] font-bold text-raja-maroon mt-0.5">
                                ₹{prod.price.toLocaleString("en-IN")}
                                {prod.unit === "meter" && <span className="font-normal text-[10px] text-raja-ink-muted">/m</span>}
                              </p>
                            </Link>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Department Footer CTA */}
                    <div className="pt-6 mt-6 border-t border-raja-ink-border/60 flex flex-wrap items-center justify-between gap-4">
                      <div className="text-xs text-raja-ink-muted">
                        Direct Loom Weave · Guaranteed Authentic
                      </div>
                      <Link
                        href={`/products?department=${encodeURIComponent(dept.id)}`}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-raja-maroon text-white text-xs font-bold hover:bg-raja-maroon-light transition-all shadow-sm"
                      >
                        <span>Explore All {dept.title}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </div>
                  </div>
                </div>
              </section>
            );
          })}
        </div>

        {/* Master Loom Guarantees */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-xl border border-raja-ink-border shadow-sm flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-raja-maroon-subtle text-raja-maroon">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-raja-ink">
                100% Authentic Handloom
              </h4>
              <p className="text-xs text-raja-ink-soft mt-1">
                Woven on registered master looms in Elampillai, Salem. Zero counterfeit powerloom prints.
              </p>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-raja-ink-border shadow-sm flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-raja-maroon-subtle text-raja-maroon">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-raja-ink">
                Custom Running Cuts
              </h4>
              <p className="text-xs text-raja-ink-soft mt-1">
                Fabrics cut continuous to exact meter lengths for bespoke designer tailoring.
              </p>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-raja-ink-border shadow-sm flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-raja-maroon-subtle text-raja-maroon">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-raja-ink">
                Free Pan-India Shipping
              </h4>
              <p className="text-xs text-raja-ink-soft mt-1">
                Complimentary insured courier delivery across India on orders above ₹999.
              </p>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-raja-ink-border shadow-sm flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-raja-maroon-subtle text-raja-maroon">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-raja-ink">
                Direct Weaver Pricing
              </h4>
              <p className="text-xs text-raja-ink-soft mt-1">
                No middleman markup. Transparent prices direct from our family weaver community.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
