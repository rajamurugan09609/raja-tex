import React from "react";
import { MessageCircle } from "lucide-react";
import { STORE_SETTINGS } from "@/data/products";

export default function ReturnsPolicyPage() {
  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 bg-white p-8 sm:p-12 rounded-2xl border border-raja-ink-border shadow-sm">
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-raja-gold">
            Customer Guarantee
          </span>
          <h1 className="font-serif text-3xl font-bold text-raja-maroon mt-1">
            Returns, Exchanges & Damaged Item Policy
          </h1>
          <p className="text-xs text-raja-ink-muted mt-1">
            Last updated: October 2026 • Raja Textile, Elampillai
          </p>
        </div>

        <div className="space-y-6 text-xs text-raja-ink-soft leading-relaxed">
          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              1. 7-Day Exchange & Quality Guarantee
            </h2>
            <p>
              We want you to love your handloom saree. In the unlikely event that you receive a saree with a weaving defect, wrong colorway, or transit damage, you are entitled to a full replacement or exchange within <strong>7 days</strong> of delivery.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              2. Exchange Conditions
            </h2>
            <ul className="list-disc list-inside space-y-1.5 pl-2">
              <li>The saree must be unworn, unwashed, and with all original tags attached.</li>
              <li>The attached unstitched running blouse piece must remain intact and uncut.</li>
              <li>Please keep the original packaging box/bag for return collection.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="font-serif text-base font-bold text-raja-ink">
              3. How to Initiate an Exchange
            </h2>
            <p>
              Simply send a WhatsApp message to our weaver support desk at <strong>+91 93600 21627</strong> with your Order Number (e.g. RT-2026-XXXX) and a short video or photo of the issue. Our team will arrange reverse pickup or guide you with immediate dispatch.
            </p>
          </section>

          <div className="p-4 rounded-xl bg-raja-ivory border border-raja-ink-border flex items-center justify-between">
            <div>
              <p className="font-bold text-raja-ink">Have a question regarding your order?</p>
              <p className="text-raja-ink-muted text-[11px]">Chat with our weaver team directly</p>
            </div>
            <a
              href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20have%20a%20query%20about%20my%20order.`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded bg-[#25D366] text-white font-semibold text-xs inline-flex items-center gap-1.5"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Us</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
