"use client";

import React, { useState, useMemo, useEffect, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Search, X, Sparkles } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import QuickViewModal from "@/components/QuickViewModal";
import { INITIAL_PRODUCTS, CATEGORIES } from "@/data/products";
import { Product, TextileDepartment } from "@/types";

const DEPARTMENTS: { label: string; value: TextileDepartment | "all" }[] = [
  { label: "All Textiles", value: "all" },
  { label: "Sarees", value: "Sarees" },
  { label: "Fabrics & Yardage", value: "Fabrics" },
  { label: "Dress Materials", value: "Dress Materials" },
  { label: "Men's Garments", value: "Garments" },
  { label: "Home Textiles", value: "Home Textiles" },
];

function ProductsContent() {
  const searchParams = useSearchParams();
  const initialDept = (searchParams.get("department") as TextileDepartment) || "all";
  const initialCategory = searchParams.get("category") || "all";
  const initialQuery = searchParams.get("q") || "";

  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [selectedDepartment, setSelectedDepartment] = useState<TextileDepartment | "all">(initialDept);
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [searchQuery, setSearchQuery] = useState<string>(initialQuery);
  const [priceFilter, setPriceFilter] = useState("all");
  const [sortBy, setSortBy] = useState("featured");
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Fetch live products from DB / API
  useEffect(() => {
    fetch("/api/products")
      .then((res) => res.json())
      .then((data) => {
        if (data.products && Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
        }
      })
      .catch(() => {});
  }, []);

  // Sync state if URL search params change
  useEffect(() => {
    const dept = searchParams.get("department") as TextileDepartment | null;
    const cat = searchParams.get("category");
    const q = searchParams.get("q");
    if (dept) setSelectedDepartment(dept);
    if (cat) setSelectedCategory(cat);
    if (q) setSearchQuery(q);
  }, [searchParams]);

  // Categories belonging to selected department
  const availableCategories = useMemo(() => {
    if (selectedDepartment === "all") {
      return CATEGORIES;
    }
    return CATEGORIES.filter((c) => c.department === selectedDepartment);
  }, [selectedDepartment]);

  // Reset category if it doesn't belong to the newly selected department
  const handleDepartmentChange = (dept: TextileDepartment | "all") => {
    setSelectedDepartment(dept);
    if (dept !== "all" && selectedCategory !== "all") {
      const match = CATEGORIES.some(
        (c) => c.department === dept && c.name === selectedCategory
      );
      if (!match) setSelectedCategory("all");
    }
  };

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Department match
      if (selectedDepartment !== "all" && product.department !== selectedDepartment) {
        return false;
      }

      // Category match
      if (selectedCategory !== "all" && product.category !== selectedCategory) {
        return false;
      }

      // Search match
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matches =
          product.name.toLowerCase().includes(q) ||
          product.fabric.toLowerCase().includes(q) ||
          product.zariType.toLowerCase().includes(q) ||
          product.description.toLowerCase().includes(q) ||
          (product.department && product.department.toLowerCase().includes(q)) ||
          product.category.toLowerCase().includes(q);
        if (!matches) return false;
      }

      // Price filter
      if (priceFilter === "under-500" && product.price >= 500) return false;
      if (priceFilter === "500-1000" && (product.price < 500 || product.price > 1000)) return false;
      if (priceFilter === "1000-2500" && (product.price < 1000 || product.price > 2500)) return false;
      if (priceFilter === "above-2500" && product.price <= 2500) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === "price-asc") return a.price - b.price;
      if (sortBy === "price-desc") return b.price - a.price;
      if (sortBy === "rating") return b.rating - a.rating;
      if (sortBy === "name-asc") return a.name.localeCompare(b.name);
      // Default: featured first
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return 0;
    });
  }, [products, selectedDepartment, selectedCategory, searchQuery, priceFilter, sortBy]);

  const resetFilters = () => {
    setSelectedDepartment("all");
    setSelectedCategory("all");
    setSearchQuery("");
    setPriceFilter("all");
    setSortBy("featured");
  };

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb & Header */}
        <div className="mb-8">
          <nav className="text-xs text-raja-ink-muted mb-2 flex items-center gap-2">
            <Link href="/" className="hover:text-raja-maroon font-medium transition-colors">
              Home
            </Link>
            <span>/</span>
            <Link href="/collection" className="hover:text-raja-maroon font-medium transition-colors">
              Collections
            </Link>
            <span>/</span>
            <span className="text-raja-maroon font-bold">Catalog</span>
          </nav>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs uppercase font-bold tracking-[0.2em] text-raja-gold mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Salem Handloom &amp; Master Weaves</span>
              </div>
              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-raja-maroon leading-tight">
                {selectedDepartment === "all"
                  ? "Authentic Textile Catalog"
                  : selectedDepartment === "Sarees"
                  ? "Elampillai Saree Collections"
                  : selectedDepartment === "Fabrics"
                  ? "Silk Fabrics & Running Yardage"
                  : selectedDepartment === "Dress Materials"
                  ? "Festive Dress Materials & Suits"
                  : selectedDepartment === "Garments"
                  ? "Men's Traditional Silk Dhotis"
                  : "Handcrafted Home Textiles"}
              </h1>
              <p className="text-xs sm:text-sm text-raja-ink-soft mt-1 max-w-xl">
                Directly from the master artisan looms of Elampillai, Salem. Authentic weaves, genuine zari, and zero middlemen commission.
              </p>
            </div>
            <p className="text-xs text-raja-ink-muted font-medium bg-white px-3 py-1.5 rounded-full border border-raja-ink-border self-start md:self-auto shadow-sm">
              Showing <span className="font-bold text-raja-maroon">{filteredProducts.length}</span> authentic creations
            </p>
          </div>
        </div>

        {/* Department Tab Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 scrollbar-none">
          {DEPARTMENTS.map((dept) => {
            const count =
              dept.value === "all"
                ? products.length
                : products.filter((p) => p.department === dept.value).length;
            const isSelected = selectedDepartment === dept.value;

            return (
              <button
                key={dept.value}
                onClick={() => handleDepartmentChange(dept.value)}
                className={`whitespace-nowrap px-4 py-2 rounded-full text-xs font-bold transition-all shadow-sm flex items-center gap-2 shrink-0 ${
                  isSelected
                    ? "bg-raja-maroon text-white ring-2 ring-raja-maroon/20"
                    : "bg-white text-raja-ink hover:text-raja-maroon border border-raja-ink-border hover:border-raja-gold"
                }`}
              >
                <span>{dept.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? "bg-white/20 text-white" : "bg-raja-ivory text-raja-gold-dark font-semibold"
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-white p-5 rounded-2xl border border-raja-ink-border shadow-sm mb-10 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Search Input */}
            <div className="md:col-span-4 relative">
              <Search className="w-4 h-4 text-raja-gold absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by weave, fabric, zari butta..."
                className="w-full text-xs sm:text-sm pl-10 pr-8 py-2.5 rounded-xl border border-raja-ink-border bg-raja-ivory/30 focus:outline-none focus:border-raja-maroon"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-3 text-raja-ink-muted hover:text-raja-ink"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Category Select */}
            <div className="md:col-span-3">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl border border-raja-ink-border bg-white text-raja-ink focus:outline-none focus:border-raja-maroon"
              >
                <option value="all">
                  {selectedDepartment === "all" ? "All Categories" : `All ${selectedDepartment} Categories`}
                </option>
                {availableCategories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Filter */}
            <div className="md:col-span-3">
              <select
                value={priceFilter}
                onChange={(e) => setPriceFilter(e.target.value)}
                className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl border border-raja-ink-border bg-white text-raja-ink focus:outline-none focus:border-raja-maroon"
              >
                <option value="all">All Prices</option>
                <option value="under-500">Under ₹500</option>
                <option value="500-1000">₹500 – ₹1,000</option>
                <option value="1000-2500">₹1,000 – ₹2,500</option>
                <option value="above-2500">Above ₹2,500</option>
              </select>
            </div>

            {/* Sort Select */}
            <div className="md:col-span-2">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl border border-raja-ink-border bg-white text-raja-ink focus:outline-none focus:border-raja-maroon"
              >
                <option value="featured">Featured First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
                <option value="name-asc">Alphabetical</option>
              </select>
            </div>
          </div>

          {/* Active Filter Pills */}
          {(selectedDepartment !== "all" || selectedCategory !== "all" || priceFilter !== "all" || searchQuery) && (
            <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-raja-ink-border/50 text-xs">
              <span className="text-raja-ink-muted">Active filters:</span>

              {selectedDepartment !== "all" && (
                <span className="bg-raja-maroon-subtle text-raja-maroon px-3 py-1 rounded-full flex items-center gap-1.5 font-semibold">
                  Dept: {selectedDepartment}
                  <button onClick={() => setSelectedDepartment("all")}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}

              {selectedCategory !== "all" && (
                <span className="bg-raja-maroon-subtle text-raja-maroon px-3 py-1 rounded-full flex items-center gap-1.5 font-semibold">
                  {selectedCategory}
                  <button onClick={() => setSelectedCategory("all")}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}

              {priceFilter !== "all" && (
                <span className="bg-raja-maroon-subtle text-raja-maroon px-3 py-1 rounded-full flex items-center gap-1.5 font-semibold">
                  Price: {priceFilter}
                  <button onClick={() => setPriceFilter("all")}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}

              {searchQuery && (
                <span className="bg-raja-maroon-subtle text-raja-maroon px-3 py-1 rounded-full flex items-center gap-1.5 font-semibold">
                  &ldquo;{searchQuery}&rdquo;
                  <button onClick={() => setSearchQuery("")}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}

              <button
                onClick={resetFilters}
                className="text-xs text-raja-maroon hover:underline font-bold ml-auto"
              >
                Reset All Filters
              </button>
            </div>
          )}
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-2xl p-16 text-center border border-raja-ink-border space-y-4 shadow-sm">
            <h3 className="font-serif text-2xl font-bold text-raja-ink">
              No matching textiles found
            </h3>
            <p className="text-xs sm:text-sm text-raja-ink-soft max-w-sm mx-auto leading-relaxed">
              We couldn&apos;t find any items matching your selected department or filter criteria. Try clearing some filters or searching for another weave.
            </p>
            <button
              onClick={resetFilters}
              className="px-6 py-3 rounded-lg bg-raja-maroon text-white text-xs font-bold hover:bg-raja-maroon-light transition-colors shadow-md"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={(p) => setQuickViewProduct(p)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        isOpen={!!quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense
      fallback={
        <div className="bg-raja-ivory min-h-screen py-20 flex items-center justify-center">
          <div className="text-center space-y-3">
            <div className="w-8 h-8 border-2 border-raja-maroon border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs uppercase tracking-widest text-raja-gold font-bold">
              Loading Master Weaves...
            </p>
          </div>
        </div>
      }
    >
      <ProductsContent />
    </Suspense>
  );
}
