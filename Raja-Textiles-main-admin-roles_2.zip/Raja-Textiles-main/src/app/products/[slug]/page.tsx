"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { notFound, useRouter } from "next/navigation";
import {
  Heart,
  ShoppingBag,
  MessageCircle,
  Truck,
  ShieldCheck,
  RotateCcw,
  Maximize2,
  X,
  Share2,
} from "lucide-react";
import { INITIAL_PRODUCTS, STORE_SETTINGS } from "@/data/products";
import { Product } from "@/types";
import ProductCard from "@/components/ProductCard";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { useToast } from "@/context/ToastContext";

interface ProductDetailPageProps {
  params: { slug: string };
}

export default function ProductDetailPage({ params }: ProductDetailPageProps) {
  const router = useRouter();
  const [allProducts, setAllProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch live products
  useEffect(() => {
    fetch("/api/products")
      .then((res) => res.json())
      .then((data) => {
        if (data.products && Array.isArray(data.products) && data.products.length > 0) {
          setAllProducts(data.products);
        }
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  const product = allProducts.find(
    (p) => p.slug === params.slug || p.id === params.slug
  );

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [zoomModalOpen, setZoomModalOpen] = useState(false);
  const [pincode, setPincode] = useState("");
  const [pincodeResult, setPincodeResult] = useState<string | null>(null);

  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { showToast } = useToast();

  if (isLoading && !product) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3 bg-raja-ivory">
        <div className="w-8 h-8 border-2 border-raja-gold border-t-raja-maroon rounded-full animate-spin" />
        <span className="text-xs text-raja-ink-soft">Loading weave details...</span>
      </div>
    );
  }

  if (!product) {
    notFound();
  }

  const isFavorited = isInWishlist(product.id);
  const selectedColor = product.colors && product.colors.length > 0
    ? product.colors[selectedColorIndex]?.name || "Standard"
    : "Standard";

  const handleColorSelect = (index: number) => {
    setSelectedColorIndex(index);
    if (product.colors[index]?.imageIndex !== undefined) {
      setActiveImageIndex(product.colors[index].imageIndex || 0);
    } else if (index < product.images.length) {
      setActiveImageIndex(index);
    }
  };

  const handleAddToCart = () => {
    addToCart(product, selectedColor, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedColor, quantity);
    router.push("/checkout");
  };

  const handleWhatsAppOrder = () => {
    const unitText = product.unit === "meter" ? "/meter" : "";
    const qtyText = product.unit === "meter" ? "Length in meters" : "Quantity";
    const msg = encodeURIComponent(
      `*Vanakkam Raja Textile!*\n\nI want to order this ${product.department || "textile"} from your Elampillai loom:\n` +
        `*Name:* ${product.name}\n` +
        `*Price:* ₹${product.price}${unitText} (MRP: ₹${product.originalPrice})\n` +
        `*Color Selected:* ${selectedColor}\n` +
        `*${qtyText}:* ${quantity}\n` +
        `*Product Link:* https://raja-textiles.vercel.app/products/${product.slug}\n\n` +
        `Please confirm stock availability and send UPI payment details. Nandri!`
    );
    window.open(`https://wa.me/${STORE_SETTINGS.whatsapp}?text=${msg}`, "_blank");
  };

  const handleCheckPincode = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pincode.trim();
    if (!/^\d{6}$/.test(cleanPin)) {
      setPincodeResult("Please enter a valid 6-digit Indian PIN code.");
      return;
    }

    const firstTwo = cleanPin.substring(0, 2);
    if (["60", "61", "62", "63", "64"].includes(firstTwo)) {
      setPincodeResult(
        `✓ Fast Delivery available to ${cleanPin}! Dispatched directly from Salem: Expected in 2–3 business days. Cash on Delivery eligible.`
      );
    } else if (["56", "57", "58", "59", "50", "51", "52", "53"].includes(firstTwo)) {
      setPincodeResult(
        `✓ Delivery available to ${cleanPin}! Expected in 3–4 business days via Express Courier. Cash on Delivery eligible.`
      );
    } else {
      setPincodeResult(
        `✓ Pan-India Delivery available to ${cleanPin}! Expected in 4–6 business days. Safe & trackable.`
      );
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: `Look at this beautiful ${product.name} from Raja Textile, Elampillai!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast("Product link copied to clipboard!");
    }
  };

  const relatedProducts = allProducts.filter((p) => p.id !== product.id).slice(0, 3);

  return (
    <div className="bg-raja-ivory min-h-screen py-8 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="text-xs text-raja-ink-muted mb-6 flex items-center gap-2">
          <Link href="/" className="hover:text-raja-maroon">Home</Link>
          <span>/</span>
          <Link href="/products" className="hover:text-raja-maroon">Sarees</Link>
          <span>/</span>
          <span className="text-raja-maroon font-medium truncate max-w-xs">{product.name}</span>
        </nav>

        {/* Main Product Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Left Column: Image Gallery */}
          <div className="lg:col-span-6 space-y-4">
            {/* Primary Main Image */}
            <div className="relative aspect-[4/5] bg-white rounded-xl overflow-hidden border border-raja-ink-border shadow-sm group">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={`${product.name} - ${selectedColor}`}
                className="w-full h-full object-cover object-center transition-all duration-300"
              />

              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-1.5">
                <span className="bg-raja-maroon text-white text-xs font-bold px-2.5 py-1 rounded shadow-sm uppercase tracking-wider">
                  {product.discountPercent}% OFF
                </span>
                <span className="bg-raja-gold text-raja-wine text-[10px] font-bold px-2 py-0.5 rounded shadow-sm uppercase tracking-wider">
                  Elampillai Loom Direct
                </span>
              </div>

              {/* Action Overlay */}
              <div className="absolute top-4 right-4 flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => toggleWishlist(product)}
                  className={`p-2.5 rounded-full shadow-md transition-all ${
                    isFavorited
                      ? "bg-raja-maroon text-white"
                      : "bg-white/95 text-raja-ink hover:text-raja-maroon"
                  }`}
                  aria-label="Toggle wishlist"
                >
                  <Heart className={`w-4 h-4 ${isFavorited ? "fill-current" : ""}`} />
                </button>

                <button
                  type="button"
                  onClick={() => setZoomModalOpen(true)}
                  className="p-2.5 rounded-full bg-white/95 text-raja-ink hover:text-raja-maroon shadow-md transition-all"
                  aria-label="Zoom image"
                >
                  <Maximize2 className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={handleShare}
                  className="p-2.5 rounded-full bg-white/95 text-raja-ink hover:text-raja-maroon shadow-md transition-all"
                  aria-label="Share product"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Thumbnail Carousel */}
            {product.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-20 h-24 rounded-lg overflow-hidden border-2 flex-shrink-0 transition-all ${
                      activeImageIndex === idx
                        ? "border-raja-maroon ring-2 ring-raja-gold/50 shadow-sm"
                        : "border-raja-ink-border opacity-70 hover:opacity-100"
                    }`}
                  >
                    <img
                      src={img}
                      alt={`Thumbnail ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Product Information & Purchase Actions */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              {/* Category & Verified Badge */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold uppercase tracking-[0.2em] text-raja-gold">
                  {product.category}
                </span>
                <span className="text-xs text-raja-ink-muted flex items-center gap-1">
                  ★ <strong className="text-raja-ink">{product.rating}</strong> ({product.reviewCount} reviews)
                </span>
              </div>

              {/* Title */}
              <h1 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-raja-ink leading-tight">
                {product.name}
              </h1>

              {/* Tagline */}
              <p className="text-xs sm:text-sm text-raja-ink-soft mt-1">
                {product.fabric} with {product.zariType}
              </p>
            </div>

            {/* Price Block */}
            <div className="p-4 rounded-xl bg-white border border-raja-ink-border flex items-baseline justify-between">
              <div>
                <div className="flex items-baseline gap-3">
                  <span className="text-2xl sm:text-3xl font-bold text-raja-maroon">
                    ₹{product.price.toLocaleString("en-IN")}
                    {product.unit === "meter" && (
                      <span className="text-sm font-normal text-raja-ink-muted ml-1">/ meter</span>
                    )}
                  </span>
                  <span className="text-sm text-raja-ink-muted line-through">
                    MRP ₹{product.originalPrice.toLocaleString("en-IN")}
                  </span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    Save ₹{(product.originalPrice - product.price).toLocaleString("en-IN")} ({product.discountPercent}%)
                  </span>
                </div>
                <p className="text-[11px] text-raja-ink-muted mt-1">
                  Inclusive of all taxes • Direct loom pricing from Salem
                </p>
              </div>

              <span className="text-xs font-semibold text-emerald-800 bg-emerald-100/60 px-2.5 py-1 rounded-full">
                In Stock
              </span>
            </div>

            {/* Color Swatches */}
            {product.colors && product.colors.length > 0 && (
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-raja-ink">
                    Colorway: <span className="text-raja-maroon font-bold">{selectedColor}</span>
                  </span>
                  <span className="text-raja-ink-muted text-[11px]">
                    {product.colors.length} shades available
                  </span>
                </div>

                <div className="flex flex-wrap gap-2.5">
                  {product.colors.map((color, idx) => (
                    <button
                      key={color.name}
                      type="button"
                      onClick={() => handleColorSelect(idx)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs transition-all ${
                        selectedColorIndex === idx
                          ? "border-raja-maroon bg-raja-maroon-subtle text-raja-maroon font-semibold ring-1 ring-raja-maroon"
                          : "border-raja-ink-border bg-white text-raja-ink hover:border-raja-gold"
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/20 flex-shrink-0"
                        style={{ backgroundColor: color.hex }}
                      />
                      <span>{color.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="flex items-center gap-4">
              <span className="text-xs font-semibold text-raja-ink">
                {product.unit === "meter" ? "Length (meters):" : "Quantity:"}
              </span>
              <div className="flex items-center border border-raja-ink-border rounded bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1.5 text-raja-ink hover:bg-raja-ivory text-sm font-semibold rounded-l"
                >
                  -
                </button>
                <span className="px-4 py-1.5 text-xs font-bold text-raja-ink min-w-[2.5rem] text-center">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(product.stockCount, quantity + 1))}
                  className="px-3 py-1.5 text-raja-ink hover:bg-raja-ivory text-sm font-semibold rounded-r"
                >
                  +
                </button>
              </div>
              <span className="text-[11px] text-raja-ink-muted">
                (Max {product.stockCount} available for immediate dispatch)
              </span>
            </div>

            {/* Primary Action Buttons */}
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded bg-raja-wine hover:bg-raja-maroon text-white font-semibold text-sm shadow-md transition-colors"
                >
                  <ShoppingBag className="w-4 h-4 text-raja-gold" />
                  <span>Add to Bag</span>
                </button>

                <button
                  type="button"
                  onClick={handleBuyNow}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded bg-raja-maroon hover:bg-raja-maroon-light text-white font-semibold text-sm shadow-md transition-colors"
                >
                  <span>Buy Now (₹{(product.price * quantity).toLocaleString("en-IN")})</span>
                </button>
              </div>

              {/* Direct WhatsApp Ordering */}
              <button
                type="button"
                onClick={handleWhatsAppOrder}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded bg-[#25D366] hover:bg-[#20ba59] text-white font-semibold text-xs shadow-sm transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Instant Order & Video Inspection on WhatsApp (+91 93600 21627)</span>
              </button>
            </div>

            {/* Pincode Delivery Checker */}
            <div className="p-4 rounded-xl bg-white border border-raja-ink-border space-y-2">
              <span className="text-xs font-semibold text-raja-ink flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-raja-gold" />
                Delivery & Pincode Check
              </span>
              <form onSubmit={handleCheckPincode} className="flex gap-2">
                <input
                  type="text"
                  maxLength={6}
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value.replace(/[^0-9]/g, ""))}
                  placeholder="Enter 6-digit PIN code (e.g. 637502 or 600001)"
                  className="flex-1 text-xs px-3 py-2 rounded border border-raja-ink-border bg-raja-ivory/30 focus:outline-none focus:border-raja-maroon"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-raja-ink text-white text-xs font-semibold rounded hover:bg-raja-maroon transition-colors"
                >
                  Check
                </button>
              </form>
              {pincodeResult && (
                <p
                  className={`text-xs mt-1.5 ${
                    pincodeResult.startsWith("✓") ? "text-emerald-800" : "text-red-700"
                  }`}
                >
                  {pincodeResult}
                </p>
              )}
            </div>

            {/* Value Guarantees */}
            <div className="grid grid-cols-2 gap-3 text-xs text-raja-ink-soft">
              <div className="flex items-center gap-2 p-3 rounded-lg bg-white border border-raja-ink-border/80">
                <ShieldCheck className="w-4 h-4 text-raja-gold flex-shrink-0" />
                <span>100% Master Loom Woven</span>
              </div>
              <div className="flex items-center gap-2 p-3 rounded-lg bg-white border border-raja-ink-border/80">
                <RotateCcw className="w-4 h-4 text-raja-gold flex-shrink-0" />
                <span>Easy Exchange Support</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Specifications & Craftsmanship Details */}
        <div className="mt-16 bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-10 shadow-sm space-y-8">
          <div>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-raja-maroon mb-2">
              Saree Description & Heritage
            </h2>
            <p className="text-sm text-raja-ink-soft leading-relaxed max-w-4xl">
              {product.description}
            </p>
          </div>

          {/* Specifications Table */}
          <div>
            <h3 className="font-serif text-lg font-bold text-raja-ink mb-4">
              Weave & Dimension Specifications
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 text-xs">
              <div className="flex justify-between py-2.5 border-b border-raja-ink-border">
                <span className="text-raja-ink-muted">Fabric / Material</span>
                <span className="font-semibold text-raja-ink">{product.fabric}</span>
              </div>

              <div className="flex justify-between py-2.5 border-b border-raja-ink-border">
                <span className="text-raja-ink-muted">Total Length</span>
                <span className="font-semibold text-raja-ink">{product.sareeLength}</span>
              </div>

              <div className="flex justify-between py-2.5 border-b border-raja-ink-border">
                <span className="text-raja-ink-muted">Zari Type</span>
                <span className="font-semibold text-raja-ink">{product.zariType}</span>
              </div>

              <div className="flex justify-between py-2.5 border-b border-raja-ink-border">
                <span className="text-raja-ink-muted">Pallu Style</span>
                <span className="font-semibold text-raja-ink">{product.pallu}</span>
              </div>

              <div className="flex justify-between py-2.5 border-b border-raja-ink-border">
                <span className="text-raja-ink-muted">Weight</span>
                <span className="font-semibold text-raja-ink">{product.weight}</span>
              </div>

              <div className="flex justify-between py-2.5 border-b border-raja-ink-border">
                <span className="text-raja-ink-muted">Origin</span>
                <span className="font-semibold text-raja-ink">Elampillai, Salem, Tamil Nadu</span>
              </div>
            </div>
          </div>

          {/* Care Instructions */}
          <div>
            <h3 className="font-serif text-lg font-bold text-raja-ink mb-3">
              Care & Zari Preservation
            </h3>
            <ul className="space-y-1.5 text-xs text-raja-ink-soft list-disc list-inside">
              {product.care.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Related Products */}
        <div className="mt-16 space-y-6">
          <div className="flex items-baseline justify-between">
            <h2 className="font-serif text-2xl font-bold text-raja-maroon">
              You May Also Like
            </h2>
            <Link href="/products" className="text-xs text-raja-maroon hover:underline font-semibold">
              View All Sarees →
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>

      {/* Image Zoom Modal */}
      {zoomModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
        >
          <button
            onClick={() => setZoomModalOpen(false)}
            className="absolute top-5 right-5 p-3 text-white/80 hover:text-white rounded-full bg-white/10"
            aria-label="Close zoom modal"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={product.images[activeImageIndex] || product.images[0]}
            alt={product.name}
            className="max-w-full max-h-[90vh] object-contain rounded-lg"
          />
        </div>
      )}
    </div>
  );
}
