"use client";

import React, { useState } from "react";
import { Search, AlertCircle, MessageCircle } from "lucide-react";
import { Order } from "@/types";
import { STORE_SETTINGS } from "@/data/products";

export default function TrackOrderPage() {
  const [orderQuery, setOrderQuery] = useState("");
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderQuery.trim()) return;

    setLoading(true);
    setErrorMsg(null);
    setOrder(null);

    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(orderQuery.trim())}`);
      const data = await res.json();
      if (data.success && data.order) {
        setOrder(data.order);
      } else {
        setErrorMsg("Order not found. Please verify your Order Reference Number (e.g. RT-2026-XXXX).");
      }
    } catch {
      setErrorMsg("Failed to connect to tracking servers. Please try again or WhatsApp us.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-raja-ivory min-h-screen py-12 md:py-16">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-raja-gold">
            Real-Time Courier Tracking
          </span>
          <h1 className="font-serif text-3xl font-bold text-raja-maroon">
            Track Your Saree Shipment
          </h1>
          <p className="text-xs text-raja-ink-soft">
            Enter your Raja Textile Order Number to view live packaging, dispatch, and courier status.
          </p>
        </div>

        {/* Search Form */}
        <div className="bg-white p-6 rounded-2xl border border-raja-ink-border shadow-sm">
          <form onSubmit={handleTrack} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-raja-gold absolute left-3 top-3.5" />
              <input
                type="text"
                required
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                placeholder="Enter Order No. (e.g. RT-2026-92841)"
                className="w-full text-xs sm:text-sm pl-9 pr-3 py-2.5 rounded-lg border border-raja-ink-border focus:border-raja-maroon focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-raja-maroon hover:bg-raja-maroon-light disabled:opacity-60 text-white text-xs font-semibold rounded-lg transition-colors"
            >
              {loading ? "Searching..." : "Track Order"}
            </button>
          </form>

          {errorMsg && (
            <div className="mt-4 p-3 rounded-lg bg-red-50 text-red-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Order Result Card */}
        {order && (
          <div className="bg-white rounded-2xl border border-raja-ink-border p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-raja-ink-border pb-4">
              <div>
                <span className="font-bold text-sm text-raja-maroon tracking-wider">
                  {order.orderNumber}
                </span>
                <p className="text-xs text-raja-ink-muted mt-0.5">
                  Ordered on {new Date(order.createdAt).toLocaleDateString("en-IN", { dateStyle: "medium" })}
                </p>
              </div>

              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-raja-maroon-subtle text-raja-maroon">
                {order.orderStatus}
              </span>
            </div>

            {/* Tracking details */}
            <div className="space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-raja-ink-muted">Customer Name:</span>
                <span className="font-semibold text-raja-ink">{order.customer.fullName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-raja-ink-muted">Delivery Destination:</span>
                <span className="font-semibold text-raja-ink">
                  {order.customer.city}, {order.customer.state} ({order.customer.pincode})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-raja-ink-muted">Items:</span>
                <span className="font-semibold text-raja-ink">
                  {order.items.map((i) => `${i.name} (Qty: ${i.quantity})`).join(", ")}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-raja-ink-muted">Total Amount:</span>
                <span className="font-bold text-raja-maroon">
                  ₹{order.pricing.total.toLocaleString("en-IN")}
                </span>
              </div>
              {order.trackingNumber && (
                <div className="flex justify-between p-2 rounded bg-emerald-50 text-emerald-800 font-semibold">
                  <span>Courier AWB Tracking Number:</span>
                  <span>{order.trackingNumber}</span>
                </div>
              )}
            </div>

            <div className="pt-2">
              <a
                href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20am%20tracking%20my%20order%20${order.orderNumber}.`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-lg bg-[#25D366] text-white text-xs font-semibold flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Get Instant Update from Loom on WhatsApp</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
