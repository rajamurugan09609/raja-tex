import type { Metadata, Viewport } from "next";
import "./globals.css";
import AnnouncementBar from "@/components/AnnouncementBar";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import SearchModal from "@/components/SearchModal";
import AmbientSilkParticles from "@/components/AmbientSilkParticles";
import RajaAIAdvisor from "@/components/RajaAIAdvisor";
import { ToastProvider } from "@/context/ToastContext";
import { AuthProvider } from "@/context/AuthContext";
import { CartProvider } from "@/context/CartContext";
import { WishlistProvider } from "@/context/WishlistContext";

export const metadata: Metadata = {
  title: "Raja Textile | Master Weavers of Elampillai, Salem",
  description:
    "Explore authentic South Indian handloom sarees, 3D embossed silks, vintage kolam drapes, and festive bridal weaves direct from the master weavers of Elampillai, Salem, Tamil Nadu.",
  keywords: [
    "Raja Textile",
    "Elampillai Sarees",
    "Salem Sarees",
    "Soft Silk Sarees",
    "Karizma Silk",
    "Kolam Silk Sarees",
    "Bridal Silk Sarees",
    "Direct Weaver Saree",
    "Tamil Nadu Handloom",
  ],
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://raja-textiles.vercel.app"),
  authors: [{ name: "Raja Textile", url: "https://raja-textiles.vercel.app" }],
  openGraph: {
    title: "Raja Textile | Traditional Weaves × Modern Luxury",
    description:
      "Handcrafted South Indian sarees direct from the loom in Elampillai, Salem. Experience exquisite golden zari, soft silk, and wedding drapes.",
    siteName: "Raja Textile",
    locale: "en_IN",
    type: "website",
  },
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/icon.png", type: "image/png" },
    ],
    shortcut: "/favicon.ico",
    apple: "/icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#681329",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen flex flex-col bg-raja-ivory text-raja-ink selection:bg-raja-maroon selection:text-white">
        <ToastProvider>
          <AuthProvider>
            <WishlistProvider>
              <CartProvider>
                <AmbientSilkParticles />
                <AnnouncementBar />
                <Header />
                <main className="flex-1">{children}</main>
                <Footer />
                <CartDrawer />
                <SearchModal />
                <RajaAIAdvisor />
              </CartProvider>
            </WishlistProvider>
          </AuthProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
