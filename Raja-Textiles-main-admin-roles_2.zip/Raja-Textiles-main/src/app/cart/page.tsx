"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  ShieldCheck,
  Truck,
  Tag,
} from "lucide-react";
import { useCart } from "@/context/CartContext";
import { STORE_SETTINGS } from "@/data/products";

export default function CartPage() {
  const {
    items,
    removeFromCart,
    updateQuantity,
    totalCount,
    subtotal,
    discount,
    shipping,
    total,
    couponCode,
    applyCoupon,
    removeCoupon,
  } = useCart();

  const [inputCoupon, setInputCoupon] = useState("");

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCoupon.trim()) return;
    if (applyCoupon(inputCoupon)) {
      setInputCoupon("");
    }
  };

  const amountNeededForFreeShipping = Math.max(0, STORE_SETTINGS.freeShippingThreshold - subtotal);

  if (items.length === 0) {
    return (
      <div className="bg-raja-ivory min-h-[70vh] py-16 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl border border-raja-ink-border p-8 sm:p-12 max-w-md text-center space-y-5 shadow-sm">
          <div className="w-16 h-16 rounded-full bg-raja-maroon-subtle flex items-center justify-center mx-auto text-raja-maroon">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="font-serif text-2xl font-bold text-raja-ink">
            Your shopping bag is empty
          </h2>
          <p className="text-xs sm:text-sm text-raja-ink-soft leading-relaxed">
            Discover authentic handloom sarees, pure raw silk yardage, unstitched suit sets, and men&apos;s traditional dhotis direct from our master looms in Elampillai.
          </p>
          <Link
            href="/collection"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-raja-maroon text-white text-xs font-bold hover:bg-raja-maroon-light transition-all shadow-md"
          >
            <span>Explore Collections</span>
            <ArrowRight className="w-4 h-4 text-raja-gold" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-raja-ivory min-h-screen py-10 md:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="text-xs text-raja-ink-muted mb-4 flex items-center gap-2">
          <Link href="/" className="hover:text-raja-maroon font-medium transition-colors">
            Home
          </Link>
          <span>/</span>
          <span className="text-raja-maroon font-bold">Shopping Bag</span>
        </nav>

        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-raja-maroon mb-2">
          Your Shopping Bag
        </h1>
        <p className="text-xs sm:text-sm text-raja-ink-soft mb-8">
          Review your selected weaves before proceeding to secure checkout.
        </p>

        {/* Free Shipping Alert */}
        <div className="bg-white p-4 rounded-xl border border-raja-ink-border shadow-sm mb-8 flex items-center gap-3">
          <div className="p-2 rounded-full bg-raja-gold/15 text-raja-gold-dark flex-shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div className="text-xs">
            {amountNeededForFreeShipping === 0 ? (
              <span className="font-bold text-emerald-800">
                🎉 Congratulations! Your order qualifies for Free Pan-India Insured Shipping.
              </span>
            ) : (
              <span>
                Add weaves worth <strong className="text-raja-maroon">₹{amountNeededForFreeShipping}</strong> more to get <strong>Free Insured Delivery</strong>.
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Items List (8 cols) */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-raja-ink-border p-6 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-raja-ink-border pb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-raja-ink">
                Selected Weaves ({totalCount})
              </span>
              <span className="text-xs text-raja-ink-muted">Direct Loom Pricing</span>
            </div>

            <div className="divide-y divide-raja-ink-border/60">
              {items.map((item) => (
                <div key={item.id} className="py-6 first:pt-0 last:pb-0 flex flex-col sm:flex-row gap-5 items-start sm:items-center justify-between">
                  <div className="flex items-center gap-4">
                    <img
                      src={item.product.images[0] || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"}
                      alt={item.product.name}
                      className="w-20 h-24 object-cover rounded-lg bg-raja-ivory flex-shrink-0 border border-raja-ink-border"
                    />
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-raja-gold-dark">
                        {item.product.department || item.product.category}
                      </span>
                      <h3 className="font-serif text-base font-semibold text-raja-ink hover:text-raja-maroon transition-colors line-clamp-1">
                        <Link href={`/products/${item.product.slug}`}>{item.product.name}</Link>
                      </h3>
                      <p className="text-xs text-raja-ink-soft mt-0.5">
                        Colorway: <span className="font-semibold text-raja-ink">{item.selectedColor}</span>
                      </p>
                      <p className="text-xs font-bold text-raja-maroon mt-1">
                        ₹{item.product.price.toLocaleString("en-IN")}
                        {item.product.unit === "meter" && <span className="font-normal text-raja-ink-muted ml-0.5">/m</span>}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 self-end sm:self-center">
                    {/* Quantity Selector */}
                    <div className="flex items-center border border-raja-ink-border rounded-lg bg-raja-ivory/40">
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-2 hover:bg-white text-raja-ink transition-colors rounded-l-lg"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 text-xs font-bold text-raja-ink min-w-[2rem] text-center">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-2 hover:bg-white text-raja-ink transition-colors rounded-r-lg"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Subtotal */}
                    <div className="text-right min-w-[5rem]">
                      <span className="font-bold text-sm text-raja-maroon">
                        ₹{(item.product.price * item.quantity).toLocaleString("en-IN")}
                      </span>
                    </div>

                    {/* Delete */}
                    <button
                      type="button"
                      onClick={() => removeFromCart(item.id)}
                      className="text-raja-ink-muted hover:text-red-700 p-2 transition-colors"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order Summary (4 cols) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-2xl border border-raja-ink-border p-6 shadow-sm space-y-5">
              <h3 className="font-serif text-lg font-bold text-raja-ink border-b border-raja-ink-border pb-3">
                Order Summary
              </h3>

              {/* Coupon Input */}
              <div>
                <span className="text-xs font-semibold text-raja-ink block mb-1.5">
                  Have a promotional coupon?
                </span>
                {couponCode ? (
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs">
                    <span className="font-bold text-emerald-800 flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-emerald-600" />
                      {couponCode} Applied
                    </span>
                    <button
                      type="button"
                      onClick={removeCoupon}
                      className="text-red-700 hover:underline font-semibold"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      value={inputCoupon}
                      onChange={(e) => setInputCoupon(e.target.value)}
                      placeholder="Try FESTIVE10 or WEAVER100"
                      className="w-full text-xs px-3 py-2.5 rounded-lg border border-raja-ink-border bg-raja-ivory/30 focus:outline-none focus:border-raja-maroon uppercase"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2.5 bg-raja-maroon text-white text-xs font-bold rounded-lg hover:bg-raja-maroon-light transition-colors flex-shrink-0"
                    >
                      Apply
                    </button>
                  </form>
                )}
              </div>

              {/* Calculation Rows */}
              <div className="space-y-2.5 text-xs pt-3 border-t border-raja-ink-border/60">
                <div className="flex justify-between text-raja-ink-soft">
                  <span>Bag Subtotal</span>
                  <span className="font-semibold text-raja-ink">₹{subtotal.toLocaleString("en-IN")}</span>
                </div>

                {discount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Discount Savings</span>
                    <span>-₹{discount.toLocaleString("en-IN")}</span>
                  </div>
                )}

                <div className="flex justify-between text-raja-ink-soft">
                  <span>Insured Shipping</span>
                  <span>{shipping === 0 ? <strong className="text-emerald-700">FREE</strong> : `₹${shipping}`}</span>
                </div>

                <div className="flex justify-between text-base font-bold text-raja-maroon pt-3 border-t border-raja-ink-border">
                  <span>Total Payable</span>
                  <span>₹{total.toLocaleString("en-IN")}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <Link
                href="/checkout"
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-lg bg-raja-maroon hover:bg-raja-maroon-light text-white font-bold text-xs shadow-md transition-all"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4 text-raja-gold" />
              </Link>
            </div>

            {/* Trust Badges */}
            <div className="bg-white/60 p-4 rounded-xl border border-raja-ink-border text-xs space-y-2 text-raja-ink-muted">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>100% Genuine Handloom Guarantee</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-raja-gold-dark" />
                <span>Direct dispatch from Elampillai, Salem</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
