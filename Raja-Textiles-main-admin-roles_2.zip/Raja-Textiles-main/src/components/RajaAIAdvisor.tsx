"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  X,
  Send,
  MessageCircle,
  Bot,
  User,
  ArrowRight,
} from "lucide-react";
import { Product } from "@/types";
import { STORE_SETTINGS } from "@/data/products";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  suggestedProducts?: Product[];
}

const PROMPT_SUGGESTIONS = [
  "🌟 Best festive saree for a temple wedding under ₹750?",
  "👑 Men's pure silk double dhotis & wedding veshtis",
  "✂️ Running silk fabric yardage for designer blouse",
  "👗 Unstitched 3-piece salwar suit dress materials",
];

export default function RajaAIAdvisor() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-1",
      role: "assistant",
      content:
        "Vanakkam! 🙏 I am **Raja AI**, your master loom textile & saree advisor from Elampillai, Salem.\n\nWhether you need drape advice for an upcoming wedding, fabric yardage for a designer blouse, or details on our 3D Karizma weaves, I'm here to assist you direct from our artisan looms.",
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isOpen]);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: query,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/ai/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      const data = await res.json();

      const assistantMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: "assistant",
        content:
          data.reply ||
          "Vanakkam! I am currently unable to reach the loom network. Please message our master weavers directly on WhatsApp for live video saree selection.",
        suggestedProducts: data.suggestedProducts || [],
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          role: "assistant",
          content:
            "Vanakkam! Connection interrupted. Please chat directly with our weavers on WhatsApp at +91 93600 21627 for instant assistance.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Launcher Button */}
      <div className="fixed bottom-4 right-3.5 sm:bottom-6 sm:right-6 z-40 touch-manipulation">
        <motion.button
          type="button"
          onClick={() => setIsOpen((prev) => !prev)}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 p-2.5 sm:px-4 sm:py-3 rounded-full bg-raja-wine hover:bg-raja-maroon text-white shadow-luxury border border-raja-gold transition-all duration-300 group max-w-[calc(100vw-1.5rem)]"
          aria-label="Open Raja AI Saree Advisor"
        >
          <div className="relative flex-shrink-0">
            <Sparkles className="w-5 h-5 text-raja-gold group-hover:rotate-12 transition-transform" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping pointer-events-none" />
          </div>
          <div className="text-left hidden sm:block">
            <p className="text-xs font-bold leading-tight flex items-center gap-1">
              <span>Raja AI</span>
              <span className="text-[9px] bg-raja-gold/20 text-raja-gold px-1.5 py-0.2 rounded font-semibold">
                GROQ
              </span>
            </p>
            <p className="text-[10px] text-raja-ivory/80 leading-tight">Saree &amp; Loom Advisor</p>
          </div>
        </motion.button>
      </div>

      {/* Interactive Chat Window Modal */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="fixed bottom-16 sm:bottom-20 inset-x-3 sm:inset-x-auto sm:right-6 w-auto sm:w-[400px] max-h-[75vh] sm:max-h-[80vh] h-[520px] sm:h-[580px] bg-white rounded-2xl shadow-2xl border-2 border-raja-gold/40 flex flex-col z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 bg-raja-wine text-white border-b border-raja-gold/30 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-raja-maroon border border-raja-gold flex items-center justify-center text-raja-gold shadow-sm flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-raja-gold" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif font-bold text-sm text-white">Raja AI Advisor</h3>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded-full font-semibold">
                      Online · Salem Looms
                    </span>
                  </div>
                  <p className="text-[10px] text-raja-ivory/70">
                    Master Loom Styling &amp; Textile Consultant
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-raja-ivory/80 hover:text-white rounded-full hover:bg-white/10 transition-colors"
                aria-label="Close Advisor"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Conversation Messages Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-raja-ivory/30">
              {messages.map((m) => {
                const isUser = m.role === "user";
                return (
                  <div
                    key={m.id}
                    className={`flex gap-2.5 ${isUser ? "justify-end" : "justify-start"}`}
                  >
                    {!isUser && (
                      <div className="w-7 h-7 rounded-full bg-raja-wine text-raja-gold flex items-center justify-center flex-shrink-0 mt-0.5 text-xs shadow-sm border border-raja-gold/40">
                        <Bot className="w-3.5 h-3.5" />
                      </div>
                    )}

                    <div className="space-y-2 max-w-[82%]">
                      <div
                        className={`p-3.5 rounded-2xl text-xs leading-relaxed shadow-sm ${
                          isUser
                            ? "bg-raja-maroon text-white rounded-tr-none"
                            : "bg-white text-raja-ink border border-raja-ink-border rounded-tl-none"
                        }`}
                      >
                        <div className="whitespace-pre-wrap">{m.content}</div>
                      </div>

                      {/* Suggested Products Inline Cards */}
                      {m.suggestedProducts && m.suggestedProducts.length > 0 && (
                        <div className="space-y-2 pt-1">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-raja-gold-dark">
                            Loom Recommendation:
                          </p>
                          <div className="grid grid-cols-1 gap-2">
                            {m.suggestedProducts.map((prod) => (
                              <Link
                                key={prod.id}
                                href={`/products/${prod.slug}`}
                                onClick={() => setIsOpen(false)}
                                className="group flex items-center gap-3 p-2 rounded-xl bg-white border border-raja-gold/50 shadow-sm hover:border-raja-maroon transition-all"
                              >
                                <img
                                  src={prod.images[0]}
                                  alt={prod.name}
                                  className="w-12 h-14 object-cover rounded-lg bg-raja-ivory flex-shrink-0"
                                />
                                <div className="flex-1 min-w-0">
                                  <p className="font-serif font-bold text-xs text-raja-ink truncate group-hover:text-raja-maroon">
                                    {prod.name}
                                  </p>
                                  <p className="text-[10px] text-raja-ink-muted truncate">
                                    {prod.fabric}
                                  </p>
                                  <p className="text-xs font-bold text-raja-maroon mt-0.5">
                                    ₹{prod.price.toLocaleString("en-IN")}
                                    {prod.unit === "meter" && <span className="font-normal text-[10px]">/m</span>}
                                  </p>
                                </div>
                                <ArrowRight className="w-3.5 h-3.5 text-raja-gold group-hover:translate-x-1 transition-transform mr-1" />
                              </Link>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {isUser && (
                      <div className="w-7 h-7 rounded-full bg-raja-gold text-raja-wine flex items-center justify-center flex-shrink-0 mt-0.5 text-xs shadow-sm font-bold">
                        <User className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Typing Indicator */}
              {isLoading && (
                <div className="flex gap-2.5 items-center text-xs text-raja-ink-muted">
                  <div className="w-7 h-7 rounded-full bg-raja-wine text-raja-gold flex items-center justify-center flex-shrink-0 text-xs">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                  <div className="bg-white p-3 rounded-2xl rounded-tl-none border border-raja-ink-border flex items-center gap-1.5 shadow-sm">
                    <span className="w-1.5 h-1.5 rounded-full bg-raja-gold animate-bounce" />
                    <span className="w-1.5 h-1.5 rounded-full bg-raja-gold animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-raja-gold animate-bounce [animation-delay:0.4s]" />
                    <span className="text-[11px] text-raja-ink-soft ml-1">Consulting Elampillai looms...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Prompt Suggestion Chips (when only initial message exists) */}
            {messages.length === 1 && (
              <div className="p-3 bg-white border-t border-raja-ink-border/60">
                <p className="text-[10px] font-bold uppercase tracking-wider text-raja-ink-muted mb-2">
                  Common Weave Questions:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {PROMPT_SUGGESTIONS.map((s, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSend(s)}
                      className="text-[11px] text-left px-2.5 py-1.5 rounded-lg bg-raja-ivory text-raja-ink hover:text-raja-maroon hover:border-raja-gold border border-raja-ink-border/60 transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Bar */}
            <div className="p-3 bg-white border-t border-raja-ink-border">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend();
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about sarees, weaves, zari, occasions..."
                  className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-raja-ink-border bg-raja-ivory/30 focus:outline-none focus:border-raja-maroon text-raja-ink placeholder:text-raja-ink-muted"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="p-2.5 rounded-xl bg-raja-maroon text-white hover:bg-raja-maroon-light transition-colors disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
                  aria-label="Send query"
                >
                  <Send className="w-4 h-4 text-raja-gold" />
                </button>
              </form>

              {/* Bottom WhatsApp Fallback */}
              <div className="mt-2 flex items-center justify-between text-[10px] text-raja-ink-muted">
                <span>Direct Elampillai master loom AI</span>
                <a
                  href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20would%20like%20to%20consult%20with%20a%20master%20weaver.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-700 hover:underline font-semibold flex items-center gap-1"
                >
                  <MessageCircle className="w-3 h-3 text-[#25D366]" />
                  <span>Weaver WhatsApp</span>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
