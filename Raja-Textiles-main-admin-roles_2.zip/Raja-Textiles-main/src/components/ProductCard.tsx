"use client";

import React, { useState } from "react";
import Link from "next/link";
import { Heart, ShoppingBag, MessageCircle, Eye } from "lucide-react";
import { Product } from "@/types";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { STORE_SETTINGS } from "@/data/products";

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export default function ProductCard({ product, onQuickView }: ProductCardProps) {
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  const isFavorited = isInWishlist(product.id);
  const images = product.images && product.images.length > 0
    ? product.images
    : ["/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"];
  
  // Primary image based on selected color
  const primaryImage = images[selectedColorIndex] || images[0];
  // Secondary image for hover crossfade (next image in array or index 1)
  const secondaryImage = images[1] || images[0];
  const selectedColorName = product.colors?.[selectedColorIndex]?.name || "Standard";

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, selectedColorName, 1);
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product);
  };

  const handleWhatsAppInquiry = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const unitLabel = product.unit === "meter" ? "/meter" : "";
    const msg = encodeURIComponent(
      `Vanakkam Raja Textile, I am interested in your ${product.department || "textile"}:\n*${product.name}*\nPrice: ₹${product.price}${unitLabel}\nSelected Color: ${selectedColorName}\nLink: https://raja-textiles.vercel.app/products/${product.slug}`
    );
    window.open(`https://wa.me/${STORE_SETTINGS.whatsapp}?text=${msg}`, "_blank");
  };

  const handleOpenQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onQuickView) {
      onQuickView(product);
    }
  };

  return (
    <article
      className="group relative bg-white border border-raja-ink-border rounded-xl overflow-hidden flex flex-col transition-all duration-300 hover:shadow-luxury hover:border-raja-gold/60"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Product Image Area with Dual-Image Crossfade */}
      <div className="relative aspect-[4/5] bg-raja-ivory overflow-hidden">
        <Link href={`/products/${product.slug}`} className="block w-full h-full relative">
          {/* Primary image */}
          <img
            src={primaryImage}
            alt={product.name}
            loading="lazy"
            className={`w-full h-full object-cover object-center transition-all duration-700 ease-out ${
              isHovered && images.length > 1
                ? "opacity-0 scale-105"
                : "opacity-100 scale-100 group-hover:scale-105"
            }`}
          />

          {/* Secondary image (Pallu / angle view) shown on hover */}
          {images.length > 1 && (
            <img
              src={secondaryImage}
              alt={`${product.name} pallu weave`}
              loading="lazy"
              className={`absolute inset-0 w-full h-full object-cover object-center transition-all duration-700 ease-out ${
                isHovered ? "opacity-100 scale-105" : "opacity-0 scale-100 pointer-events-none"
              }`}
            />
          )}
        </Link>

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 pointer-events-none z-10">
          <span className="bg-raja-maroon text-white text-[10px] font-bold px-2 py-0.5 rounded tracking-wider uppercase shadow-sm">
            {product.discountPercent}% OFF
          </span>
          {product.isBestSeller && (
            <span className="bg-raja-gold text-raja-wine text-[9px] font-bold px-2 py-0.5 rounded tracking-wider uppercase shadow-sm">
              Loom Favorite
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          type="button"
          onClick={handleWishlistToggle}
          className={`absolute top-3 right-3 p-2 rounded-full transition-all duration-200 shadow-md z-10 ${
            isFavorited
              ? "bg-raja-maroon text-white"
              : "bg-white/90 text-raja-ink hover:text-raja-maroon hover:bg-white"
          }`}
          aria-label={isFavorited ? "Remove from wishlist" : "Add to wishlist"}
        >
          <Heart className={`w-4 h-4 ${isFavorited ? "fill-current" : ""}`} />
        </button>

        {/* Quick View Pill - Appears in Center on Hover */}
        {onQuickView && (
          <button
            type="button"
            onClick={handleOpenQuickView}
            className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 px-3.5 py-2 rounded-full bg-white/95 backdrop-blur-sm text-raja-ink hover:text-raja-maroon font-semibold text-xs shadow-luxury border border-raja-gold/40 flex items-center gap-1.5 transition-all duration-300 ${
              isHovered ? "opacity-100 scale-100" : "opacity-0 scale-90 pointer-events-none"
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-raja-gold" />
            <span>Quick View</span>
          </button>
        )}

        {/* Quick Action Overlay (Bottom) */}
        <div
          className={`absolute bottom-3 inset-x-3 flex gap-2 z-10 transition-all duration-300 ${
            isHovered
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-3 pointer-events-none"
          }`}
        >
          <button
            type="button"
            onClick={handleQuickAdd}
            className="flex-1 bg-raja-wine/95 hover:bg-raja-maroon text-white text-xs font-semibold py-2.5 px-3 rounded-lg shadow-luxury flex items-center justify-center gap-1.5 transition-all"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-raja-gold" />
            <span>Add to Bag</span>
          </button>

          <button
            type="button"
            onClick={handleWhatsAppInquiry}
            className="bg-[#25D366] hover:bg-[#20ba59] text-white p-2.5 rounded-lg shadow-luxury transition-colors"
            title="Inquire on WhatsApp"
            aria-label="Inquire about this saree on WhatsApp"
          >
            <MessageCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-3 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-[10px] sm:text-[11px] mb-1">
            <span className="text-raja-gold-dark font-bold uppercase tracking-wider truncate mr-1">
              {product.category}
            </span>
            <span className="text-raja-ink-muted font-medium whitespace-nowrap">
              ★ {product.rating} ({product.reviewCount})
            </span>
          </div>

          {/* Product Title */}
          <h3 className="font-serif text-sm sm:text-base md:text-lg font-semibold text-raja-ink hover:text-raja-maroon transition-colors line-clamp-1">
            <Link href={`/products/${product.slug}`}>{product.name}</Link>
          </h3>

          {/* Fabric & Zari Note */}
          <p className="text-[11px] sm:text-xs text-raja-ink-soft line-clamp-1 mt-0.5">
            {product.fabric} • {product.zariType}
          </p>

          {/* Color Swatches */}
          {product.colors && product.colors.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2.5 sm:mt-3">
              {product.colors.slice(0, 5).map((color, idx) => (
                <button
                  key={color.name}
                  type="button"
                  onClick={() => setSelectedColorIndex(idx)}
                  className={`w-3 h-3 sm:w-3.5 sm:h-3.5 rounded-full border transition-all ${
                    selectedColorIndex === idx
                      ? "ring-2 ring-raja-maroon ring-offset-1 scale-125"
                      : "border-black/20 hover:scale-110"
                  }`}
                  style={{ backgroundColor: color.hex }}
                  title={color.name}
                  aria-label={`Select ${color.name} color`}
                />
              ))}
              {product.colors.length > 5 && (
                <span className="text-[9px] sm:text-[10px] text-raja-ink-muted font-medium ml-1">
                  +{product.colors.length - 5}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Pricing & Stock Status */}
        <div className="pt-2.5 sm:pt-3 mt-2.5 sm:mt-3 border-t border-raja-ink-border/60 flex flex-wrap items-baseline justify-between gap-1">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base sm:text-lg font-bold text-raja-maroon">
              ₹{product.price.toLocaleString("en-IN")}
              {product.unit === "meter" && (
                <span className="text-[10px] sm:text-xs font-normal text-raja-ink-muted ml-0.5">/m</span>
              )}
            </span>
            <span className="text-[10px] sm:text-xs text-raja-ink-muted line-through">
              ₹{product.originalPrice.toLocaleString("en-IN")}
            </span>
          </div>

          <span className="text-[9px] sm:text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 sm:px-2 py-0.5 rounded border border-emerald-200">
            Loom Direct
          </span>
        </div>
      </div>
    </article>
  );
}
