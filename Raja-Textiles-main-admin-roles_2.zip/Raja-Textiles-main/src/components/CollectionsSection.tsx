"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { CATEGORIES } from "@/data/products";

export default function CollectionsSection() {
  const featuredCategory = CATEGORIES[0]; // Karizma Silk
  const otherCategories = CATEGORIES.slice(1);

  return (
    <section className="py-20 md:py-28 bg-white border-b border-raja-ink-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-raja-gold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Curated Loom Collections</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-raja-maroon leading-tight">
              Weaves of Distinction
            </h2>
            <p className="text-sm sm:text-base text-raja-ink-soft mt-3 leading-relaxed">
              Every drape from Raja Textile is woven with distinct jacquard cards, pure metallic
              zari motifs, and celebrated Tamil textile geometry.
            </p>
          </div>

          <Link
            href="/collection"
            className="inline-flex items-center gap-2 text-xs uppercase tracking-wider font-bold text-raja-maroon hover:text-raja-gold transition-colors pb-1 border-b-2 border-raja-maroon hover:border-raja-gold self-start md:self-auto group"
          >
            <span>Explore All Collections</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Asymmetrical Editorial Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
          {/* Main Editorial Hero Collection Card (Span 7) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-7 group relative rounded-2xl overflow-hidden shadow-luxury border border-raja-ink-border bg-raja-wine flex flex-col justify-end min-h-[420px] sm:min-h-[500px]"
          >
            <div className="absolute inset-0 w-full h-full overflow-hidden">
              <img
                src={featuredCategory.image}
                alt={featuredCategory.name}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out opacity-85 group-hover:opacity-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-raja-wine via-raja-wine/50 to-transparent" />
            </div>

            <div className="relative z-10 p-6 sm:p-10 text-white space-y-3">
              <div className="flex items-center gap-2.5">
                <span className="text-[10px] uppercase font-bold tracking-[0.25em] text-raja-gold px-2.5 py-1 rounded bg-white/10 backdrop-blur-sm border border-raja-gold/40">
                  Signature Masterpiece
                </span>
                {featuredCategory.tamilName && (
                  <span className="text-xs text-raja-gold font-medium">
                    {featuredCategory.tamilName}
                  </span>
                )}
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold leading-tight">
                {featuredCategory.name}
              </h3>

              <p className="text-xs sm:text-sm text-raja-ivory/85 max-w-lg leading-relaxed line-clamp-2">
                {featuredCategory.description}
              </p>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-xs text-raja-gold font-medium">
                  {featuredCategory.itemCount} Weaves Ready to Dispatch
                </span>

                <Link
                  href={`/category/${featuredCategory.slug}`}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-raja-gold text-raja-wine font-bold text-xs hover:bg-raja-gold-light transition-all shadow-gold-sm"
                >
                  <span>Explore Collection</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          </motion.div>

          {/* Right 2x2 Grid of Weaves (Span 5) */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            {otherCategories.map((cat, idx) => (
              <motion.div
                key={cat.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="group relative rounded-xl overflow-hidden shadow-sm hover:shadow-luxury border border-raja-ink-border bg-raja-ivory flex flex-col justify-end min-h-[220px] sm:min-h-[240px] transition-all"
              >
                <div className="absolute inset-0 w-full h-full overflow-hidden">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-raja-wine/90 via-raja-wine/40 to-transparent" />
                </div>

                <div className="relative z-10 p-4 text-white space-y-1">
                  {cat.tamilName && (
                    <span className="text-[10px] text-raja-gold font-semibold uppercase tracking-wider block">
                      {cat.tamilName}
                    </span>
                  )}

                  <h4 className="font-serif text-lg font-bold leading-snug group-hover:text-raja-gold transition-colors">
                    <Link href={`/category/${cat.slug}`}>{cat.name}</Link>
                  </h4>

                  <p className="text-[11px] text-raja-ivory/80 line-clamp-1">
                    {cat.tagline}
                  </p>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-[10px] text-raja-ivory/70">
                      {cat.itemCount} Designs
                    </span>
                    <Link
                      href={`/category/${cat.slug}`}
                      className="text-xs text-raja-gold hover:text-white font-semibold flex items-center gap-1"
                    >
                      <span>View</span>
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
