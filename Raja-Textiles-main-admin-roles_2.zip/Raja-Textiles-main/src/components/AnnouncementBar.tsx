"use client";

import React, { useState, useEffect } from "react";
import { Phone, MessageCircle, Sparkles, Truck, ShieldCheck } from "lucide-react";
import { STORE_SETTINGS } from "@/data/products";

export default function AnnouncementBar() {
  const announcements = [
    {
      icon: <Sparkles className="w-3.5 h-3.5 text-raja-gold flex-shrink-0" />,
      text: "Direct from the Master Looms of Elampillai, Salem • Zero Middlemen Markup",
    },
    {
      icon: <Truck className="w-3.5 h-3.5 text-raja-gold flex-shrink-0" />,
      text: "Complimentary Pan-India Delivery on Orders Above ₹999",
    },
    {
      icon: <ShieldCheck className="w-3.5 h-3.5 text-raja-gold flex-shrink-0" />,
      text: "6.25 Meters Authentic Length with Running Contrast Blouse Piece Included",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % announcements.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [announcements.length]);

  return (
    <aside
      aria-label="Store announcement"
      className="bg-raja-wine text-white text-xs py-2 px-3 sm:px-6 border-b border-raja-gold/25 tracking-wide overflow-hidden relative z-50 select-none"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left trust metric - desktop */}
        <div className="hidden lg:flex items-center gap-2 text-raja-ivory/80 text-[11px]">
          <span className="w-1.5 h-1.5 rounded-full bg-raja-gold animate-pulse" />
          <span className="tracking-wider uppercase font-medium text-raja-gold-light">
            Live from Salem Looms
          </span>
          <span className="text-raja-gold/40">•</span>
          <span>PIN: 637502</span>
        </div>

        {/* Center Animated Message Carousel */}
        <div className="flex-1 flex items-center justify-center min-h-[20px] overflow-hidden">
          <div
            key={currentIndex}
            className="flex items-center justify-center gap-2 text-center text-[11px] sm:text-xs text-raja-ivory font-medium transition-all duration-500 ease-out animate-fade-in"
          >
            {announcements[currentIndex].icon}
            <span className="truncate max-w-[280px] sm:max-w-none">
              {announcements[currentIndex].text}
            </span>
          </div>
        </div>

        {/* Right Direct WhatsApp & Call Assist */}
        <div className="hidden sm:flex items-center gap-4 text-[11px]">
          <a
            href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20would%20like%20to%20inquire%20about%20your%20sarees.`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-raja-gold hover:text-white transition-colors font-medium"
          >
            <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
            <span>WhatsApp Order</span>
          </a>
          <span className="text-raja-gold/40 hidden md:inline">•</span>
          <a
            href={`tel:${STORE_SETTINGS.phone.replace(/[^0-9+]/g, "")}`}
            className="hidden md:flex items-center gap-1.5 text-raja-ivory/80 hover:text-white transition-colors"
          >
            <Phone className="w-3 h-3 text-raja-gold" />
            <span>+91 93600 21627</span>
          </a>
        </div>
      </div>
    </aside>
  );
}
