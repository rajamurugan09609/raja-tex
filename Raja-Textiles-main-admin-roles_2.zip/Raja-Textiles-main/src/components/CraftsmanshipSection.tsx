"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";
import Link from "next/link";

export default function CraftsmanshipSection() {
  const steps = [
    {
      id: "jacquard",
      number: "01",
      title: "Electronic Jacquard Card Mapping",
      subtitle: "Geometric & Floral Motifs",
      description:
        "Every Elampillai motif begins with meticulous punch-card mapping. Traditional Tamil Kolam geometry, peacock buttas, and sacred temple spires are encoded thread by thread to ensure crisp, symmetrical patterns across the entire 6.25-meter drape.",
      image: "/images/products/93ceaae9391b962ddae5bf7fb34aea97.jpg",
      highlight: "80's Fine Warp Count",
    },
    {
      id: "zari",
      number: "02",
      title: "Pure Metallic Zari Blending",
      subtitle: "Dual Copper & Antique Gold",
      description:
        "Unlike heavy stiff zari that pricks the skin, our Elampillai artisans blend micro-metallic filaments into the soft silk base. This yields a liquid golden luster that glistens under festive chandeliers while remaining feather-light to wear for long family poojas.",
      image: "/images/products/520c970018c55e4d922933b05cc865c2.jpg",
      highlight: "Non-Tarnish Metallic Finish",
    },
    {
      id: "weaving",
      number: "03",
      title: "Master Loom Weaving in Elampillai",
      subtitle: "Centuries of Salem Heritage",
      description:
        "Our master weavers manage high-precision electronic and shuttle looms in Elampillai, Salem. Each saree takes dedicated hours to calibrate the warp tension, ensuring that pleats fall effortlessly and the pallu drapes with royal grandeur.",
      image: "/images/products/94e8ae5a574f711faa8642c263beae7b.jpg",
      highlight: "Hand-Calibrated Loom Tension",
    },
    {
      id: "inspection",
      number: "04",
      title: "Zero-Flaw Hand Inspection",
      subtitle: "Direct From Loom Packaging",
      description:
        "Before any saree is packed for dispatch, experienced weavers manually inspect every inch of the border, pallu, and running 0.8m blouse piece. Only pieces that meet strict temple-standard perfection are approved for dispatch.",
      image: "/images/products/d3491e83863f4c3f7686c9daedcf312a.jpg",
      highlight: "100% Weave Inspected",
    },
  ];

  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const activeStep = steps[activeStepIndex];

  return (
    <section className="py-20 md:py-28 bg-raja-ivory border-b border-raja-ink-border overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-raja-gold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Artisan Heritage</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-raja-maroon leading-tight">
            The Craftsmanship of Elampillai
          </h2>
          <p className="text-sm sm:text-base text-raja-ink-soft mt-3 leading-relaxed">
            Elampillai in Salem is internationally acclaimed for pioneering lightweight jacquard silks.
            Discover how every Raja Textile drape travels from master loom to your wardrobe.
          </p>
        </div>

        {/* Step Navigation Tabs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
          {steps.map((step, idx) => {
            const isActive = activeStepIndex === idx;
            return (
              <button
                key={step.id}
                type="button"
                onClick={() => setActiveStepIndex(idx)}
                className={`p-4 rounded-xl border text-left transition-all duration-300 relative ${
                  isActive
                    ? "bg-white border-raja-gold shadow-luxury ring-1 ring-raja-gold"
                    : "bg-white/60 border-raja-ink-border hover:bg-white hover:border-raja-gold/50"
                }`}
              >
                <span className="font-serif text-xl font-bold text-raja-gold block mb-1">
                  {step.number}
                </span>
                <h3 className="font-serif text-sm font-bold text-raja-ink truncate">
                  {step.title}
                </h3>
                <p className="text-[11px] text-raja-ink-muted mt-0.5 truncate">
                  {step.subtitle}
                </p>
              </button>
            );
          })}
        </div>

        {/* Interactive Step Display Card */}
        <div className="bg-white rounded-2xl border border-raja-ink-border shadow-luxury overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
            {/* Visual */}
            <div className="lg:col-span-6 relative aspect-[4/3] sm:aspect-[16/10] lg:aspect-auto lg:h-[460px] overflow-hidden bg-raja-ivory">
              <AnimatePresence mode="wait">
                <motion.img
                  key={activeStep.id}
                  src={activeStep.image}
                  alt={activeStep.title}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="w-full h-full object-cover object-center"
                />
              </AnimatePresence>
              <div className="absolute top-4 left-4 bg-raja-wine text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                {activeStep.highlight}
              </div>
            </div>

            {/* Description Content */}
            <div className="lg:col-span-6 p-6 sm:p-10 lg:p-12 space-y-6">
              <div className="space-y-2">
                <span className="text-xs uppercase font-bold tracking-[0.2em] text-raja-gold">
                  Stage {activeStep.number} of 04
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-raja-maroon">
                  {activeStep.title}
                </h3>
                <p className="text-xs text-raja-gold-dark font-medium">
                  {activeStep.subtitle}
                </p>
              </div>

              <p className="text-sm sm:text-base text-raja-ink-soft leading-relaxed">
                {activeStep.description}
              </p>

              {/* Verified Trust Points */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                <div className="flex items-center gap-2 text-raja-ink">
                  <CheckCircle2 className="w-4 h-4 text-raja-gold flex-shrink-0" />
                  <span>Full 6.25m with Blouse</span>
                </div>
                <div className="flex items-center gap-2 text-raja-ink">
                  <CheckCircle2 className="w-4 h-4 text-raja-gold flex-shrink-0" />
                  <span>Crease-Resistant 3D Silk</span>
                </div>
                <div className="flex items-center gap-2 text-raja-ink">
                  <CheckCircle2 className="w-4 h-4 text-raja-gold flex-shrink-0" />
                  <span>Direct Loom Pricing</span>
                </div>
                <div className="flex items-center gap-2 text-raja-ink">
                  <CheckCircle2 className="w-4 h-4 text-raja-gold flex-shrink-0" />
                  <span>Zero Middlemen Commission</span>
                </div>
              </div>

              <div className="pt-4 border-t border-raja-ink-border flex items-center justify-between">
                <Link
                  href="/about"
                  className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-raja-maroon hover:text-raja-gold transition-colors"
                >
                  <span>Read Full Heritage Chronicle</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setActiveStepIndex((prev) => (prev === 0 ? steps.length - 1 : prev - 1))
                    }
                    className="p-2 rounded-lg border border-raja-ink-border hover:border-raja-maroon text-xs"
                    aria-label="Previous step"
                  >
                    ←
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setActiveStepIndex((prev) => (prev === steps.length - 1 ? 0 : prev + 1))
                    }
                    className="p-2 rounded-lg border border-raja-ink-border hover:border-raja-maroon text-xs"
                    aria-label="Next step"
                  >
                    →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
