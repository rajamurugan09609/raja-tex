"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  MapPin,
  Phone,
  MessageCircle,
  Clock,
  ShieldCheck,
  Truck,
  Sparkles,
  ArrowRight,
  Mail,
  Check,
} from "lucide-react";
import { STORE_SETTINGS, CATEGORIES } from "@/data/products";
import BrandLogo from "./BrandLogo";

export default function Footer() {
  const [emailInput, setEmailInput] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const developerUrl = process.env.NEXT_PUBLIC_DEVELOPER_URL || STORE_SETTINGS.developerUrl || "";

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput.trim()) return;
    setIsSubscribed(true);
    setEmailInput("");
  };

  return (
    <footer className="bg-raja-wine text-raja-ivory border-t-2 border-raja-gold/30 relative overflow-hidden">
      {/* Decorative ambient background accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-raja-gold/5 rounded-full blur-3xl pointer-events-none" />

      {/* Trust & Guarantee Banner */}
      <div className="border-b border-raja-gold/20 bg-black/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-raja-gold/15 flex items-center justify-center border border-raja-gold/30 flex-shrink-0 text-raja-gold">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif text-base font-bold text-white">Direct From Master Looms</h4>
                <p className="text-xs text-raja-ivory/70 mt-1 leading-relaxed">
                  Crafted in Elampillai, Salem with authentic weaver pricing
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-raja-gold/15 flex items-center justify-center border border-raja-gold/30 flex-shrink-0 text-raja-gold">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif text-base font-bold text-white">Free Pan-India Delivery</h4>
                <p className="text-xs text-raja-ivory/70 mt-1 leading-relaxed">
                  Complimentary tracked courier on orders above ₹999
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-raja-gold/15 flex items-center justify-center border border-raja-gold/30 flex-shrink-0 text-raja-gold">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif text-base font-bold text-white">100% Quality Inspected</h4>
                <p className="text-xs text-raja-ivory/70 mt-1 leading-relaxed">
                  Every textile piece manually checked by weavers before packing
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-raja-gold/15 flex items-center justify-center border border-raja-gold/30 flex-shrink-0 text-raja-gold">
                <MessageCircle className="w-6 h-6 text-[#25D366]" />
              </div>
              <div>
                <h4 className="font-serif text-base font-bold text-white">WhatsApp Video Assist</h4>
                <p className="text-xs text-raja-ivory/70 mt-1 leading-relaxed">
                  Inspect weave textures & colors with our weavers on live video
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8">
          {/* Brand Info & Newsletter (Col 5) */}
          <div className="lg:col-span-5 space-y-6">
            <BrandLogo variant="footer" />

            <p className="text-sm text-raja-ivory/80 leading-relaxed max-w-md">
              Rooted in the celebrated textile hub of Elampillai, Salem. We produce genuine 3D
              embossed Karizma silks, raw silk fabrics, festive dress materials, traditional dhotis,
              and luxury jacquard home furnishings direct from master weavers.
            </p>

            {/* Newsletter Form */}
            <div className="pt-2 max-w-md">
              <span className="text-xs font-bold uppercase tracking-wider text-raja-gold block mb-2">
                Join our Loom Edition Circle
              </span>
              {isSubscribed ? (
                <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-lg text-emerald-200 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Vanakkam! You are subscribed to new loom releases.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2">
                  <div className="relative flex-1">
                    <Mail className="w-4 h-4 text-raja-gold/60 absolute left-3 top-3.5" />
                    <input
                      type="email"
                      required
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="Enter your email"
                      className="w-full text-xs pl-9 pr-3 py-3 rounded-lg bg-white/10 border border-raja-gold/30 text-white placeholder-raja-ivory/50 focus:outline-none focus:border-raja-gold"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-3 rounded-lg bg-raja-gold text-raja-wine font-bold text-xs hover:bg-raja-gold-light transition-colors shadow-gold-sm flex-shrink-0"
                  >
                    Subscribe
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Quick Links: Textile Departments (Col 3) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-serif text-base font-bold text-white tracking-wide">
              Textile Departments
            </h4>
            <ul className="space-y-2.5 text-xs text-raja-ivory/80">
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <Link
                    href={`/category/${cat.slug}`}
                    className="hover:text-raja-gold transition-colors inline-block"
                  >
                    {cat.name}
                  </Link>
                </li>
              ))}
              <li className="pt-1">
                <Link
                  href="/collection"
                  className="text-raja-gold hover:text-white font-bold inline-flex items-center gap-1"
                >
                  <span>Explore Full Collection</span>
                  <ArrowRight className="w-3 h-3" />
                </Link>
              </li>
            </ul>
          </div>

          {/* Customer Care (Col 2) */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="font-serif text-base font-bold text-white tracking-wide">
              Customer Care
            </h4>
            <ul className="space-y-2.5 text-xs text-raja-ivory/80">
              <li>
                <Link href="/shipping-policy" className="hover:text-raja-gold transition-colors">
                  Pan-India Shipping
                </Link>
              </li>
              <li>
                <Link href="/returns-policy" className="hover:text-raja-gold transition-colors">
                  Returns & Exchange
                </Link>
              </li>
              <li>
                <Link href="/saree-care-guide" className="hover:text-raja-gold transition-colors">
                  Textile & Zari Care
                </Link>
              </li>
              <li>
                <Link href="/track-order" className="hover:text-raja-gold transition-colors">
                  Track Your Order
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-raja-gold transition-colors">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-raja-gold transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* Salem Flagship Store (Col 2) */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="font-serif text-base font-bold text-white tracking-wide">
              Salem Showroom
            </h4>
            <div className="space-y-3 text-xs text-raja-ivory/80">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-raja-gold flex-shrink-0 mt-0.5" />
                <address className="not-italic leading-relaxed">
                  Raja Textile, Main Road,
                  <br />
                  Elampillai, Salem — 637502,
                  <br />
                  Tamil Nadu, India
                </address>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-raja-gold flex-shrink-0" />
                <a
                  href={`tel:${STORE_SETTINGS.phone.replace(/[^0-9+]/g, "")}`}
                  className="hover:text-white transition-colors"
                >
                  {STORE_SETTINGS.phone}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-raja-gold flex-shrink-0" />
                <span>{STORE_SETTINGS.operatingHours}</span>
              </div>

              <div className="pt-2">
                <a
                  href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20would%20like%20to%20chat.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#25D366] text-white font-bold text-xs hover:bg-[#20ba59] transition-colors shadow-sm"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Chat on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright Bar (Completely Public, No Admin links) */}
      <div className="border-t border-raja-gold/20 bg-black/40 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-raja-ivory/60 text-center sm:text-left">
            <p>
              © {new Date().getFullYear()} Raja Textile, Elampillai, Salem. All rights reserved. Handloom heritage of Tamil Nadu.
            </p>
            <div className="flex items-center gap-5">
              <span className="text-raja-gold/80 font-medium">Safe & Verified UPI • Card • COD</span>
              <span className="text-raja-gold/40">•</span>
              <Link href="/about" className="hover:text-raja-gold transition-colors">
                About Our Weavers
              </Link>
            </div>
          </div>

          {/* Subtle, Professional Developer Credit */}
          <div className="pt-3 border-t border-raja-gold/10 flex items-center justify-center text-[11px] text-raja-ivory/50">
            <p className="tracking-wide">
              Developed by{" "}
              {developerUrl ? (
                <a
                  href={developerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium text-raja-gold/90 hover:text-raja-gold transition-colors underline underline-offset-2 decoration-raja-gold/40 hover:decoration-raja-gold"
                >
                  Altrivelle Technologies
                </a>
              ) : (
                <span className="font-medium text-raja-ivory/70">Altrivelle Technologies</span>
              )}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
