"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  Search,
  Heart,
  ShoppingBag,
  User as UserIcon,
  Phone,
  MessageCircle,
  MapPin,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { useAuth } from "@/context/AuthContext";
import { STORE_SETTINGS, CATEGORIES } from "@/data/products";
import BrandLogo from "./BrandLogo";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const { totalCount, setIsCartOpen } = useCart();
  const { wishlistCount } = useWishlist();
  const { user, profile } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [pathname]);

  // Main navigation required strictly: Home, Collection, About, Contact
  const navLinks = [
    { label: "Home", href: "/" },
    { label: "Collection", href: "/collection" },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <>
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          scrolled
            ? "bg-white/95 backdrop-blur-md shadow-luxury border-b border-raja-gold/25 py-2.5"
            : "bg-raja-ivory/85 backdrop-blur-sm border-b border-raja-ink-border/80 py-3.5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Mobile menu trigger */}
            <div className="flex items-center lg:hidden">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="p-2 -ml-2 text-raja-ink hover:text-raja-maroon focus:outline-none focus:ring-2 focus:ring-raja-gold/50 rounded-lg"
                aria-label="Open mobile navigation menu"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>

            {/* Brand Logo with finalized artwork */}
            <div className="flex-1 lg:flex-none text-left min-w-0 px-1 sm:px-0">
              <BrandLogo variant="header" />
            </div>

            {/* Desktop Main Navigation: Home, Collection, About, Contact */}
            <nav className="hidden lg:flex items-center space-x-9" aria-label="Main navigation">
              {navLinks.map((link) => {
                const isActive =
                  pathname === link.href ||
                  (link.href === "/products" &&
                    (pathname.startsWith("/products") || pathname.startsWith("/category")));
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={`text-xs uppercase tracking-[0.2em] font-bold transition-all relative py-2 ${
                      isActive
                        ? "text-raja-maroon font-bold"
                        : "text-raja-ink-soft hover:text-raja-maroon"
                    }`}
                  >
                    {link.label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-underline"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-raja-gold rounded-full"
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Utility Actions: Search, Account, Wishlist, Cart */}
            <div className="flex items-center space-x-0.5 sm:space-x-3 shrink-0">
              {/* 1. Search */}
              <button
                type="button"
                onClick={() => {
                  window.dispatchEvent(new CustomEvent("open-search-modal"));
                }}
                className="p-2.5 text-raja-ink hover:text-raja-maroon transition-all rounded-full hover:bg-raja-ivory focus:outline-none group relative"
                aria-label="Search collection"
                title="Search Textiles (Ctrl+K)"
              >
                <Search className="w-5 h-5 group-hover:scale-110 transition-transform" />
              </button>

              {/* 2. Account */}
              <Link
                href={user ? "/account" : "/auth/login"}
                className="p-1.5 sm:p-2 text-raja-ink hover:text-raja-maroon transition-all rounded-full hover:bg-raja-ivory focus:outline-none group relative flex items-center justify-center"
                aria-label={user ? "Customer Account" : "Sign In to Raja Textile"}
                title={user ? `Account: ${user.email}` : "Sign In"}
              >
                {user ? (
                  <div className="w-7 h-7 rounded-full bg-raja-wine text-raja-gold border border-raja-gold flex items-center justify-center text-xs font-bold shadow-sm ring-1 ring-raja-gold/30 group-hover:scale-105 transition-transform">
                    {(profile?.fullName || user.email || "U").charAt(0).toUpperCase()}
                  </div>
                ) : (
                  <UserIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                )}
              </Link>

              {/* 3. Wishlist */}
              <Link
                href="/wishlist"
                className="p-2.5 text-raja-ink hover:text-raja-maroon transition-all rounded-full hover:bg-raja-ivory relative focus:outline-none group"
                aria-label={`Wishlist with ${wishlistCount} items`}
                title="Wishlist"
              >
                <Heart className="w-5 h-5 group-hover:scale-110 transition-transform" />
                {wishlistCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-raja-maroon text-white text-[10px] font-bold flex items-center justify-center shadow-sm">
                    {wishlistCount}
                  </span>
                )}
              </Link>

              {/* 4. Shopping Cart */}
              <button
                type="button"
                onClick={() => setIsCartOpen(true)}
                className="p-2.5 text-raja-ink hover:text-raja-maroon transition-all rounded-full hover:bg-raja-ivory relative focus:outline-none group"
                aria-label={`Shopping bag with ${totalCount} items`}
                title="Shopping Bag"
              >
                <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
                {totalCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-raja-gold text-raja-wine text-[10px] font-bold flex items-center justify-center shadow-gold-sm animate-pulse">
                    {totalCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Framer Motion Mobile Navigation Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden overflow-hidden">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="fixed inset-0 bg-raja-wine/50 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />

            {/* Drawer Content */}
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 260 }}
              className="fixed inset-y-0 left-0 w-full max-w-sm bg-white shadow-2xl flex flex-col justify-between border-r border-raja-gold/30"
            >
              {/* Drawer Header */}
              <div className="p-5 border-b border-raja-ink-border bg-raja-ivory/60 flex items-center justify-between">
                <BrandLogo variant="mobile" />
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-raja-ink-soft hover:text-raja-maroon focus:outline-none rounded-full hover:bg-white"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation Items */}
              <div className="flex-1 overflow-y-auto px-5 py-6 space-y-6">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.2em] text-raja-gold font-bold px-2 mb-2 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3" />
                    <span>Navigation</span>
                  </p>
                  <div className="space-y-1">
                    {navLinks.map((link) => {
                      const isActive =
                        pathname === link.href ||
                        (link.href === "/products" && pathname.startsWith("/products"));
                      return (
                        <Link
                          key={link.href}
                          href={link.href}
                          className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-bold transition-all ${
                            isActive
                              ? "bg-raja-maroon text-white shadow-sm"
                              : "text-raja-ink hover:bg-raja-ivory"
                          }`}
                        >
                          <span>{link.label}</span>
                          <ChevronRight
                            className={`w-4 h-4 ${
                              isActive ? "text-raja-gold" : "text-raja-ink-muted"
                            }`}
                          />
                        </Link>
                      );
                    })}
                  </div>
                </div>

                {/* Account / Profile Quick Action */}
                <div className="p-3.5 rounded-xl bg-raja-ivory border border-raja-ink-border/70 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-raja-maroon text-white flex items-center justify-center text-xs font-bold">
                      {user ? (profile?.fullName || user.email || "U").charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-raja-ink">
                        {user ? (profile?.fullName || "My Account") : "Welcome, Guest"}
                      </p>
                      <p className="text-[11px] text-raja-ink-muted truncate max-w-[140px]">
                        {user ? user.email : "Sign in to view orders"}
                      </p>
                    </div>
                  </div>
                  <Link
                    href={user ? "/account" : "/auth/login"}
                    className="text-xs font-bold text-raja-maroon hover:underline"
                  >
                    {user ? "View" : "Sign In"}
                  </Link>
                </div>

                {/* Textile Categories & Departments */}
                <div>
                  <p className="text-[10px] uppercase tracking-[0.2em] text-raja-gold font-bold px-2 mb-2">
                    Textile Departments
                  </p>
                  <div className="grid grid-cols-1 gap-1.5">
                    {CATEGORIES.map((cat) => (
                      <Link
                        key={cat.id}
                        href={`/category/${cat.slug}`}
                        className="flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-raja-ink hover:text-raja-maroon hover:bg-raja-ivory rounded-lg border border-transparent hover:border-raja-ink-border transition-all"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="w-2 h-2 rounded-full bg-raja-gold" />
                          <span className="font-semibold">{cat.name}</span>
                        </div>
                        {cat.tamilName && (
                          <span className="text-[10px] text-raja-gold font-medium">
                            {cat.tamilName}
                          </span>
                        )}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Direct Loom Weaver Support */}
                <div className="bg-gradient-to-br from-raja-ivory to-raja-ivory-warm p-4 rounded-xl border border-raja-gold/30 space-y-3">
                  <div>
                    <p className="text-xs font-bold text-raja-maroon flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-raja-gold" />
                      Showroom in Elampillai, Salem
                    </p>
                    <p className="text-[11px] text-raja-ink-soft leading-relaxed mt-1">
                      {STORE_SETTINGS.address}, Salem — 637502
                      <br />
                      {STORE_SETTINGS.operatingHours}
                    </p>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <a
                      href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20am%20inquiring%20about%20your%20textiles.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-1.5 bg-[#25D366] text-white py-2.5 rounded-lg text-xs font-bold shadow-sm"
                    >
                      <MessageCircle className="w-4 h-4" />
                      WhatsApp
                    </a>
                    <a
                      href={`tel:${STORE_SETTINGS.phone.replace(/[^0-9+]/g, "")}`}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-raja-maroon text-white py-2.5 rounded-lg text-xs font-bold shadow-sm"
                    >
                      <Phone className="w-3.5 h-3.5 text-raja-gold" />
                      Call
                    </a>
                  </div>
                </div>
              </div>

              {/* Bottom Bar: Copyright only (No Admin links) */}
              <div className="p-4 border-t border-raja-ink-border bg-raja-ivory/50 flex items-center justify-between text-xs text-raja-ink-soft">
                <span>Direct Elampillai Handloom Looms</span>
                <span>© {new Date().getFullYear()} Raja Textile</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
