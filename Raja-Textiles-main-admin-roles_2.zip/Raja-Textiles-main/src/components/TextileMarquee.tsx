"use client";

import React from "react";
import { Sparkles } from "lucide-react";

export default function TextileMarquee() {
  const marqueeItems = [
    { text: "3D Embossed Karizma Silk", tag: "Elampillai Special" },
    { text: "சேலம் இளம்பிள்ளை பட்டு", tag: "Authentic Salem Weave" },
    { text: "Auspicious Vintage Kolam Sarees", tag: "Pure Zari Pallu" },
    { text: "Shining Soft Silk with Lichi Finish", tag: "Festive Edition" },
    { text: "Direct Loom Price • Zero Middlemen Markup", tag: "Save 50%–67%" },
    { text: "Muhurtham & Wedding Brocade Silks", tag: "Grand Bridal Weaves" },
    { text: "Traditional Temple Gopuram Borders", tag: "Heritage Art" },
    { text: "Pan-India Express Safe Delivery", tag: "Tamil Nadu Master Looms" },
  ];

  return (
    <div
      aria-label="Textile collections ticker"
      className="bg-raja-wine text-white py-3 border-y border-raja-gold/30 overflow-hidden select-none relative group"
    >
      {/* Golden gradient fade masks on edges */}
      <div className="absolute left-0 inset-y-0 w-12 sm:w-24 bg-gradient-to-r from-raja-wine to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 inset-y-0 w-12 sm:w-24 bg-gradient-to-l from-raja-wine to-transparent z-10 pointer-events-none" />

      {/* Marquee Track with pause on hover */}
      <div className="flex w-max animate-marquee group-hover:[animation-play-state:paused]">
        {/* Set 1 */}
        <div className="flex items-center space-x-8 sm:space-x-12 pr-8 sm:pr-12">
          {marqueeItems.map((item, index) => (
            <div key={`m1-${index}`} className="flex items-center space-x-3 whitespace-nowrap">
              <Sparkles className="w-3.5 h-3.5 text-raja-gold flex-shrink-0 animate-pulse" />
              <span className="font-serif text-sm sm:text-base font-semibold tracking-wide text-raja-ivory">
                {item.text}
              </span>
              <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-raja-gold/20 text-raja-gold border border-raja-gold/40">
                {item.tag}
              </span>
            </div>
          ))}
        </div>

        {/* Set 2 (Seamless loop duplicate) */}
        <div className="flex items-center space-x-8 sm:space-x-12 pr-8 sm:pr-12" aria-hidden="true">
          {marqueeItems.map((item, index) => (
            <div key={`m2-${index}`} className="flex items-center space-x-3 whitespace-nowrap">
              <Sparkles className="w-3.5 h-3.5 text-raja-gold flex-shrink-0 animate-pulse" />
              <span className="font-serif text-sm sm:text-base font-semibold tracking-wide text-raja-ivory">
                {item.text}
              </span>
              <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-raja-gold/20 text-raja-gold border border-raja-gold/40">
                {item.tag}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
