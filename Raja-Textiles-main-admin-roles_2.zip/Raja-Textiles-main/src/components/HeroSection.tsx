"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight,
  Sparkles,
  ShieldCheck,
  MessageCircle,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Tag,
} from "lucide-react";
import { HeroSlide } from "@/types";
import { INITIAL_HERO_SLIDES, STORE_SETTINGS } from "@/data/products";

export default function HeroSection() {
  const [slides, setSlides] = useState<HeroSlide[]>(INITIAL_HERO_SLIDES);
  const [activeHeroIndex, setActiveHeroIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);

  const SLIDE_DURATION = 5500; // 5.5 seconds
  const INTERVAL_STEP = 50; // update progress every 50ms

  // Fetch live active hero slides (configured by owner)
  useEffect(() => {
    fetch("/api/hero-slides")
      .then((res) => res.json())
      .then((data) => {
        if (data.slides && Array.isArray(data.slides) && data.slides.length > 0) {
          setSlides(data.slides);
        }
      })
      .catch(() => {
        // fallback to INITIAL_HERO_SLIDES
      });
  }, []);

  // Auto-advance timer with progress tracking
  useEffect(() => {
    if (isPaused || slides.length === 0) return;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setActiveHeroIndex((current) => (current + 1) % slides.length);
          return 0;
        }
        return prev + (INTERVAL_STEP / SLIDE_DURATION) * 100;
      });
    }, INTERVAL_STEP);

    return () => clearInterval(timer);
  }, [isPaused, slides.length]);

  const selectHero = (index: number) => {
    setActiveHeroIndex(index);
    setProgress(0);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveHeroIndex((prev) => (prev - 1 + slides.length) % slides.length);
    setProgress(0);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveHeroIndex((prev) => (prev + 1) % slides.length);
    setProgress(0);
  };

  const activeSlide = slides[activeHeroIndex] || slides[0] || INITIAL_HERO_SLIDES[0];

  return (
    <section
      className="relative bg-raja-ivory overflow-hidden border-b border-raja-ink-border min-h-[85vh] lg:min-h-[92vh] flex items-center"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background ambient gold & wine glow */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-raja-gold/10 rounded-full blur-3xl pointer-events-none -mr-40 -mt-20" />
      <div className="absolute bottom-0 left-0 w-[450px] h-[450px] bg-raja-maroon/5 rounded-full blur-3xl pointer-events-none -ml-32 -mb-20" />

      {/* Subtle traditional loom grid pattern */}
      <div className="absolute inset-0 opacity-[0.035] pointer-events-none bg-[radial-gradient(#681329_1px,transparent_1px)] [background-size:24px_24px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Left Column: Editorial Headlines & Interactive Carousel Nav */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Pill Badge */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-raja-maroon/10 border border-raja-maroon/20 text-raja-maroon text-xs font-bold tracking-widest uppercase shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-raja-gold" />
              <span>Direct Loom Weaves • Salem, Tamil Nadu</span>
            </motion.div>

            {/* Editorial Headline */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="space-y-1"
            >
              <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl lg:text-7xl text-raja-maroon font-bold leading-[1.08] tracking-tight">
                Where Sacred Threads
                <br />
                <span className="italic font-normal text-raja-ink">Meet Modern</span>{" "}
                <span className="gold-gradient-text font-serif italic">Majesty.</span>
              </h1>
            </motion.div>

            {/* Subtitle / Description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-sm sm:text-base md:text-lg text-raja-ink-soft max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal"
            >
              Experience master weaving direct from Elampillai, Salem. Traditional soft silks,
              3D embossed Karizma weaves, unstitched fabrics, men&apos;s dhotis, and wedding heirlooms
              crafted on electronic jacquards with zero retail markup.
            </motion.p>

            {/* Call To Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2"
            >
              <Link
                href="/products"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-lg bg-raja-maroon hover:bg-raja-maroon-light text-white font-semibold text-sm shadow-luxury hover:shadow-luxury-hover transition-all duration-300 hover:-translate-y-0.5 group"
              >
                <span>Shop All Textiles</span>
                <ArrowRight className="w-4 h-4 text-raja-gold group-hover:translate-x-1 transition-transform" />
              </Link>

              <a
                href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20would%20like%20to%20view%20your%20latest%20textiles%20on%20live%20video%20and%20order%20direct%20from%20loom.`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-lg bg-white hover:bg-raja-ivory text-raja-ink border border-raja-gold/40 font-semibold text-sm shadow-sm transition-all duration-300 hover:border-raja-gold"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>WhatsApp Video Assist</span>
              </a>
            </motion.div>

            {/* Interactive Hero Carousel Selector Bar (Shows Products + Advertisement Banners in Admin Order) */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="pt-6 border-t border-raja-ink-border/80"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-raja-gold-dark flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-raja-gold" />
                  <span>Featured &amp; Campaign Spotlight ({slides.length})</span>
                </span>
                <span className="text-[11px] text-raja-ink-muted">
                  {isPaused ? "Paused on hover" : "Auto-cycles in sequence"}
                </span>
              </div>

              {/* Responsive Slide Selector Tabs */}
              <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-none max-w-xl mx-auto lg:mx-0">
                {slides.map((slide, index) => {
                  const isActive = activeHeroIndex === index;
                  const isAd = slide.type === "advertisement";
                  return (
                    <button
                      key={slide.id}
                      type="button"
                      onClick={() => selectHero(index)}
                      className={`relative flex-shrink-0 text-left p-2.5 rounded-xl border transition-all text-xs w-[145px] sm:w-[160px] overflow-hidden ${
                        isActive
                          ? "bg-white border-raja-maroon shadow-md ring-1 ring-raja-maroon"
                          : "bg-white/70 border-raja-ink-border hover:bg-white hover:border-raja-gold/60"
                      }`}
                      aria-label={`Select ${slide.title}`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                            isAd
                              ? "bg-amber-100 text-amber-900 border border-amber-300"
                              : "bg-raja-maroon/10 text-raja-maroon"
                          }`}
                        >
                          {isAd ? "Promo / Ad" : "Weave"}
                        </span>
                        {slide.price ? (
                          <span className="text-[10px] font-bold text-raja-maroon">
                            ₹{slide.price}
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-emerald-700">
                            {slide.discountBadge || "Special"}
                          </span>
                        )}
                      </div>
                      <p className="font-semibold text-raja-ink truncate text-[11px] leading-snug">
                        {slide.title}
                      </p>
                      <p className="text-[10px] text-raja-gold-dark font-medium truncate">
                        {slide.tamilTitle || slide.badge || "Elampillai Special"}
                      </p>

                      {/* Animated Progress Bar on Active Item */}
                      {isActive && (
                        <div className="absolute bottom-0 left-0 right-0 h-1 bg-raja-ivory overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-raja-gold to-raja-maroon transition-all duration-75 ease-linear"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          </div>

          {/* Right Column: Cinematic Textile Visual & Floating Details */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer decorative golden border frame */}
              <div className="absolute -inset-2.5 rounded-3xl border border-raja-gold/40 transform rotate-1 hidden sm:block pointer-events-none" />

              {/* Main Saree / Advertisement Visual Card with Framer Motion AnimatePresence */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-white border border-raja-ink-border aspect-[4/5] flex flex-col justify-between">
                {/* Visual Area with Image Crossfade */}
                <div className="absolute inset-0 w-full h-full">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={activeSlide.id}
                      initial={{ opacity: 0, scale: 1.05 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
                      className="absolute inset-0 w-full h-full"
                    >
                      <img
                        src={activeSlide.imageUrl}
                        alt={activeSlide.title}
                        className="w-full h-full object-cover object-center"
                      />
                      {/* Gradient Overlay for text contrast */}
                      <div className="absolute inset-0 bg-gradient-to-t from-raja-wine via-raja-wine/40 to-transparent" />
                    </motion.div>
                  </AnimatePresence>
                </div>

                {/* Top Overlay Elements */}
                <div className="relative z-20 p-4 sm:p-5 flex items-start justify-between gap-2">
                  <div className="flex flex-col gap-1.5">
                    <span
                      className={`text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-md w-fit ${
                        activeSlide.type === "advertisement"
                          ? "bg-amber-600 text-white"
                          : "bg-raja-maroon text-white"
                      }`}
                    >
                      {activeSlide.badge || (activeSlide.type === "advertisement" ? "Featured Campaign" : "Direct Loom")}
                    </span>
                    {activeSlide.discountBadge && (
                      <span className="bg-white/95 backdrop-blur-sm text-raja-ink text-[10px] font-semibold px-2.5 py-0.5 rounded-full shadow-sm w-fit border border-raja-gold/30">
                        {activeSlide.discountBadge}
                      </span>
                    )}
                  </div>

                  {/* Certified Authenticity or Campaign Badge */}
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/95 backdrop-blur-md border border-raja-gold/60 text-raja-ink text-[10px] font-bold shadow-md">
                    {activeSlide.type === "advertisement" ? (
                      <>
                        <Tag className="w-3.5 h-3.5 text-raja-gold" />
                        <span>Exclusive Offer</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-3.5 h-3.5 text-raja-gold" />
                        <span>Loom Certified</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Middle Arrows: Next & Prev manual triggers */}
                <div className="relative z-20 px-3 flex items-center justify-between pointer-events-none">
                  <button
                    type="button"
                    onClick={handlePrev}
                    className="pointer-events-auto p-2 rounded-full bg-white/85 hover:bg-white text-raja-ink hover:text-raja-maroon shadow-luxury border border-raja-ink-border transition-all hover:scale-110"
                    aria-label="Previous Slide"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={handleNext}
                    className="pointer-events-auto p-2 rounded-full bg-white/85 hover:bg-white text-raja-ink hover:text-raja-maroon shadow-luxury border border-raja-ink-border transition-all hover:scale-110"
                    aria-label="Next Slide"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Bottom Info Overlay */}
                <div className="relative z-20 p-5 sm:p-6 text-white space-y-2.5">
                  <div>
                    {activeSlide.tamilTitle && (
                      <span className="text-[10px] tracking-widest uppercase font-semibold text-raja-gold block mb-0.5">
                        {activeSlide.tamilTitle}
                      </span>
                    )}
                    <h3 className="font-serif text-xl sm:text-2xl font-bold leading-snug">
                      {activeSlide.title}
                    </h3>
                  </div>

                  {activeSlide.subtitle && (
                    <p className="text-xs text-raja-ivory/85 line-clamp-2 leading-relaxed">
                      {activeSlide.subtitle}
                    </p>
                  )}

                  <div className="flex items-center justify-between pt-3 border-t border-white/20">
                    <div className="flex items-baseline gap-2">
                      {activeSlide.price ? (
                        <>
                          <span className="text-2xl sm:text-3xl font-bold text-raja-gold">
                            ₹{activeSlide.price.toLocaleString("en-IN")}
                          </span>
                          {activeSlide.originalPrice && (
                            <span className="text-xs text-raja-ivory/60 line-through">
                              ₹{activeSlide.originalPrice.toLocaleString("en-IN")}
                            </span>
                          )}
                        </>
                      ) : (
                        <span className="text-lg sm:text-xl font-bold text-raja-gold">
                          {activeSlide.discountBadge || "Salem Handloom"}
                        </span>
                      )}
                    </div>

                    <Link
                      href={activeSlide.linkUrl}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-raja-gold text-raja-wine font-bold text-xs hover:bg-raja-gold-light transition-all shadow-gold-sm hover:scale-105"
                    >
                      <span>{activeSlide.buttonText || (activeSlide.type === "advertisement" ? "Explore Offer" : "View Saree")}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </div>

              {/* Bottom Assurance Strip below card */}
              <div className="mt-3 bg-white/90 backdrop-blur-sm border border-raja-gold/40 rounded-xl p-3 shadow-sm flex items-center justify-between text-xs text-raja-ink">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 flex-shrink-0" />
                  <span className="font-medium text-[11px] sm:text-xs">
                    Authentic Salem Handlooms • Fast Dispatch
                  </span>
                </div>
                <span className="text-[10px] text-raja-ink-muted hidden sm:inline">
                  Slide {activeHeroIndex + 1} of {slides.length}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
