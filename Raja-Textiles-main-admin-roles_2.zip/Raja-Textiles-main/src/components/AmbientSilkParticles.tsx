"use client";

import React, { useEffect, useState } from "react";

type ParticleType = "mote" | "strand" | "sparkle";

interface Particle {
  id: number;
  type: ParticleType;
  x: number; // percentage
  y: number; // percentage
  size: number; // px
  height?: number; // px (for strand)
  duration: number; // seconds
  delay: number; // seconds
  opacity: number;
  driftX: number; // px sway
  rot: number; // deg
}

export default function AmbientSilkParticles() {
  const [particles, setParticles] = useState<Particle[]>([]);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    // Respect user's motion preference
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mediaQuery.matches);

    const listener = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener("change", listener);

    if (!mediaQuery.matches) {
      const isMobile = window.innerWidth < 768;
      // 12 particles on mobile for 60fps responsiveness, 24 on desktop
      const count = isMobile ? 12 : 24;

      const items: Particle[] = Array.from({ length: count }).map((_, i) => {
        // Distribute types: ~50% golden zari motes, ~30% floating silk threads, ~20% glint sparkles
        const randType = Math.random();
        let type: ParticleType = "mote";
        if (randType > 0.75) {
          type = "sparkle";
        } else if (randType > 0.45) {
          type = "strand";
        }

        const size =
          type === "sparkle"
            ? Math.random() * 4 + 9 // 9px - 13px star glint
            : type === "strand"
            ? Math.random() * 0.8 + 1.4 // 1.4px - 2.2px thread width
            : Math.random() * 2.8 + 3.4; // 3.4px - 6.2px glowing golden mote

        const height =
          type === "strand" ? Math.random() * 8 + 14 : undefined; // 14px - 22px length

        const duration =
          type === "sparkle"
            ? Math.random() * 2.5 + 4.5 // 4.5s - 7s sparkle cycle
            : type === "strand"
            ? Math.random() * 4 + 9.5 // 9.5s - 13.5s slow thread drift
            : Math.random() * 4.5 + 7.5; // 7.5s - 12s mote upward float

        return {
          id: i,
          type,
          // Full viewport coverage across horizontal width (4% to 96%)
          x: Math.random() * 92 + 4,
          y: Math.random() * 94 + 3,
          size,
          height,
          duration,
          // Negative delay ensures particles are active immediately on load
          delay: Math.random() * -14,
          // High-contrast, luxurious opacity so they are clearly visible
          opacity:
            type === "sparkle"
              ? Math.random() * 0.35 + 0.55 // 55% - 90%
              : Math.random() * 0.3 + 0.45, // 45% - 75%
          driftX: (Math.random() - 0.5) * 60, // -30px to +30px sway
          rot: Math.random() * 60 + 20, // 20deg to 80deg
        };
      });

      setParticles(items);
    }

    return () => mediaQuery.removeEventListener("change", listener);
  }, []);

  if (reducedMotion || particles.length === 0) {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none overflow-hidden z-30 select-none"
    >
      {particles.map((p) => {
        if (p.type === "sparkle") {
          return (
            <div
              key={p.id}
              className="absolute will-change-transform pointer-events-none flex items-center justify-center text-[#DFC077]"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                width: `${p.size}px`,
                height: `${p.size}px`,
                animation: `sparkleGlint ${p.duration}s ease-in-out infinite`,
                animationDelay: `${p.delay}s`,
                // @ts-expect-error custom css variable
                "--particle-opacity": p.opacity,
              }}
            >
              <svg
                viewBox="0 0 24 24"
                fill="currentColor"
                className="w-full h-full filter drop-shadow-[0_0_5px_rgba(223,192,119,0.85)]"
              >
                <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
              </svg>
            </div>
          );
        }

        if (p.type === "strand") {
          return (
            <div
              key={p.id}
              className="absolute rounded-full will-change-transform pointer-events-none"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                width: `${p.size}px`,
                height: `${p.height}px`,
                background:
                  "linear-gradient(180deg, rgba(255, 244, 189, 0.15) 0%, rgba(212, 175, 55, 0.95) 50%, rgba(155, 113, 32, 0.25) 100%)",
                boxShadow: "0 0 6px rgba(212, 175, 55, 0.65)",
                animation: `silkStrandDrift ${p.duration}s ease-in-out infinite`,
                animationDelay: `${p.delay}s`,
                // @ts-expect-error custom css variable
                "--particle-opacity": p.opacity,
                "--drift-x": `${p.driftX}px`,
                "--rot": `${p.rot}deg`,
              }}
            />
          );
        }

        // Standard Golden Zari Mote
        return (
          <div
            key={p.id}
            className="absolute rounded-full will-change-transform pointer-events-none"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: `${p.size}px`,
              height: `${p.size}px`,
              background:
                "radial-gradient(circle, #FFF4BD 15%, #D4AF37 60%, #9B7120 100%)",
              boxShadow:
                "0 0 10px 1.5px rgba(212, 175, 55, 0.75), 0 0 3px rgba(255, 244, 189, 0.9)",
              animation: `silkMoteDrift ${p.duration}s ease-in-out infinite`,
              animationDelay: `${p.delay}s`,
              // @ts-expect-error custom css variable
              "--particle-opacity": p.opacity,
              "--drift-x": `${p.driftX}px`,
            }}
          />
        );
      })}
    </div>
  );
}
