"use client";

import React from "react";
import Link from "next/link";

interface BrandLogoProps {
  variant?: "header" | "footer" | "auth" | "mobile";
  className?: string;
  withLink?: boolean;
}

export default function BrandLogo({
  variant = "header",
  className = "",
  withLink = true,
}: BrandLogoProps) {
  const content = (
    <div className={`flex items-center gap-3 group select-none ${className}`}>
      {/* Crisp Logo Image with preserved proportions */}
      <div
        className={`relative flex-shrink-0 overflow-hidden rounded-xl bg-white shadow-sm transition-transform duration-300 group-hover:scale-105 border border-raja-gold/30 ${
          variant === "auth"
            ? "w-20 h-20 sm:w-24 sm:h-24 p-2 shadow-gold-md"
            : variant === "footer"
            ? "w-12 h-12 p-1.5 bg-white/95 border-raja-gold/50 shadow-gold-sm"
            : variant === "mobile"
            ? "w-9 h-9 sm:w-11 sm:h-11 p-1 bg-white border-raja-gold/40 shadow-sm"
            : "w-9 h-9 sm:w-12 sm:h-12 p-1 bg-white border-raja-gold/40 shadow-sm"
        }`}
      >
        <img
          src="/images/logo.png"
          alt="Raja Textile Elampillai Logo"
          className="w-full h-full object-contain object-center"
          loading="eager"
        />
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col text-left min-w-0">
        <span
          className={`font-serif font-bold tracking-[0.10em] sm:tracking-[0.16em] leading-tight transition-colors ${
            variant === "footer"
              ? "text-white text-lg sm:text-2xl group-hover:text-raja-gold"
              : "text-raja-maroon text-base sm:text-2xl group-hover:text-raja-maroon-light"
          }`}
        >
          RAJA TEXTILE
        </span>
        <span
          className={`text-[8px] sm:text-[10px] font-semibold tracking-[0.14em] sm:tracking-[0.28em] uppercase ${
            variant === "footer" ? "text-raja-gold-light" : "text-raja-gold-dark"
          }`}
        >
          <span className="sm:hidden">Elampillai • Salem</span>
          <span className="hidden sm:inline">Elampillai • Salem • Estd. Master Weavers</span>
        </span>
      </div>
    </div>
  );

  if (withLink) {
    return (
      <Link href="/" className="inline-block focus:outline-none" aria-label="Raja Textile Home">
        {content}
      </Link>
    );
  }

  return content;
}
