"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { Search, X, ArrowRight, Tag } from "lucide-react";
import { INITIAL_PRODUCTS, CATEGORIES } from "@/data/products";
import { Product } from "@/types";

export default function SearchModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch("/api/products")
      .then((res) => res.json())
      .then((data) => {
        if (data.products && Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const handleOpen = () => setIsOpen(true);
    window.addEventListener("open-search-modal", handleOpen);

    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setIsOpen((prev) => !prev);
      }
      if (e.key === "Escape") {
        setIsOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("open-search-modal", handleOpen);
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery("");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredProducts: Product[] = query.trim()
    ? products.filter((p) => {
        const q = query.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.fabric.toLowerCase().includes(q) ||
          p.zariType.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
        );
      })
    : [];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Search catalog"
      className="fixed inset-0 z-50 overflow-y-auto bg-raja-wine/40 backdrop-blur-sm p-4 sm:p-6 md:p-20 flex justify-center items-start"
    >
      <div
        className="fixed inset-0"
        onClick={() => setIsOpen(false)}
      />

      <div className="relative bg-white rounded-xl shadow-2xl border border-raja-ink-border w-full max-w-2xl overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200">
        {/* Input Bar */}
        <div className="p-4 sm:p-5 border-b border-raja-ink-border flex items-center gap-3 bg-raja-ivory/40">
          <Search className="w-5 h-5 text-raja-gold flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search soft silks, Karizma weaves, Kolam motifs, bridal drapes..."
            className="flex-1 bg-transparent text-sm sm:text-base text-raja-ink placeholder:text-raja-ink-muted focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="p-1 text-raja-ink-muted hover:text-raja-ink rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setIsOpen(false)}
            className="text-xs bg-raja-ivory px-2.5 py-1.5 rounded text-raja-ink-soft hover:text-raja-maroon border border-raja-ink-border"
          >
            ESC
          </button>
        </div>

        {/* Quick Filter Chips */}
        {!query && (
          <div className="p-5 space-y-4">
            <div>
              <p className="text-xs font-semibold text-raja-ink-muted uppercase tracking-wider mb-2">
                Popular Searches
              </p>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setQuery(cat.name)}
                    className="text-xs px-3 py-1.5 rounded-full bg-raja-ivory hover:bg-raja-maroon-subtle text-raja-ink-soft hover:text-raja-maroon border border-raja-ink-border transition-colors flex items-center gap-1.5"
                  >
                    <Tag className="w-3 h-3 text-raja-gold" />
                    <span>{cat.name}</span>
                  </button>
                ))}
                <button
                  onClick={() => setQuery("Kolam")}
                  className="text-xs px-3 py-1.5 rounded-full bg-raja-ivory hover:bg-raja-maroon-subtle text-raja-ink-soft hover:text-raja-maroon border border-raja-ink-border transition-colors"
                >
                  Kolam Design
                </button>
                <button
                  onClick={() => setQuery("Golden Zari")}
                  className="text-xs px-3 py-1.5 rounded-full bg-raja-ivory hover:bg-raja-maroon-subtle text-raja-ink-soft hover:text-raja-maroon border border-raja-ink-border transition-colors"
                >
                  Golden Zari
                </button>
              </div>
            </div>

            <div className="pt-2">
              <p className="text-xs font-semibold text-raja-ink-muted uppercase tracking-wider mb-3">
                Featured Highlights
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {INITIAL_PRODUCTS.slice(0, 2).map((p) => (
                  <Link
                    key={p.id}
                    href={`/products/${p.slug}`}
                    onClick={() => setIsOpen(false)}
                    className="flex items-center gap-3 p-2.5 rounded-lg border border-raja-ink-border/80 hover:border-raja-gold bg-raja-ivory/30 hover:bg-white transition-all"
                  >
                    <img
                      src={p.images[0]}
                      alt={p.name}
                      className="w-12 h-14 object-cover rounded bg-raja-ivory"
                    />
                    <div className="overflow-hidden">
                      <h4 className="font-serif text-xs font-semibold text-raja-ink truncate">
                        {p.name}
                      </h4>
                      <p className="text-[11px] text-raja-maroon font-bold mt-0.5">
                        ₹{p.price.toLocaleString("en-IN")}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Results List */}
        {query && (
          <div className="max-h-96 overflow-y-auto p-4 space-y-2">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12 space-y-2">
                <p className="font-serif text-base text-raja-ink font-semibold">
                  No sarees found for &ldquo;{query}&rdquo;
                </p>
                <p className="text-xs text-raja-ink-soft">
                  Try searching for &quot;Karizma&quot;, &quot;Kolam&quot;, &quot;Soft Silk&quot;, or &quot;Bridal&quot;.
                </p>
              </div>
            ) : (
              filteredProducts.map((p) => (
                <Link
                  key={p.id}
                  href={`/products/${p.slug}`}
                  onClick={() => setIsOpen(false)}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-raja-ivory border border-transparent hover:border-raja-ink-border transition-all"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={p.images[0]}
                      alt={p.name}
                      className="w-12 h-14 object-cover rounded bg-raja-ivory"
                    />
                    <div>
                      <h4 className="font-serif text-sm font-semibold text-raja-ink">
                        {p.name}
                      </h4>
                      <p className="text-xs text-raja-ink-soft">
                        {p.category} • {p.fabric}
                      </p>
                      <span className="text-xs font-bold text-raja-maroon">
                        ₹{p.price.toLocaleString("en-IN")}{" "}
                        <span className="text-[10px] text-raja-ink-muted line-through font-normal">
                          ₹{p.originalPrice.toLocaleString("en-IN")}
                        </span>
                      </span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-raja-gold" />
                </Link>
              ))
            )}
          </div>
        )}

        {/* Footer info */}
        <div className="p-3 bg-raja-ivory/60 border-t border-raja-ink-border flex items-center justify-between text-[11px] text-raja-ink-muted">
          <span>Elampillai Handloom Weaving Catalog</span>
          <Link
            href="/products"
            onClick={() => setIsOpen(false)}
            className="text-raja-maroon hover:underline font-medium"
          >
            Browse all sarees →
          </Link>
        </div>
      </div>
    </div>
  );
}
