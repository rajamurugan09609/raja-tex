"use client";

import React, { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import QuickViewModal from "@/components/QuickViewModal";
import { Product } from "@/types";

interface FeaturedSareesSectionProps {
  products: Product[];
}

export default function FeaturedSareesSection({ products }: FeaturedSareesSectionProps) {
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  const filterTabs = [
    { id: "all", label: "All Masterpieces" },
    { id: "Sarees", label: "Sarees" },
    { id: "Fabrics", label: "Fabrics & Yardage" },
    { id: "Dress Materials", label: "Dress Materials" },
    { id: "Garments", label: "Men's Dhotis" },
    { id: "Home Textiles", label: "Home Furnishings" },
  ];

  const filteredProducts =
    selectedFilter === "all"
      ? products
      : products.filter(
          (p) => p.department === selectedFilter || p.category === selectedFilter
        );

  return (
    <section className="py-20 md:py-28 bg-raja-ivory border-b border-raja-ink-border relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-raja-gold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Direct Loom Catalog</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-raja-maroon leading-tight">
              Featured Festive Sarees
            </h2>
            <p className="text-sm sm:text-base text-raja-ink-soft mt-2 max-w-xl leading-relaxed">
              Hand-finished with pure metallic zari buttas and lichi-soft textures. Woven for poojas,
              festivals, and grand celebrations.
            </p>
          </div>

          {/* Filter Pills with Framer Motion active pill */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none self-start md:self-auto bg-white/70 p-1.5 rounded-full border border-raja-ink-border/80 shadow-sm">
            {filterTabs.map((tab) => {
              const isActive = selectedFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedFilter(tab.id)}
                  className={`relative px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-colors z-10 ${
                    isActive
                      ? "text-white"
                      : "text-raja-ink-soft hover:text-raja-maroon"
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="filter-pill"
                      className="absolute inset-0 bg-raja-maroon rounded-full -z-10 shadow-sm"
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Product Count & Direct Loom Price Tag */}
        <div className="flex items-center justify-between text-xs text-raja-ink-muted mb-6 px-1">
          <span>
            Displaying <strong className="text-raja-ink">{filteredProducts.length}</strong> master weaves
          </span>
          <span className="hidden sm:inline-block text-emerald-800 font-semibold bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
            ✓ 100% Genuine Elampillai Loom Production
          </span>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={(p) => setQuickViewProduct(p)}
            />
          ))}
        </div>

        {/* Explore Full Catalog Banner */}
        <div className="text-center mt-16 pt-8 border-t border-raja-ink-border/60">
          <Link
            href="/collection"
            className="inline-flex items-center gap-3 px-9 py-4 rounded-xl bg-raja-maroon text-white hover:bg-raja-maroon-light font-bold text-sm shadow-luxury hover:shadow-luxury-hover transition-all duration-300 hover:-translate-y-0.5 group"
          >
            <span>Explore Complete Textile Archive</span>
            <ArrowRight className="w-4 h-4 text-raja-gold group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        isOpen={!!quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />
    </section>
  );
}
