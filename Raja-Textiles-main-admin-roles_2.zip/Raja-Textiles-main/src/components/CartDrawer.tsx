"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  X,
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  MessageCircle,
  Truck,
  Sparkles,
  Tag,
} from "lucide-react";
import { useCart } from "@/context/CartContext";
import { STORE_SETTINGS } from "@/data/products";

export default function CartDrawer() {
  const {
    items,
    removeFromCart,
    updateQuantity,
    totalCount,
    subtotal,
    discount,
    shipping,
    total,
    couponCode,
    applyCoupon,
    removeCoupon,
    isCartOpen,
    setIsCartOpen,
  } = useCart();

  const [inputCoupon, setInputCoupon] = useState("");

  if (!isCartOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCoupon.trim()) return;
    if (applyCoupon(inputCoupon)) {
      setInputCoupon("");
    }
  };

  const amountNeededForFreeShipping = Math.max(0, STORE_SETTINGS.freeShippingThreshold - subtotal);

  const handleWhatsAppCheckout = () => {
    let orderText = `*Vanakkam Raja Textile, I would like to place an order:*\n\n`;
    items.forEach((item, index) => {
      const unitStr = item.product.unit === "meter" ? "m" : "";
      orderText += `${index + 1}. *${item.product.name}*\n   Color: ${item.selectedColor}\n   Qty: ${item.quantity}${unitStr} x ₹${item.product.price} = ₹${item.quantity * item.product.price}\n\n`;
    });
    orderText += `*Subtotal:* ₹${subtotal}\n`;
    if (discount > 0) orderText += `*Discount:* -₹${discount} (${couponCode})\n`;
    orderText += `*Shipping:* ${shipping === 0 ? "FREE" : `₹${shipping}`}\n`;
    orderText += `*Estimated Total:* ₹${total}\n\n`;
    orderText += `Please confirm availability and bank / UPI payment details. Nandri!`;

    window.open(
      `https://wa.me/${STORE_SETTINGS.whatsapp}?text=${encodeURIComponent(orderText)}`,
      "_blank"
    );
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Shopping bag"
      className="fixed inset-0 z-50 overflow-hidden"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-raja-wine/40 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-4 sm:pl-10">
        <div className="w-full max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-raja-ink-border">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-raja-ink-border flex items-center justify-between bg-raja-ivory/50">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-raja-maroon" />
              <h2 className="font-serif text-lg font-bold text-raja-ink">
                Shopping Bag ({totalCount})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1.5 text-raja-ink-muted hover:text-raja-maroon rounded-full hover:bg-white transition-colors"
              aria-label="Close bag"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Alert Bar */}
          <div className="bg-raja-maroon-subtle px-4 py-2.5 text-xs border-b border-raja-maroon/10">
            {amountNeededForFreeShipping > 0 ? (
              <div className="flex items-center gap-2 text-raja-maroon">
                <Truck className="w-4 h-4 flex-shrink-0 text-raja-gold" />
                <span>
                  Add <strong className="font-bold">₹{amountNeededForFreeShipping}</strong> more for{" "}
                  <strong>FREE Pan-India Delivery</strong>
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-emerald-800 font-medium">
                <Sparkles className="w-4 h-4 flex-shrink-0 text-emerald-600" />
                <span>Congratulations! You qualify for <strong>FREE Pan-India Delivery</strong>!</span>
              </div>
            )}
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {items.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-raja-ivory flex items-center justify-center text-raja-gold">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-raja-ink">
                  Your bag is empty
                </h3>
                <p className="text-xs text-raja-ink-soft max-w-xs mx-auto">
                  Discover authentic handloom sarees woven directly at our Elampillai looms.
                </p>
                <Link
                  href="/collection"
                  onClick={() => setIsCartOpen(false)}
                  className="inline-block mt-2 px-6 py-2.5 bg-raja-maroon text-white text-xs font-semibold rounded hover:bg-raja-maroon-light transition-colors"
                >
                  Explore Collections
                </Link>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 p-3 rounded-lg border border-raja-ink-border/80 hover:border-raja-gold/50 bg-white transition-colors"
                >
                  <img
                    src={item.product.images[0] || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"}
                    alt={item.product.name}
                    className="w-20 h-24 object-cover rounded bg-raja-ivory flex-shrink-0"
                  />

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-serif text-sm font-semibold text-raja-ink leading-snug line-clamp-2">
                          {item.product.name}
                        </h4>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.id)}
                          className="text-raja-ink-muted hover:text-red-700 p-1"
                          aria-label={`Remove ${item.product.name} from bag`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[11px] text-raja-ink-soft bg-raja-ivory px-2 py-0.5 rounded border border-raja-ink-border/50">
                          Color: {item.selectedColor}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center border border-raja-ink-border rounded bg-raja-ivory/50">
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-white text-raja-ink transition-colors rounded-l"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2.5 text-xs font-semibold text-raja-ink">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-white text-raja-ink transition-colors rounded-r"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-right">
                        <span className="text-sm font-bold text-raja-maroon">
                          ₹{(item.product.price * item.quantity).toLocaleString("en-IN")}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Area */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-raja-ink-border bg-raja-ivory/40 space-y-4">
              {/* Promo Code Form */}
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-3.5 h-3.5 text-raja-gold absolute left-3 top-3" />
                  <input
                    type="text"
                    value={inputCoupon}
                    onChange={(e) => setInputCoupon(e.target.value)}
                    placeholder="Coupon: FESTIVE10 or WEAVER100"
                    className="w-full text-xs pl-8 pr-3 py-2.5 rounded border border-raja-ink-border bg-white text-raja-ink uppercase tracking-wider focus:outline-none focus:border-raja-maroon"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-raja-ink text-white text-xs font-semibold rounded hover:bg-raja-maroon transition-colors"
                >
                  Apply
                </button>
              </form>

              {couponCode && (
                <div className="flex items-center justify-between text-xs bg-emerald-50 text-emerald-800 p-2 rounded border border-emerald-200">
                  <span>Applied coupon: <strong>{couponCode}</strong></span>
                  <button
                    onClick={removeCoupon}
                    className="text-red-700 hover:underline font-semibold"
                  >
                    Remove
                  </button>
                </div>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-raja-ink-soft">
                <div className="flex justify-between">
                  <span>Bag Subtotal</span>
                  <span className="font-medium text-raja-ink">
                    ₹{subtotal.toLocaleString("en-IN")}
                  </span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Loom Discount</span>
                    <span className="font-medium">-₹{discount.toLocaleString("en-IN")}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Pan-India Delivery</span>
                  <span className="font-medium text-raja-ink">
                    {shipping === 0 ? (
                      <span className="text-emerald-700 font-bold uppercase">Free</span>
                    ) : (
                      `₹${shipping}`
                    )}
                  </span>
                </div>
                <div className="pt-2 border-t border-raja-ink-border flex justify-between text-sm font-bold text-raja-ink">
                  <span>Total Amount</span>
                  <span className="text-base text-raja-maroon">
                    ₹{total.toLocaleString("en-IN")}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <Link
                  href="/checkout"
                  onClick={() => setIsCartOpen(false)}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded bg-raja-maroon hover:bg-raja-maroon-light text-white font-semibold text-sm shadow-md transition-colors"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <button
                  type="button"
                  onClick={handleWhatsAppCheckout}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded bg-[#25D366] hover:bg-[#20ba59] text-white font-semibold text-xs shadow-sm transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Order Directly on WhatsApp</span>
                </button>
              </div>

              <div className="text-center">
                <p className="text-[10px] text-raja-ink-muted">
                  🔒 Safe & Encrypted Cashfree / UPI / Card / COD Available
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
