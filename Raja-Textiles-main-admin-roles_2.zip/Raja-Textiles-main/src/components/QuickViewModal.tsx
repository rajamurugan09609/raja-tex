"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  ShoppingBag,
  MessageCircle,
  ArrowRight,
  Heart,
} from "lucide-react";
import { Product } from "@/types";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { STORE_SETTINGS } from "@/data/products";

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function QuickViewModal({ product, isOpen, onClose }: QuickViewModalProps) {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  useEffect(() => {
    if (product) {
      setSelectedImageIndex(0);
      setSelectedColorIndex(0);
    }
  }, [product]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (isOpen) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "unset";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen || !product) return null;

  const isFavorited = isInWishlist(product.id);
  const images = product.images && product.images.length > 0
    ? product.images
    : ["/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"];
  const selectedImage = images[selectedImageIndex] || images[0];
  const selectedColorName = product.colors?.[selectedColorIndex]?.name || "Standard";

  const handleAddToCart = () => {
    addToCart(product, selectedColorName, 1);
    onClose();
  };

  const handleWhatsApp = () => {
    const msg = encodeURIComponent(
      `Vanakkam Raja Textile, I am interested in viewing this saree on live video / direct order:\n*${product.name}*\nPrice: ₹${product.price} (Loom Direct)\nSelected Color: ${selectedColorName}\nLink: https://rajatextile.in/products/${product.slug}`
    );
    window.open(`https://wa.me/${STORE_SETTINGS.whatsapp}?text=${msg}`, "_blank");
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6 lg:p-8">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 bg-raja-wine/60 backdrop-blur-md"
          onClick={onClose}
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="relative bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden border border-raja-gold/30 z-10 my-8"
        >
          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 hover:bg-white text-raja-ink hover:text-raja-maroon shadow-md transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
            {/* Left: Gallery */}
            <div className="md:col-span-6 p-6 sm:p-8 bg-raja-ivory flex flex-col justify-between">
              <div className="relative aspect-[4/5] rounded-xl overflow-hidden shadow-md bg-white border border-raja-ink-border">
                <img
                  src={selectedImage}
                  alt={product.name}
                  className="w-full h-full object-cover object-center"
                />
                <span className="absolute top-3 left-3 bg-raja-maroon text-white text-[11px] font-bold px-2.5 py-1 rounded shadow-sm uppercase tracking-wider">
                  Save {product.discountPercent}%
                </span>
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pt-4 pb-1 scrollbar-none">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedImageIndex(idx)}
                      className={`w-14 h-16 rounded-md overflow-hidden flex-shrink-0 border-2 transition-all ${
                        selectedImageIndex === idx
                          ? "border-raja-maroon scale-105 shadow-sm"
                          : "border-transparent opacity-70 hover:opacity-100"
                      }`}
                    >
                      <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Right: Product Details & Purchase Actions */}
            <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center justify-between text-xs text-raja-gold-dark font-bold uppercase tracking-wider mb-1">
                  <span>{product.category}</span>
                  <span className="text-raja-ink-muted">
                    ★ {product.rating} ({product.reviewCount} reviews)
                  </span>
                </div>

                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-raja-maroon leading-snug">
                  {product.name}
                </h2>

                {/* Price block */}
                <div className="flex items-baseline gap-3 pt-3">
                  <span className="text-3xl font-bold text-raja-maroon">
                    ₹{product.price.toLocaleString("en-IN")}
                  </span>
                  <span className="text-sm text-raja-ink-muted line-through">
                    ₹{product.originalPrice.toLocaleString("en-IN")}
                  </span>
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Direct Loom Rate
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-raja-ink-soft leading-relaxed mt-4">
                  {product.description}
                </p>

                {/* Weave Specs Quick List */}
                <div className="mt-4 pt-4 border-t border-raja-ink-border grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-raja-ink-muted block text-[10px] uppercase">Fabric</span>
                    <span className="font-semibold text-raja-ink">{product.fabric}</span>
                  </div>
                  <div>
                    <span className="text-raja-ink-muted block text-[10px] uppercase">Length</span>
                    <span className="font-semibold text-raja-ink">6.25m with Blouse</span>
                  </div>
                  <div>
                    <span className="text-raja-ink-muted block text-[10px] uppercase">Zari</span>
                    <span className="font-semibold text-raja-ink">{product.zariType}</span>
                  </div>
                  <div>
                    <span className="text-raja-ink-muted block text-[10px] uppercase">Origin</span>
                    <span className="font-semibold text-raja-ink">Elampillai, Salem</span>
                  </div>
                </div>

                {/* Color Variants */}
                {product.colors && product.colors.length > 0 && (
                  <div className="mt-5">
                    <span className="text-xs font-semibold text-raja-ink block mb-2">
                      Available Color: <strong className="text-raja-maroon">{selectedColorName}</strong>
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {product.colors.map((color, idx) => (
                        <button
                          key={color.name}
                          type="button"
                          onClick={() => {
                            setSelectedColorIndex(idx);
                            if (color.imageIndex !== undefined && images[color.imageIndex]) {
                              setSelectedImageIndex(color.imageIndex);
                            }
                          }}
                          className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs transition-all ${
                            selectedColorIndex === idx
                              ? "border-raja-maroon bg-raja-maroon-subtle text-raja-maroon font-bold ring-1 ring-raja-maroon"
                              : "border-raja-ink-border hover:border-raja-gold text-raja-ink"
                          }`}
                        >
                          <span
                            className="w-3 h-3 rounded-full border border-black/10"
                            style={{ backgroundColor: color.hex }}
                          />
                          <span>{color.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5 pt-4 border-t border-raja-ink-border">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleAddToCart}
                    className="flex-1 bg-raja-maroon hover:bg-raja-maroon-light text-white font-semibold py-3 px-4 rounded-lg flex items-center justify-center gap-2 shadow-md transition-all"
                  >
                    <ShoppingBag className="w-4 h-4 text-raja-gold" />
                    <span>Add to Bag</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleWishlist(product)}
                    className={`p-3 rounded-lg border transition-all ${
                      isFavorited
                        ? "bg-raja-maroon text-white border-raja-maroon"
                        : "border-raja-ink-border text-raja-ink hover:text-raja-maroon hover:border-raja-gold"
                    }`}
                    aria-label="Wishlist toggle"
                  >
                    <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleWhatsApp}
                  className="w-full bg-[#25D366] hover:bg-[#20ba59] text-white font-semibold py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 text-xs shadow-sm transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Request Live Video Inspection on WhatsApp</span>
                </button>

                <div className="text-center pt-1">
                  <Link
                    href={`/products/${product.slug}`}
                    onClick={onClose}
                    className="text-xs text-raja-maroon hover:underline font-semibold inline-flex items-center gap-1"
                  >
                    <span>View Full Saree Specifications Page</span>
                    <ArrowRight className="w-3 h-3" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
