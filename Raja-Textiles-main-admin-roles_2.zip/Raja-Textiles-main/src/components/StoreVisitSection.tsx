"use client";

import React from "react";
import {
  MapPin,
  Clock,
  Phone,
  MessageCircle,
  Video,
  Navigation,
  Sparkles,
} from "lucide-react";
import { STORE_SETTINGS } from "@/data/products";

export default function StoreVisitSection() {
  return (
    <section className="py-20 md:py-28 bg-white border-b border-raja-ink-border relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-raja-gold/10 rounded-full blur-3xl pointer-events-none -ml-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-raja-wine to-[#28050C] text-white rounded-3xl p-8 sm:p-12 lg:p-16 shadow-2xl border border-raja-gold/30 relative overflow-hidden">
          {/* Subtle gold grid pattern */}
          <div className="absolute inset-0 opacity-5 bg-[radial-gradient(#C49436_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center relative z-10">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-raja-gold/20 text-raja-gold text-xs font-bold uppercase tracking-widest border border-raja-gold/40">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Visit Us in Salem, Tamil Nadu</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold leading-tight">
                Experience Handloom Silks
                <br />
                <span className="text-raja-gold italic font-normal">at Our Flagship Loom Store</span>
              </h2>

              <p className="text-sm sm:text-base text-raja-ivory/85 leading-relaxed max-w-xl">
                Planning a trip to Salem or nearby districts? Visit our Elampillai showroom to feel the
                textures, drape new festive arrivals, and order customized wedding drapes directly from
                master weavers.
              </p>

              {/* Verified Details Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
                <div className="flex items-start gap-3.5 bg-white/5 p-4 rounded-xl border border-white/10">
                  <MapPin className="w-5 h-5 text-raja-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-serif text-sm font-bold text-white">Showroom Address</h4>
                    <address className="not-italic text-xs text-raja-ivory/80 mt-1 leading-relaxed">
                      {STORE_SETTINGS.address},
                      <br />
                      {STORE_SETTINGS.city} — {STORE_SETTINGS.pincode}, Tamil Nadu
                    </address>
                  </div>
                </div>

                <div className="flex items-start gap-3.5 bg-white/5 p-4 rounded-xl border border-white/10">
                  <Clock className="w-5 h-5 text-raja-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-serif text-sm font-bold text-white">Showroom Hours</h4>
                    <p className="text-xs text-raja-ivory/80 mt-1">
                      {STORE_SETTINGS.operatingHours}
                    </p>
                    <span className="inline-block mt-1 text-[11px] font-bold text-emerald-400">
                      Open on Sundays & Holidays
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Action Panel */}
            <div className="lg:col-span-5 bg-white/10 backdrop-blur-md p-6 sm:p-8 rounded-2xl border border-raja-gold/30 space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-white/10">
                <div className="w-10 h-10 rounded-full bg-raja-gold text-raja-wine flex items-center justify-center font-bold">
                  <Video className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif text-base font-bold text-white">
                    Live Video Call Consultation
                  </h4>
                  <p className="text-xs text-raja-ivory/70">
                    Inspect color, shine & pleats before buying
                  </p>
                </div>
              </div>

              <p className="text-xs text-raja-ivory/80 leading-relaxed">
                Cannot visit Salem in person? Our master weaver will hold a live WhatsApp video call
                with you to showcase colors in natural lighting.
              </p>

              <div className="space-y-3 pt-2">
                <a
                  href={`https://wa.me/${STORE_SETTINGS.whatsapp}?text=Vanakkam%20Raja%20Textile,%20I%20would%20like%20to%20book%20a%20WhatsApp%20video%20call%20to%20inspect%20sarees.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-5 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-sm shadow-md transition-all hover:scale-[1.02]"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Start WhatsApp Video Call</span>
                </a>

                <a
                  href={`tel:${STORE_SETTINGS.phone.replace(/[^0-9+]/g, "")}`}
                  className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-white hover:bg-raja-ivory text-raja-wine font-bold text-xs shadow-md transition-all"
                >
                  <Phone className="w-4 h-4 text-raja-maroon" />
                  <span>Call Store: {STORE_SETTINGS.phone}</span>
                </a>

                <a
                  href="https://maps.google.com/?q=Elampillai,+Salem,+Tamil+Nadu"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 text-xs text-raja-gold hover:text-white font-semibold transition-colors"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Get Driving Directions on Google Maps →</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
