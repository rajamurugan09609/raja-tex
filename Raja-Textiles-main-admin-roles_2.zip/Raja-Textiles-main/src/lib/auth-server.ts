import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin, isSupabaseConfigured } from "./supabase";
import { getAdminByEmail } from "./db";
import type { AdminRole } from "@/types";

/**
 * ROLES
 *  - main_admin : everything (orders, settings, hero, products, admin team)
 *  - admin      : "Normal Admin" -> ONLY adds new products
 *
 * Emails in OWNER_EMAILS (.env) are always main_admin.
 * Extra admins live in the `admins` table (see supabase/admin_roles.sql).
 *
 * To change what Normal Admin can do, edit ROLE_PERMISSIONS below. Nothing else.
 */
export type Permission =
  | "product:create"
  | "product:update"
  | "product:delete"
  | "orders:read"
  | "orders:update"
  | "settings:update"
  | "hero:manage"
  | "admins:manage";

export const ALL_PERMISSIONS: Permission[] = [
  "product:create",
  "product:update",
  "product:delete",
  "orders:read",
  "orders:update",
  "settings:update",
  "hero:manage",
  "admins:manage",
];

export const ROLE_PERMISSIONS: Record<AdminRole, Permission[]> = {
  main_admin: ALL_PERMISSIONS,
  admin: ["product:create"],
};

export function getOwnerEmails(): string[] {
  const envEmails = process.env.OWNER_EMAILS || process.env.OWNER_EMAIL || "sriharibshk@gmail.com";
  return envEmails
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

export function isOwnerEmail(email?: string | null): boolean {
  if (!email) return false;
  return getOwnerEmails().includes(email.trim().toLowerCase());
}

export interface AdminAuth {
  email: string;
  userId: string;
  role: AdminRole;
  permissions: Permission[];
}

export interface AdminAuthResult {
  authorized: boolean;
  status: 200 | 401 | 403;
  auth?: AdminAuth;
  error?: string;
}

/** Verify the Supabase session token and work out which role (if any) the user has. */
export async function verifyAdminRequest(req: NextRequest): Promise<AdminAuthResult> {
  const authHeader = req.headers.get("authorization");
  let token = "";
  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.substring(7).trim();
  } else {
    token = req.cookies.get("sb-access-token")?.value || "";
  }

  if (!token) {
    return { authorized: false, status: 401, error: "Please sign in to continue." };
  }
  if (!isSupabaseConfigured || !supabaseAdmin) {
    return { authorized: false, status: 401, error: "Authentication is not configured on the server." };
  }

  try {
    const {
      data: { user },
      error,
    } = await supabaseAdmin.auth.getUser(token);

    if (error || !user || !user.email) {
      return { authorized: false, status: 401, error: "Session expired. Please sign in again." };
    }

    let role: AdminRole | null = null;
    if (isOwnerEmail(user.email)) {
      role = "main_admin";
    } else {
      const record = await getAdminByEmail(user.email);
      if (record) role = record.role;
    }

    if (!role) {
      return { authorized: false, status: 403, error: "This account is not an admin." };
    }

    return {
      authorized: true,
      status: 200,
      auth: {
        email: user.email.toLowerCase(),
        userId: user.id,
        role,
        permissions: ROLE_PERMISSIONS[role],
      },
    };
  } catch (err: any) {
    return { authorized: false, status: 401, error: err?.message || "Failed to verify session" };
  }
}

export function hasPermission(auth: AdminAuth, permission: Permission): boolean {
  return auth.permissions.includes(permission);
}

type Guard = { ok: true; auth: AdminAuth } | { ok: false; response: NextResponse };

/**
 * Use at the top of every admin API route:
 *   const g = await requirePermission(req, "orders:read");
 *   if (!g.ok) return g.response;
 */
export async function requirePermission(req: NextRequest, permission?: Permission): Promise<Guard> {
  const result = await verifyAdminRequest(req);
  if (!result.authorized || !result.auth) {
    return {
      ok: false,
      response: NextResponse.json({ error: result.error || "Unauthorized" }, { status: result.status }),
    };
  }
  if (permission && !hasPermission(result.auth, permission)) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "You do not have permission to do this. Only the Main Admin can." },
        { status: 403 }
      ),
    };
  }
  return { ok: true, auth: result.auth };
}
