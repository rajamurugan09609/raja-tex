import { createClient } from "@supabase/supabase-js";

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL ||
  "https://fbejdxujhxjcmmgsrqeh.supabase.co";

const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "sb_publishable_N1aPdp7s3a6KL8Ab3VrraQ_5PJtfElR";

const supabaseServiceKey =
  process.env.SUPABASE_SECRET_KEY ||
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  "";



export const hasServiceRoleKey = Boolean(supabaseServiceKey);

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
    supabaseUrl.startsWith("http") &&
    supabaseAnonKey &&
    !supabaseUrl.includes("your_supabase_url_here")
);

// Client-safe instance with no-store cache to avoid Next.js caching PostgREST data
export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: { persistSession: true },
      global: {
        fetch: (url, options = {}) =>
          fetch(url, { ...options, cache: "no-store" }),
      },
    })
  : null;

// Server-side service-role instance for verified writes
export const supabaseAdmin =
  isSupabaseConfigured && supabaseServiceKey
    ? createClient(supabaseUrl, supabaseServiceKey, {
        auth: { autoRefreshToken: false, persistSession: false },
        global: {
          fetch: (url, options = {}) =>
            fetch(url, { ...options, cache: "no-store" }),
        },
      })
    : supabase;
