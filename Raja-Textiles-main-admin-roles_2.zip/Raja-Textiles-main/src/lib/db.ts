import { Product, Category, Order, StoreSettings, HeroSlide, AdminUser, AdminRole } from "@/types";
import { INITIAL_PRODUCTS, CATEGORIES, STORE_SETTINGS, INITIAL_HERO_SLIDES } from "@/data/products";
import { supabase, supabaseAdmin, isSupabaseConfigured, hasServiceRoleKey } from "./supabase";

// In-memory runtime cache for seamless operation
let localProducts: Product[] = [...INITIAL_PRODUCTS];
const localOrders: Order[] = [];
let localSettings: StoreSettings = { ...STORE_SETTINGS };
let localHeroSlides: HeroSlide[] = [...INITIAL_HERO_SLIDES];

export async function getProducts(): Promise<Product[]> {
  const client = supabaseAdmin || supabase;
  if (isSupabaseConfigured && client) {
    try {
      const { data, error } = await client
        .from("products")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Supabase getProducts error:", error.message);
      }

      if (!error && data && data.length > 0) {
        return data.map((item: any) => ({
          id: item.id,
          slug: item.slug,
          name: item.name,
          category: item.category,
          department: item.department || "Sarees",
          section: item.section || "Women",
          price: Number(item.price),
          originalPrice: Number(item.originalPrice ?? item.original_price ?? item.price * 2.5),
          discountPercent: Number(item.discountPercent ?? item.discount_percent ?? 50),
          unit: item.unit || "piece",
          description: item.description || "",
          fabric: item.fabric || "Soft Silk",
          sareeLength: item.sareeLength ?? item.saree_length ?? "6.25 meters",
          zariType: item.zariType ?? item.zari_type ?? "Golden Zari",
          pallu: item.pallu || "Rich Contrast Woven Pallu",
          weight: item.weight || "600 grams",
          care: Array.isArray(item.care) ? item.care : [],
          images: Array.isArray(item.images) ? item.images : [],
          colors: Array.isArray(item.colors) ? item.colors : [],
          inStock: Boolean(item.inStock ?? item.in_stock ?? true),
          stockCount: Number(item.stockCount ?? item.stock_count ?? 15),
          isFeatured: Boolean(item.isFeatured ?? item.is_featured ?? false),
          isBestSeller: Boolean(item.isBestSeller ?? item.is_best_seller ?? false),
          rating: Number(item.rating || 5.0),
          reviewCount: Number(item.reviewCount ?? item.review_count ?? 0),
          createdAt: item.createdAt ?? item.created_at ?? new Date().toISOString(),
        })) as Product[];
      }
    } catch (err: any) {
      console.error("Supabase getProducts exception:", err?.message);
    }
  }
  return localProducts;
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const products = await getProducts();
  return products.find((p) => p.slug === slug || p.id === slug) || null;
}

export async function getProductById(id: string): Promise<Product | null> {
  const products = await getProducts();
  return products.find((p) => p.id === id) || null;
}

export async function saveProduct(product: Partial<Product> & { name: string; price: number }): Promise<Product> {
  const id = product.id || `prod-${Date.now()}`;
  const slug =
    product.slug ||
    product.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");

  const fullProduct: Product = {
    id,
    slug,
    name: product.name,
    category: product.category || "Soft Silk",
    department: product.department || "Sarees",
    section: product.section || "Women",
    price: Number(product.price),
    originalPrice: Number(product.originalPrice || product.price * 2.5),
    discountPercent:
      product.originalPrice && product.originalPrice > product.price
        ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
        : 50,
    unit: product.unit || "piece",
    description: product.description || "Authentic textile direct from Elampillai, Salem weavers.",
    fabric: product.fabric || "Soft Silk",
    sareeLength: product.sareeLength || "6.25 meters (includes 0.8m blouse piece)",
    zariType: product.zariType || "Golden Zari",
    pallu: product.pallu || "Rich Contrast Woven Pallu",
    weight: product.weight || "600 grams",
    care: product.care || [
      "Dry clean recommended for first wash",
      "Gentle cold wash thereafter",
      "Iron on reverse side",
    ],
    images: product.images && product.images.length > 0 ? product.images : ["/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg"],
    colors: product.colors || [{ name: "Standard", hex: "#681329", inStock: true }],
    inStock: product.inStock ?? true,
    stockCount: Number(product.stockCount ?? 15),
    isFeatured: Boolean(product.isFeatured),
    isBestSeller: Boolean(product.isBestSeller),
    rating: product.rating || 5.0,
    reviewCount: product.reviewCount || 1,
    createdAt: product.createdAt || new Date().toISOString(),
  };

  const client = supabaseAdmin || supabase;
  if (isSupabaseConfigured && client) {
    try {
      const dbPayload = {
        id: fullProduct.id,
        slug: fullProduct.slug,
        name: fullProduct.name,
        category: fullProduct.category,
        department: fullProduct.department || "Sarees",
        section: fullProduct.section || "Women",
        price: fullProduct.price,
        original_price: fullProduct.originalPrice,
        discount_percent: fullProduct.discountPercent,
        unit: fullProduct.unit || "piece",
        description: fullProduct.description,
        fabric: fullProduct.fabric,
        saree_length: fullProduct.sareeLength,
        zari_type: fullProduct.zariType,
        pallu: fullProduct.pallu,
        weight: fullProduct.weight,
        care: fullProduct.care,
        images: fullProduct.images,
        colors: fullProduct.colors,
        in_stock: fullProduct.inStock,
        stock_count: fullProduct.stockCount,
        is_featured: fullProduct.isFeatured,
        is_best_seller: fullProduct.isBestSeller,
        rating: fullProduct.rating,
        review_count: fullProduct.reviewCount,
        created_at: fullProduct.createdAt,
        updated_at: new Date().toISOString(),
      };
      const { error } = await client.from("products").upsert(dbPayload);
      if (error) {
        console.error("Supabase product upsert error:", error.message);
      } else {
        const existingIndex = localProducts.findIndex((p) => p.id === id);
        if (existingIndex >= 0) {
          localProducts[existingIndex] = fullProduct;
        } else {
          localProducts.unshift(fullProduct);
        }
        return fullProduct;
      }
    } catch (err: any) {
      console.error("Supabase product upsert exception:", err?.message);
    }
  }

  const existingIndex = localProducts.findIndex((p) => p.id === id);
  if (existingIndex >= 0) {
    localProducts[existingIndex] = fullProduct;
  } else {
    localProducts.unshift(fullProduct);
  }
  return fullProduct;
}

export async function deleteProduct(id: string): Promise<boolean> {
  const client = supabaseAdmin || supabase;
  if (isSupabaseConfigured && client) {
    try {
      const { error } = await client.from("products").delete().eq("id", id);
      if (error) {
        console.error("Supabase product delete error:", error.message);
        throw new Error(error.message);
      }
    } catch (err: any) {
      console.error("Supabase product delete exception:", err?.message);
      throw err;
    }
  }
  localProducts = localProducts.filter((p) => p.id !== id);
  localHeroSlides = localHeroSlides.filter((s) => s.productId !== id);
  return true;
}

export async function getCategories(): Promise<Category[]> {
  return CATEGORIES;
}

export async function getStoreSettings(): Promise<StoreSettings> {
  if (isSupabaseConfigured && supabaseAdmin) {
    try {
      const { data, error } = await supabaseAdmin
        .from("store_settings")
        .select("*")
        .eq("id", "default")
        .single();
      if (!error && data) {
        return {
          storeName: data.store_name ?? localSettings.storeName,
          tagline: data.tagline ?? localSettings.tagline,
          phone: data.phone ?? localSettings.phone,
          whatsapp: data.whatsapp ?? localSettings.whatsapp,
          email: data.email ?? localSettings.email,
          address: data.address ?? localSettings.address,
          city: data.city ?? localSettings.city,
          state: data.state ?? localSettings.state,
          pincode: data.pincode ?? localSettings.pincode,
          operatingHours: data.operating_hours ?? localSettings.operatingHours,
          announcementText: data.announcement_text ?? localSettings.announcementText,
          freeShippingThreshold: data.free_shipping_threshold ?? localSettings.freeShippingThreshold,
          shippingFee: data.shipping_fee ?? localSettings.shippingFee,
        };
      }
    } catch {
      // fallback
    }
  }
  return localSettings;
}

export async function updateStoreSettings(updates: Partial<StoreSettings>): Promise<StoreSettings> {
  localSettings = { ...localSettings, ...updates };
  if (isSupabaseConfigured && supabaseAdmin) {
    try {
      const payload: any = {
        id: "default",
        updated_at: new Date().toISOString(),
      };
      if (updates.storeName !== undefined) payload.store_name = updates.storeName;
      if (updates.tagline !== undefined) payload.tagline = updates.tagline;
      if (updates.phone !== undefined) payload.phone = updates.phone;
      if (updates.whatsapp !== undefined) payload.whatsapp = updates.whatsapp;
      if (updates.email !== undefined) payload.email = updates.email;
      if (updates.address !== undefined) payload.address = updates.address;
      if (updates.city !== undefined) payload.city = updates.city;
      if (updates.state !== undefined) payload.state = updates.state;
      if (updates.pincode !== undefined) payload.pincode = updates.pincode;
      if (updates.operatingHours !== undefined) payload.operating_hours = updates.operatingHours;
      if (updates.announcementText !== undefined) payload.announcement_text = updates.announcementText;
      if (updates.freeShippingThreshold !== undefined) payload.free_shipping_threshold = updates.freeShippingThreshold;
      if (updates.shippingFee !== undefined) payload.shipping_fee = updates.shippingFee;

      await supabaseAdmin.from("store_settings").upsert(payload);
    } catch {
      // fallback
    }
  }
  return localSettings;
}

export async function getOrders(): Promise<Order[]> {
  if (isSupabaseConfigured && supabaseAdmin) {
    try {
      const { data, error } = await supabaseAdmin
        .from("orders")
        .select("*");

      if (!error && data && data.length > 0) {
        return data.map((ord: any) => ({
          id: ord.id,
          orderNumber: ord.orderNumber ?? ord.order_number,
          customer: ord.customer,
          items: ord.items,
          pricing: ord.pricing,
          paymentMethod: ord.paymentMethod ?? ord.payment_method,
          paymentStatus: ord.paymentStatus ?? ord.payment_status,
          orderStatus: ord.orderStatus ?? ord.order_status,
          paymentReferenceId: ord.paymentReferenceId ?? ord.payment_reference_id,
          trackingNumber: ord.trackingNumber ?? ord.tracking_number,
          notes: ord.notes,
          createdAt: ord.createdAt ?? ord.created_at ?? new Date().toISOString(),
          updatedAt: ord.updatedAt ?? ord.updated_at ?? new Date().toISOString(),
        })) as Order[];
      }
    } catch {
      // fallback
    }
  }
  return localOrders;
}

export async function getOrderById(id: string): Promise<Order | null> {
  const orders = await getOrders();
  return orders.find((o) => o.id === id || o.orderNumber === id) || null;
}

export async function saveOrder(order: Order): Promise<Order> {
  if (isSupabaseConfigured && supabaseAdmin) {
    try {
      const dbOrder = {
        ...order,
        order_number: order.orderNumber,
        payment_method: order.paymentMethod,
        payment_status: order.paymentStatus,
        order_status: order.orderStatus,
        payment_reference_id: order.paymentReferenceId,
        tracking_number: order.trackingNumber,
        created_at: order.createdAt,
        updated_at: order.updatedAt,
      };
      const { error } = await supabaseAdmin.from("orders").upsert(dbOrder);
      if (!error) {
        return order;
      }
    } catch {
      // fallback
    }
  }

  const existing = localOrders.findIndex((o) => o.id === order.id);
  if (existing >= 0) {
    localOrders[existing] = order;
  } else {
    localOrders.unshift(order);
  }
  return order;
}

export async function updateOrderStatus(
  orderId: string,
  orderStatus: Order["orderStatus"],
  paymentStatus?: Order["paymentStatus"],
  trackingNumber?: string
): Promise<Order | null> {
  const order = await getOrderById(orderId);
  if (!order) return null;

  order.orderStatus = orderStatus;
  if (paymentStatus) order.paymentStatus = paymentStatus;
  if (trackingNumber) order.trackingNumber = trackingNumber;
  order.updatedAt = new Date().toISOString();

  return await saveOrder(order);
}

export async function getHeroSlides(): Promise<HeroSlide[]> {
  try {
    const products = await getProducts();
    const featuredProductIds = new Set(
      products.filter((p) => p.isFeatured && p.inStock).map((p) => p.id)
    );
    // Sync auto-slides with current featured status
    for (const prod of products) {
      const isFeatured = featuredProductIds.has(prod.id);
      const existingIdx = localHeroSlides.findIndex((s) => s.productId === prod.id);

      if (isFeatured && existingIdx === -1) {
        localHeroSlides.push({
          id: `slide-auto-${prod.id}`,
          type: "product",
          title: prod.name,
          subtitle: prod.description ? prod.description.substring(0, 95) + "..." : "Master weave crafted in Elampillai.",
          badge: "Featured Masterpiece",
          tamilTitle: prod.category,
          imageUrl: prod.images[0] || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
          linkUrl: `/products/${prod.slug || prod.id}`,
          price: prod.price,
          originalPrice: prod.originalPrice,
          discountBadge: prod.discountPercent ? `${prod.discountPercent}% OFF` : undefined,
          buttonText: "View Saree",
          order: localHeroSlides.length + 1,
          isActive: true,
          productId: prod.id,
        });
      } else if (!isFeatured && existingIdx !== -1 && localHeroSlides[existingIdx].id.startsWith("slide-auto-")) {
        localHeroSlides.splice(existingIdx, 1);
      }
    }
  } catch (err: any) {
    console.error("getHeroSlides exception:", err?.message);
  }

  return [...localHeroSlides].sort((a, b) => a.order - b.order);
}

export async function saveHeroSlide(slide: Partial<HeroSlide>): Promise<HeroSlide> {
  const id = slide.id || `slide-${Date.now()}`;
  const fullSlide: HeroSlide = {
    id,
    type: slide.type || "advertisement",
    title: slide.title || "Special Collection",
    subtitle: slide.subtitle || "",
    badge: slide.badge || "Featured",
    tamilTitle: slide.tamilTitle || "",
    imageUrl: slide.imageUrl || "/images/products/a9e7e014a02350ebdba9d2fe0e2bb42b.jpg",
    linkUrl: slide.linkUrl || "/collection",
    price: slide.price,
    originalPrice: slide.originalPrice,
    discountBadge: slide.discountBadge,
    buttonText: slide.buttonText || (slide.type === "product" ? "View Saree" : "Explore Offer"),
    order: slide.order ?? (localHeroSlides.length + 1),
    isActive: slide.isActive ?? true,
    productId: slide.productId,
  };

  const existingIdx = localHeroSlides.findIndex((s) => s.id === id);
  if (existingIdx >= 0) {
    localHeroSlides[existingIdx] = fullSlide;
  } else {
    localHeroSlides.push(fullSlide);
  }
  return fullSlide;
}

export async function updateHeroSlidesOrder(orderedIds: string[]): Promise<HeroSlide[]> {
  localHeroSlides = localHeroSlides.map((slide) => {
    const newOrder = orderedIds.indexOf(slide.id);
    if (newOrder !== -1) {
      return { ...slide, order: newOrder + 1 };
    }
    return slide;
  });
  return [...localHeroSlides].sort((a, b) => a.order - b.order);
}

export async function deleteHeroSlide(id: string): Promise<boolean> {
  localHeroSlides = localHeroSlides.filter((s) => s.id !== id);
  return true;
}


// =========================================================================
// ADMIN TEAM (Main Admin / Normal Admin)  — server-side only
// =========================================================================
function mapAdminRow(row: any): AdminUser {
  return {
    id: row.id,
    userId: row.user_id ?? null,
    email: String(row.email).toLowerCase(),
    fullName: row.full_name || "",
    role: row.role === "main_admin" ? "main_admin" : "admin",
    createdBy: row.created_by ?? null,
    createdAt: row.created_at || new Date().toISOString(),
  };
}

export async function getAdmins(): Promise<AdminUser[]> {
  if (!isSupabaseConfigured || !supabaseAdmin || !hasServiceRoleKey) return [];
  const { data, error } = await supabaseAdmin
    .from("admins")
    .select("*")
    .order("created_at", { ascending: true });
  if (error) {
    console.error("getAdmins error:", error.message);
    throw new Error(
      error.message.includes("admins")
        ? "The 'admins' table is missing. Run supabase/admin_roles.sql in the Supabase SQL Editor."
        : error.message
    );
  }
  return (data || []).map(mapAdminRow);
}

/** Used on every admin request. Never throws: a DB problem = "not an extra admin". */
export async function getAdminByEmail(email: string): Promise<AdminUser | null> {
  if (!isSupabaseConfigured || !supabaseAdmin || !hasServiceRoleKey) return null;
  try {
    const { data, error } = await supabaseAdmin
      .from("admins")
      .select("*")
      .ilike("email", email.trim())
      .maybeSingle();
    if (error || !data) return null;
    return mapAdminRow(data);
  } catch {
    return null;
  }
}

export async function saveAdmin(input: {
  userId: string;
  email: string;
  fullName: string;
  role: AdminRole;
  createdBy: string;
}): Promise<AdminUser> {
  if (!supabaseAdmin || !hasServiceRoleKey) {
    throw new Error("SUPABASE_SECRET_KEY is not configured on the server.");
  }
  const { data, error } = await supabaseAdmin
    .from("admins")
    .upsert(
      {
        user_id: input.userId,
        email: input.email.trim().toLowerCase(),
        full_name: input.fullName,
        role: input.role,
        created_by: input.createdBy,
      },
      { onConflict: "email" }
    )
    .select("*")
    .single();
  if (error) throw new Error(error.message);
  return mapAdminRow(data);
}

export async function deleteAdminByEmail(email: string): Promise<boolean> {
  if (!supabaseAdmin || !hasServiceRoleKey) {
    throw new Error("SUPABASE_SECRET_KEY is not configured on the server.");
  }
  const { error } = await supabaseAdmin.from("admins").delete().ilike("email", email.trim());
  if (error) throw new Error(error.message);
  return true;
}
