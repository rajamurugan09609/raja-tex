export interface ColorVariant {
  name: string;
  hex: string;
  inStock: boolean;
  imageIndex?: number;
}

export type TextileDepartment =
  | "Sarees"
  | "Fabrics"
  | "Dress Materials"
  | "Garments"
  | "Home Textiles";

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: string;
  department: TextileDepartment;
  section: "Women" | "Men" | "Festive" | "Bridal" | "Traditional" | "Fabrics" | "Home";
  price: number;
  originalPrice: number;
  discountPercent: number;
  description: string;
  fabric: string;
  sareeLength: string; // or dimensions / cut length
  unit?: string; // "piece", "meter", "set"
  zariType: string;
  pallu: string;
  weight: string;
  care: string[];
  images: string[];
  colors: ColorVariant[];
  inStock: boolean;
  stockCount: number;
  isFeatured: boolean;
  isBestSeller: boolean;
  rating: number;
  reviewCount: number;
  createdAt: string;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  department: TextileDepartment;
  tamilName?: string;
  tagline: string;
  description: string;
  image: string;
  itemCount: number;
}

export interface CartItem {
  id: string; // unique item id: productId-color
  productId: string;
  product: Product;
  selectedColor: string;
  quantity: number;
}

export interface Address {
  id: string;
  label: "Home" | "Work" | "Other";
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
  isDefault?: boolean;
}

export interface CustomerProfile {
  id: string; // Supabase user id
  email: string;
  fullName: string;
  phone?: string;
  addresses: Address[];
  role?: "customer" | "owner";
  createdAt: string;
}

export interface CustomerDetails {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
}

export interface OrderPricing {
  subtotal: number;
  discount: number;
  couponCode?: string;
  shipping: number;
  tax: number;
  total: number;
}

export interface OrderItem {
  productId: string;
  name: string;
  image: string;
  price: number;
  quantity: number;
  selectedColor: string;
  subtotal: number;
  unit?: string;
}

export type PaymentMethod = "cashfree" | "whatsapp" | "cod" | "upi";
export type PaymentStatus = "pending" | "verified" | "failed" | "refunded";
export type OrderStatus =
  | "placed"
  | "confirmed"
  | "processing"
  | "shipped"
  | "delivered"
  | "cancelled";

export interface Order {
  id: string;
  orderNumber: string;
  userId?: string;
  customer: CustomerDetails;
  items: OrderItem[];
  pricing: OrderPricing;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  paymentReferenceId?: string;
  trackingNumber?: string;
  courierName?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface HeroSlide {
  id: string;
  type: "product" | "advertisement";
  title: string;
  subtitle?: string;
  badge?: string;
  tamilTitle?: string;
  imageUrl: string;
  linkUrl: string;
  price?: number;
  originalPrice?: number;
  discountBadge?: string;
  buttonText?: string;
  order: number;
  isActive: boolean;
  productId?: string;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  operatingHours: string;
  announcementText: string;
  freeShippingThreshold: number;
  shippingFee: number;
  developerUrl?: string;
}


// ---------- Admin roles ----------
export type AdminRole = "main_admin" | "admin";

export interface AdminUser {
  id: string;
  userId?: string | null;
  email: string;
  fullName: string;
  role: AdminRole;
  createdBy?: string | null;
  createdAt: string;
  /** true for emails configured in OWNER_EMAILS (cannot be removed from the UI) */
  isEnvOwner?: boolean;
}
