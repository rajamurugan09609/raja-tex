"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { CartItem, Product } from "@/types";
import { useToast } from "./ToastContext";

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, selectedColor?: string, quantity?: number) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  totalCount: number;
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  couponCode: string;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = "raja_textile_cart_v1";
const COUPON_STORAGE_KEY = "raja_textile_coupon_v1";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [couponCode, setCouponCode] = useState<string>("");
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const { showToast } = useToast();

  // Load from local storage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        setItems(JSON.parse(stored));
      }
      const storedCoupon = localStorage.getItem(COUPON_STORAGE_KEY);
      if (storedCoupon) {
        setCouponCode(storedCoupon);
      }
    } catch {
      // ignore
    } finally {
      setIsLoaded(true);
    }
  }, []);

  // Save to local storage
  useEffect(() => {
    if (!isLoaded) return;
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch {
      // ignore
    }
  }, [items, isLoaded]);

  const addToCart = (product: Product, selectedColor?: string, quantity: number = 1) => {
    const color = selectedColor || product.colors?.[0]?.name || "Standard";
    const itemId = `${product.id}-${color}`;

    setItems((prev) => {
      const existing = prev.find((item) => item.id === itemId);
      if (existing) {
        return prev.map((item) =>
          item.id === itemId ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { id: itemId, productId: product.id, product, selectedColor: color, quantity }];
    });

    showToast(`Added "${product.name}" (${color}) to your shopping bag.`);
    setIsCartOpen(true);
  };

  const removeFromCart = (itemId: string) => {
    setItems((prev) => prev.filter((item) => item.id !== itemId));
    showToast("Item removed from your bag.", "info");
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    setItems((prev) =>
      prev.map((item) => (item.id === itemId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setItems([]);
    setCouponCode("");
    try {
      localStorage.removeItem(CART_STORAGE_KEY);
      localStorage.removeItem(COUPON_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  // Discount calculation
  let discount = 0;
  if (couponCode.toUpperCase() === "FESTIVE10") {
    discount = Math.round(subtotal * 0.1);
  } else if (couponCode.toUpperCase() === "WEAVER100" && subtotal >= 600) {
    discount = 100;
  } else if (couponCode.toUpperCase() === "DIWALI50" && subtotal >= 1000) {
    discount = Math.round(subtotal * 0.15); // Authentic 15% promotional discount
  }

  const shipping = subtotal >= 999 || items.length === 0 ? 0 : 70;
  const total = Math.max(0, subtotal - discount + shipping);

  const applyCoupon = (code: string): boolean => {
    const upper = code.trim().toUpperCase();
    if (upper === "FESTIVE10") {
      setCouponCode(upper);
      localStorage.setItem(COUPON_STORAGE_KEY, upper);
      showToast("Coupon FESTIVE10 applied! 10% discount added.", "success");
      return true;
    }
    if (upper === "WEAVER100") {
      if (subtotal < 600) {
        showToast("Coupon WEAVER100 requires a minimum order of ₹600.", "error");
        return false;
      }
      setCouponCode(upper);
      localStorage.setItem(COUPON_STORAGE_KEY, upper);
      showToast("Coupon WEAVER100 applied! ₹100 discount added.", "success");
      return true;
    }
    if (upper === "DIWALI50") {
      setCouponCode(upper);
      localStorage.setItem(COUPON_STORAGE_KEY, upper);
      showToast("Festive Coupon DIWALI50 applied!", "success");
      return true;
    }
    showToast("Invalid promo code. Try FESTIVE10 or WEAVER100.", "error");
    return false;
  };

  const removeCoupon = () => {
    setCouponCode("");
    localStorage.removeItem(COUPON_STORAGE_KEY);
    showToast("Coupon removed.", "info");
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalCount,
        subtotal,
        discount,
        shipping,
        total,
        couponCode,
        applyCoupon,
        removeCoupon,
        isCartOpen,
        setIsCartOpen,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
