"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { CustomerProfile, Address } from "@/types";
import { useToast } from "./ToastContext";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: CustomerProfile | null;
  isLoading: boolean;
  /** true for Main Admin (verified by the server) */
  isOwner: boolean;
  /** true for Main Admin OR Normal Admin (verified by the server) */
  isAdmin: boolean;
  adminRole: "main_admin" | "admin" | null;
  adminPermissions: string[];
  adminLoading: boolean;
  signUpWithEmail: (email: string, password: string, fullName: string, phone?: string) => Promise<{ success: boolean; error?: string }>;
  signInWithEmail: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signInWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  resetPasswordForEmail: (email: string) => Promise<{ success: boolean; error?: string }>;
  updateUserPassword: (password: string) => Promise<{ success: boolean; error?: string }>;
  saveAddress: (address: Omit<Address, "id">) => Promise<boolean>;
  deleteAddress: (id: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Local storage key for demo/fallback auth state
const LOCAL_PROFILE_KEY = "raja_textile_user_profile_v1";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<CustomerProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { showToast } = useToast();

  // Admin role is decided by the SERVER (/api/admin/me), never guessed from the email in the browser.
  const [adminRole, setAdminRole] = useState<"main_admin" | "admin" | null>(null);
  const [adminPermissions, setAdminPermissions] = useState<string[]>([]);
  const [adminLoading, setAdminLoading] = useState(false);
  const isOwner = adminRole === "main_admin";
  const isAdmin = adminRole !== null;

  useEffect(() => {
    const token = session?.access_token;
    if (!token) {
      setAdminRole(null);
      setAdminPermissions([]);
      setAdminLoading(false);
      return;
    }
    let cancelled = false;
    setAdminLoading(true);
    fetch("/api/admin/me", { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" })
      .then(async (res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (cancelled) return;
        if (data?.success && (data.role === "main_admin" || data.role === "admin")) {
          setAdminRole(data.role);
          setAdminPermissions(Array.isArray(data.permissions) ? data.permissions : []);
        } else {
          setAdminRole(null);
          setAdminPermissions([]);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setAdminRole(null);
          setAdminPermissions([]);
        }
      })
      .finally(() => {
        if (!cancelled) setAdminLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [session?.access_token]);

  // Initialize Supabase session and listener
  useEffect(() => {
    let mounted = true;

    async function initAuth() {
      if (isSupabaseConfigured && supabase) {
        try {
          const {
            data: { session: initialSession },
          } = await supabase.auth.getSession();

          if (mounted && initialSession) {
            setSession(initialSession);
            setUser(initialSession.user);
            await fetchProfile(initialSession.user.id, initialSession.user.email || "");
          }
        } catch {
          // ignore error
        } finally {
          if (mounted) setIsLoading(false);
        }

        const {
          data: { subscription },
        } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
          if (!mounted) return;
          setSession(newSession);
          setUser(newSession?.user || null);
          if (newSession?.user) {
            await fetchProfile(newSession.user.id, newSession.user.email || "");
          } else {
            setProfile(null);
          }
          setIsLoading(false);
        });

        return () => {
          subscription.unsubscribe();
        };
      } else {
        // Fallback local auth simulation for sandbox development
        try {
          const stored = localStorage.getItem(LOCAL_PROFILE_KEY);
          if (stored) {
            const p: CustomerProfile = JSON.parse(stored);
            setProfile(p);
            // mock user
            setUser({
              id: p.id,
              email: p.email,
              user_metadata: { full_name: p.fullName },
              app_metadata: {},
              aud: "authenticated",
              created_at: p.createdAt,
            } as any);
          }
        } catch {
          // ignore
        } finally {
          if (mounted) setIsLoading(false);
        }
      }
    }

    initAuth();
    return () => {
      mounted = false;
    };
  }, []);

  // Fetch or create profile
  const fetchProfile = async (userId: string, email: string) => {
    if (isSupabaseConfigured && supabase) {
      try {
        const { data, error } = await supabase
          .from("user_profiles")
          .select("*")
          .eq("id", userId)
          .single();

        if (data && !error) {
          setProfile({
            id: data.id,
            email: data.email,
            fullName: data.full_name || data.fullName || "",
            phone: data.phone || "",
            role: data.role || "customer",
            addresses: Array.isArray(data.addresses) ? data.addresses : [],
            createdAt: data.created_at || new Date().toISOString(),
          });
          return;
        }
      } catch {
        // ignore
      }
    }

    // Default profile
    const defaultProfile: CustomerProfile = {
      id: userId,
      email,
      fullName: user?.user_metadata?.full_name || email.split("@")[0],
      phone: "",
      role: "customer",
      addresses: [],
      createdAt: new Date().toISOString(),
    };
    setProfile(defaultProfile);
  };

  const signUpWithEmail = async (
    email: string,
    password: string,
    fullName: string,
    phone?: string
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    if (isSupabaseConfigured && supabase) {
      try {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName, phone: phone || "" },
          },
        });

        if (error) {
          showToast(error.message, "error");
          return { success: false, error: error.message };
        }

        if (data.user) {
          showToast("Account created successfully! Welcome to Raja Textile.", "success");
          return { success: true };
        }
      } catch (err: any) {
        return { success: false, error: err.message };
      } finally {
        setIsLoading(false);
      }
    }

    // Fallback mode
    const fakeId = `usr_${Date.now()}`;
    const newProfile: CustomerProfile = {
      id: fakeId,
      email,
      fullName,
      phone: phone || "",
      addresses: [],
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(newProfile));
    setProfile(newProfile);
    setUser({
      id: fakeId,
      email,
      user_metadata: { full_name: fullName },
      app_metadata: {},
      aud: "authenticated",
      created_at: newProfile.createdAt,
    } as any);
    setIsLoading(false);
    showToast("Account created! (Local Sandbox Session)", "success");
    return { success: true };
  };

  const signInWithEmail = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    if (isSupabaseConfigured && supabase) {
      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) {
          showToast(error.message, "error");
          return { success: false, error: error.message };
        }

        if (data.session) {
          setSession(data.session);
          setUser(data.user);
          await fetchProfile(data.user.id, data.user.email || "");
          showToast(`Welcome back, ${data.user.user_metadata?.full_name || "Valued Customer"}!`, "success");
          return { success: true };
        }
      } catch (err: any) {
        return { success: false, error: err.message };
      } finally {
        setIsLoading(false);
      }
    }

    // Fallback sandbox login
    const fakeId = `usr_local_${Date.now()}`;
    const mockProfile: CustomerProfile = {
      id: fakeId,
      email,
      fullName: email.split("@")[0].toUpperCase(),
      addresses: [],
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(mockProfile));
    setProfile(mockProfile);
    setUser({
      id: fakeId,
      email,
      user_metadata: { full_name: mockProfile.fullName },
      app_metadata: {},
      aud: "authenticated",
      created_at: mockProfile.createdAt,
    } as any);
    setIsLoading(false);
    showToast("Signed in successfully (Sandbox session)", "success");
    return { success: true };
  };

  const signInWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    if (!supabase) {
      showToast("Connecting to authentication server. Please try again.", "info");
      return {
        success: false,
        error: "Supabase authentication client is initializing. Please try again.",
      };
    }

    try {
      const origin =
        typeof window !== "undefined" && window.location.origin
          ? window.location.origin
          : (process.env.NEXT_PUBLIC_SITE_URL || "https://raja-textiles.vercel.app");

      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${origin}/auth/callback`,
          queryParams: {
            access_type: "offline",
            prompt: "consent",
          },
        },
      });

      if (error) {
        showToast(error.message, "error");
        return { success: false, error: error.message };
      }
      return { success: true };
    } catch (err: any) {
      showToast(err.message || "Failed to initiate Google Sign-In", "error");
      return { success: false, error: err.message };
    }
  };

  const signOut = async () => {
    if (isSupabaseConfigured && supabase) {
      await supabase.auth.signOut();
    }
    localStorage.removeItem(LOCAL_PROFILE_KEY);
    setUser(null);
    setSession(null);
    setProfile(null);
    showToast("You have been signed out.", "info");
  };

  const resetPasswordForEmail = async (email: string): Promise<{ success: boolean; error?: string }> => {
    if (isSupabaseConfigured && supabase) {
      try {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/auth/reset-password`,
        });
        if (error) {
          showToast(error.message, "error");
          return { success: false, error: error.message };
        }
        showToast("Password reset link has been dispatched to your email.", "success");
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err.message };
      }
    }

    showToast("Password reset link simulated (Sandbox mode).", "info");
    return { success: true };
  };

  const updateUserPassword = async (password: string): Promise<{ success: boolean; error?: string }> => {
    if (isSupabaseConfigured && supabase) {
      try {
        const { error } = await supabase.auth.updateUser({ password });
        if (error) {
          showToast(error.message, "error");
          return { success: false, error: error.message };
        }
        showToast("Your password has been updated securely.", "success");
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err.message };
      }
    }
    showToast("Password updated in sandbox.", "success");
    return { success: true };
  };

  const saveAddress = async (newAddress: Omit<Address, "id">): Promise<boolean> => {
    if (!profile) return false;
    const addressWithId: Address = {
      ...newAddress,
      id: `addr_${Date.now()}`,
    };

    const updatedAddresses = [...profile.addresses, addressWithId];
    const updatedProfile = { ...profile, addresses: updatedAddresses };
    setProfile(updatedProfile);

    if (isSupabaseConfigured && supabase && user) {
      try {
        await supabase
          .from("user_profiles")
          .update({ addresses: updatedAddresses })
          .eq("id", user.id);
      } catch {
        // ignore
      }
    } else {
      localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(updatedProfile));
    }

    showToast("Delivery address saved to your profile.", "success");
    return true;
  };

  const deleteAddress = async (id: string): Promise<boolean> => {
    if (!profile) return false;
    const updatedAddresses = profile.addresses.filter((a) => a.id !== id);
    const updatedProfile = { ...profile, addresses: updatedAddresses };
    setProfile(updatedProfile);

    if (isSupabaseConfigured && supabase && user) {
      try {
        await supabase
          .from("user_profiles")
          .update({ addresses: updatedAddresses })
          .eq("id", user.id);
      } catch {
        // ignore
      }
    } else {
      localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(updatedProfile));
    }

    showToast("Address removed.", "info");
    return true;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        isLoading,
        isOwner,
        isAdmin,
        adminRole,
        adminPermissions,
        adminLoading,
        signUpWithEmail,
        signInWithEmail,
        signInWithGoogle,
        signOut,
        resetPasswordForEmail,
        updateUserPassword,
        saveAddress,
        deleteAddress,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
